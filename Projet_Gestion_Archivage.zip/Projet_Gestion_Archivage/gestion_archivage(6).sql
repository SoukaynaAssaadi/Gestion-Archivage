-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3308
-- Généré le :  sam. 24 juil. 2021 à 16:10
-- Version du serveur :  5.7.28
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `gestion_archivage`
--

-- --------------------------------------------------------

--
-- Structure de la table `administrateur`
--

DROP TABLE IF EXISTS `administrateur`;
CREATE TABLE IF NOT EXISTS `administrateur` (
  `CIN` varchar(8) NOT NULL,
  `Login` varchar(20) NOT NULL,
  `Nom` varchar(20) NOT NULL,
  `Prenom` varchar(20) NOT NULL,
  `Tel` varchar(10) NOT NULL,
  `Adresse` varchar(20) DEFAULT NULL,
  `Email` varchar(50) NOT NULL,
  `MDP` varchar(10) NOT NULL,
  PRIMARY KEY (`CIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `administrateur`
--

INSERT INTO `administrateur` (`CIN`, `Login`, `Nom`, `Prenom`, `Tel`, `Adresse`, `Email`, `MDP`) VALUES
('JC605310', 'Administrateur', 'Assaadi', 'Soukayna', '0677889910', 'Taroudant', 'sokaynaassaadi@gmail.com', 'admin'),
('JC654321', 'adminassaadi', 'assaadi', 'assaadi', '0654234567', 'taroudant', 'sokaynaassaadi1@gmail.com', 'admin1');

-- --------------------------------------------------------

--
-- Structure de la table `bordereau`
--

DROP TABLE IF EXISTS `bordereau`;
CREATE TABLE IF NOT EXISTS `bordereau` (
  `Numero_Bordereau` int(11) NOT NULL AUTO_INCREMENT,
  `Date_Creation` date NOT NULL,
  `Date_Reception` date NOT NULL,
  `Adresse` varchar(50) NOT NULL,
  `Tel` varchar(10) NOT NULL,
  `Statut` varchar(20) NOT NULL,
  `Bureau` varchar(50) NOT NULL,
  `Ville` varchar(20) NOT NULL,
  `Fax` varchar(20) NOT NULL,
  `Commentaire` text,
  `Nom_Entite_E` varchar(50) NOT NULL,
  `Etage` varchar(20) NOT NULL,
  `Code_Correspondant_E` varchar(20) NOT NULL,
  PRIMARY KEY (`Numero_Bordereau`),
  KEY `Nom_Entite_E` (`Nom_Entite_E`),
  KEY `Code_Correspondant_E` (`Code_Correspondant_E`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `bordereau`
--

INSERT INTO `bordereau` (`Numero_Bordereau`, `Date_Creation`, `Date_Reception`, `Adresse`, `Tel`, `Statut`, `Bureau`, `Ville`, `Fax`, `Commentaire`, `Nom_Entite_E`, `Etage`, `Code_Correspondant_E`) VALUES
(1, '2021-07-06', '2021-07-31', 'LW*S2*R04*T01*E01', '0676889900', 'Initialisé', 'bureau 1', 'Agadir', '0565557877', NULL, 'Département du controle médicale', 'etage 10', 'Corsp1'),
(2, '2021-06-21', '2021-07-28', 'LW*S1*R02*T03*E02', '0653221188', 'Initialisé', 'bureau 3', 'Agadir', '0566533999', NULL, 'Système d\'information', 'etage 8', 'Corsp1');

-- --------------------------------------------------------

--
-- Structure de la table `correspondant`
--

DROP TABLE IF EXISTS `correspondant`;
CREATE TABLE IF NOT EXISTS `correspondant` (
  `Code_Correspondant` varchar(50) NOT NULL,
  `Nom` varchar(20) NOT NULL,
  `Prenom` varchar(20) NOT NULL,
  `Tel` varchar(10) NOT NULL,
  `Adresse` varchar(20) DEFAULT NULL,
  `Email` varchar(50) NOT NULL,
  `Code_Postal` int(11) DEFAULT NULL,
  `Ville` varchar(20) DEFAULT NULL,
  `Pays` varchar(20) DEFAULT NULL,
  `Type` varchar(20) DEFAULT NULL,
  `Fax` varchar(20) DEFAULT NULL,
  `Commentaire` text,
  `Observation` text,
  `Nom_Entite_E` varchar(50) NOT NULL,
  PRIMARY KEY (`Code_Correspondant`),
  KEY `Nom_Entite_E` (`Nom_Entite_E`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `correspondant`
--

INSERT INTO `correspondant` (`Code_Correspondant`, `Nom`, `Prenom`, `Tel`, `Adresse`, `Email`, `Code_Postal`, `Ville`, `Pays`, `Type`, `Fax`, `Commentaire`, `Observation`, `Nom_Entite_E`) VALUES
('Corsp1', 'ASSAADI', 'Soukayna', '0656565654', 'Hay Pam', 'ASSAADI@gmail.com', 1800, 'Taroudant', 'Maroc', 'Actif', '05643439', NULL, NULL, 'Département de la liquidation des prestateurs');

-- --------------------------------------------------------

--
-- Structure de la table `docs`
--

DROP TABLE IF EXISTS `docs`;
CREATE TABLE IF NOT EXISTS `docs` (
  `Numero_Doc` int(11) NOT NULL AUTO_INCREMENT,
  `Numero_UA` int(11) NOT NULL,
  `photo` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`Numero_Doc`),
  KEY `Numero_UA` (`Numero_UA`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `docs`
--

INSERT INTO `docs` (`Numero_Doc`, `Numero_UA`, `photo`) VALUES
(1, 82, 'image/HGpMvJmiepFYzLBkUoADFI4S5DE2BHYe2JvzEqr3.pdf'),
(2, 85, 'image/zPhrlvHx3R2R3jtWDPNYPVhHo2qpj2FFgP5j8ahF.png'),
(3, 84, 'image/qqFlncbjVSvhwwexZWaWiMoidoFgrFluYvjjNEGy.pdf'),
(6, 82, 'image/55v4GDkdTpcEOeTThH99tEnWlx6qP0MoWPP8iDRi.png');

-- --------------------------------------------------------

--
-- Structure de la table `entites`
--

DROP TABLE IF EXISTS `entites`;
CREATE TABLE IF NOT EXISTS `entites` (
  `Nom_Entite` varchar(50) NOT NULL,
  `Code_Entite` varchar(20) NOT NULL,
  `Tel` varchar(10) NOT NULL,
  `Adresse` varchar(20) DEFAULT NULL,
  `Email` varchar(50) NOT NULL,
  `Ville` varchar(20) NOT NULL,
  `Code_Postal` int(11) NOT NULL,
  `Pays` varchar(20) NOT NULL,
  `Date_Creation` date NOT NULL,
  `Observation` text,
  PRIMARY KEY (`Nom_Entite`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `entites`
--

INSERT INTO `entites` (`Nom_Entite`, `Code_Entite`, `Tel`, `Adresse`, `Email`, `Ville`, `Code_Postal`, `Pays`, `Date_Creation`, `Observation`) VALUES
('Département de la liquidation des prestateurs', 'DLP', '098765434', 'hay mohamadi', 'DLP@gmail.com', 'Agadir', 80000, 'maroc', '2021-07-01', 'entite1'),
('Département du controle médicale', 'DCM', '0675698777', 'hay salam', 'DCM@gmail.com', 'Agadir', 80000, 'maroc', '2021-07-13', NULL),
('Système d\'information', 'SI', '0654323231', 'Hay Mohamadi', 'SI80000@gmail.com', 'Agadir', 80000, 'Maroc', '2021-07-22', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `etage`
--

DROP TABLE IF EXISTS `etage`;
CREATE TABLE IF NOT EXISTS `etage` (
  `Code_Etage` varchar(20) NOT NULL,
  `Nombre_Place` double DEFAULT NULL,
  `Description` text,
  `Code_Local_E` varchar(20) NOT NULL,
  `Code_Salle_E` varchar(20) NOT NULL,
  `Code_Ranger_E` varchar(20) NOT NULL,
  `Code_Travet_E` varchar(20) NOT NULL,
  PRIMARY KEY (`Code_Etage`),
  KEY `Code_Local_E` (`Code_Local_E`),
  KEY `Code_Salle_E` (`Code_Salle_E`),
  KEY `Code_Ranger_E` (`Code_Ranger_E`),
  KEY `Code_Travet_E` (`Code_Travet_E`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `etage`
--

INSERT INTO `etage` (`Code_Etage`, `Nombre_Place`, `Description`, `Code_Local_E`, `Code_Salle_E`, `Code_Ranger_E`, `Code_Travet_E`) VALUES
('E01', 10, 'ETAGE01', 'LW', 'S1', 'R01', 'T01'),
('E02', 10, 'ETAGE01', 'LW', 'S1', 'R01', 'T01'),
('E03', 10, 'ETAGE03', 'LA', 'S1', 'R01', 'T01'),
('E04', 10, 'ETAGE04', 'LW', 'S1', 'R01', 'T01'),
('E05', 20, 'ETAGE05', 'LW', 'S1', 'R01', 'T02'),
('E06', 20, 'ETAGE06', 'LA', 'S1', 'R01', 'T02');

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `gestion_indexation`
--

DROP TABLE IF EXISTS `gestion_indexation`;
CREATE TABLE IF NOT EXISTS `gestion_indexation` (
  `Code_Index` varchar(20) NOT NULL,
  `Type` varchar(50) NOT NULL,
  `valeur` varchar(20) DEFAULT NULL,
  `Description` text NOT NULL,
  `Code_Nature_E` varchar(20) NOT NULL,
  PRIMARY KEY (`Code_Index`),
  KEY `Code_Nature_E` (`Code_Nature_E`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `gestion_indexation`
--

INSERT INTO `gestion_indexation` (`Code_Index`, `Type`, `valeur`, `Description`, `Code_Nature_E`) VALUES
('C01', 'Chaine de caractéres', NULL, 'Libellé', 'spec tech'),
('C02', 'Date', NULL, 'Date mise à jour', 'spec tech'),
('C03', 'Numérique', NULL, 'Nombre de page', 'spec tech');

-- --------------------------------------------------------

--
-- Structure de la table `gestion_utilisateur`
--

DROP TABLE IF EXISTS `gestion_utilisateur`;
CREATE TABLE IF NOT EXISTS `gestion_utilisateur` (
  `id_gu` int(11) NOT NULL AUTO_INCREMENT,
  `CIN` varchar(8) NOT NULL,
  `Login` varchar(20) NOT NULL,
  `Nom` varchar(20) NOT NULL,
  `Prenom` varchar(20) NOT NULL,
  `Tel` varchar(10) NOT NULL,
  `Adresse` varchar(50) DEFAULT NULL,
  `Email` varchar(50) NOT NULL,
  `MDP` varchar(30) NOT NULL,
  `Date_Creation` date DEFAULT NULL,
  `Date_Debut` date DEFAULT NULL,
  `Date_Fin` date DEFAULT NULL,
  `Statut` varchar(20) DEFAULT NULL,
  `Derniere_changement_MDP` date DEFAULT NULL,
  `Ville` varchar(20) DEFAULT NULL,
  `Pays` varchar(20) DEFAULT NULL,
  `Commentaire` text,
  `Nom_Entite_E` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_gu`),
  KEY `Nom_Entite_E` (`Nom_Entite_E`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `gestion_utilisateur`
--

INSERT INTO `gestion_utilisateur` (`id_gu`, `CIN`, `Login`, `Nom`, `Prenom`, `Tel`, `Adresse`, `Email`, `MDP`, `Date_Creation`, `Date_Debut`, `Date_Fin`, `Statut`, `Derniere_changement_MDP`, `Ville`, `Pays`, `Commentaire`, `Nom_Entite_E`) VALUES
(1, 'l', 'login', 'l', 'l', '0999999999', 'l', 'l@gmail.com', 'l', '2021-07-07', '2021-07-08', '2021-08-01', 'l', '2021-07-21', 'l', 'l', 'l', NULL),
(2, 'JC605310', 'assaadi2000', 'assaadi', 'soukayna', '0999999999', 'taroudant', 'soukaynaassaadi@gmail.com', 'aaaaaaaaaaaaaaaaaaaa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'JC654321', 'assaadisoukayna', 'assaadi', 'assaadi', '0697654342', 'Agadir', 'assaadi1assaadi@gmail.com', 'assaadiassaadi', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'JC432111', 'sokaynaAssaadi', 'assaadi', 'sokayna', '0678555555', 'Taroudant', 'sokaynaassaadi@gmail.com', 'sokaynaassaadi', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'JD222222', 'Acces total', 'assaadi', 'soukayna', '0666666666', 'taroudant', 'soukaynaAccestotal@gmail.com', 'soukaynaAccestotal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'JC542312', 'assaadiVersement', 'assaadi', 'soukayna', '0867666666', 'taroudant', 'assaadiVersement@gmail.com', 'assaadiVersement', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'JC432001', 'assaadiSaisie', 'assaadi', 'soukayna', '0546787878', 'taroudant', 'assaadiSaisie@gmail.com', 'assaadiSaisie', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'JC432189', 'assaadiRecherche', 'assaadi', 'soukayna', '0986543322', 'taroudant', 'assaadiRecherche@gmail.com', 'assaadiRecherche', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Département du controle médicale'),
(9, 'JC412097', 'assaadiRetour', 'assaadi', 'soukayna', '0678633333', 'Rabat', 'assaadiRetour@gmail.com', 'assaadiRetour', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Département de la liquidation des prestateurs'),
(10, 'JC418988', 'assaadiSortiesD', 'assaadi', 'soukayna', '0954444444', 'Tanger', 'assaadiSortiesdefinitive@gmail.com', 'assaadiSortiesD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `groupe_privilege`
--

DROP TABLE IF EXISTS `groupe_privilege`;
CREATE TABLE IF NOT EXISTS `groupe_privilege` (
  `id_Privilege` int(11) NOT NULL AUTO_INCREMENT,
  `Code_Privilege` varchar(20) NOT NULL,
  `Description` varchar(50) NOT NULL,
  PRIMARY KEY (`id_Privilege`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `groupe_privilege`
--

INSERT INTO `groupe_privilege` (`id_Privilege`, `Code_Privilege`, `Description`) VALUES
(2, 'Accès Total', 'Accès Total'),
(3, 'Administrateur', 'Administrateur'),
(5, 'Client', 'Travaux Intérieurs'),
(7, 'Emplacement', 'Emplacement'),
(10, 'Recherche', 'Recherche'),
(11, 'Retour', 'Retour'),
(12, 'Saisie', 'Saisie'),
(13, 'Sorties Définitive', 'Sorties Définitive'),
(15, 'Versement', 'Versement');

-- --------------------------------------------------------

--
-- Structure de la table `inventaire`
--

DROP TABLE IF EXISTS `inventaire`;
CREATE TABLE IF NOT EXISTS `inventaire` (
  `id_Inventaire` int(11) NOT NULL AUTO_INCREMENT,
  `Libelle` varchar(50) NOT NULL,
  `Date_Modification` date DEFAULT NULL,
  `Nombre_Page` int(11) DEFAULT NULL,
  `Numero_UA_E` int(11) NOT NULL,
  PRIMARY KEY (`id_Inventaire`),
  KEY `Numero_UA_E` (`Numero_UA_E`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `inventaire`
--

INSERT INTO `inventaire` (`id_Inventaire`, `Libelle`, `Date_Modification`, `Nombre_Page`, `Numero_UA_E`) VALUES
(1, '4321', '2021-07-22', 50, 82),
(2, '45563', '2021-06-18', 100, 83),
(3, '6549', '2021-07-07', 40, 85);

-- --------------------------------------------------------

--
-- Structure de la table `listeprivileges`
--

DROP TABLE IF EXISTS `listeprivileges`;
CREATE TABLE IF NOT EXISTS `listeprivileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Menu` varchar(50) NOT NULL,
  `Page` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `listeprivileges`
--

INSERT INTO `listeprivileges` (`id`, `Menu`, `Page`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Administration', 'Groupes Privileges ', NULL, '2021-06-19 20:10:43', NULL),
(2, 'Administration', 'Utilisateurs', NULL, NULL, NULL),
(3, 'Exploitation', 'Entités', NULL, NULL, NULL),
(4, 'Exploitation', 'Correspondants', NULL, NULL, NULL),
(5, 'Exploitation', 'Natures', NULL, NULL, NULL),
(6, 'Exploitation', 'Prestations', NULL, NULL, NULL),
(7, 'Exploitation', 'Versements', NULL, '2021-06-19 20:31:53', NULL),
(8, 'Exploitation', 'Unité d\'archivage', NULL, NULL, NULL),
(9, 'Emplacement', 'Local', NULL, NULL, NULL),
(10, 'Emplacement', 'Salle', NULL, '2021-06-19 20:12:08', NULL),
(11, 'Emplacement', 'Ranger', NULL, NULL, NULL),
(12, 'Emplacement', 'Travet', NULL, '2021-06-19 20:36:31', NULL),
(13, 'Emplacement', 'Etage', NULL, NULL, NULL),
(14, 'Emplacement', 'Affectation', NULL, NULL, NULL),
(15, 'Travaux Intérieurs', 'Saisie', NULL, NULL, NULL),
(16, 'Travaux Intérieurs', 'Recherche', NULL, NULL, NULL),
(17, 'Travaux Intérieurs', 'Retour', NULL, NULL, NULL),
(19, 'Travaux Intérieurs', 'Inventaire', NULL, NULL, NULL),
(20, 'Exploitation', 'Sorties definitive', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `local`
--

DROP TABLE IF EXISTS `local`;
CREATE TABLE IF NOT EXISTS `local` (
  `Code_Local` varchar(20) NOT NULL,
  `Nom` varchar(20) NOT NULL,
  `Place_Disponible` double DEFAULT NULL,
  PRIMARY KEY (`Code_Local`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `local`
--

INSERT INTO `local` (`Code_Local`, `Nom`, `Place_Disponible`) VALUES
('LA', 'Local Agadir', 100000),
('LW', 'Local Wilaya', 19999);

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2019_08_19_000000_create_failed_jobs_table', 1),
(3, '2021_06_19_195623_add_column_delete_at_listeprivileges', 1),
(4, '2021_06_19_234229_add_column_delete_at_utilisateurs', 2),
(5, '2021_07_01_162801_add_column_photo_docs', 3);

-- --------------------------------------------------------

--
-- Structure de la table `nature_document`
--

DROP TABLE IF EXISTS `nature_document`;
CREATE TABLE IF NOT EXISTS `nature_document` (
  `Code_Nature` varchar(20) NOT NULL,
  `Nom` varchar(100) NOT NULL,
  `Delai_Conservation` int(11) DEFAULT NULL,
  `Description` text,
  `Nom_Entite_E` varchar(50) NOT NULL,
  `Code_Service_E` varchar(20) NOT NULL,
  PRIMARY KEY (`Code_Nature`),
  KEY `Nom_Entite_E` (`Nom_Entite_E`),
  KEY `Code_Service` (`Code_Service_E`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `nature_document`
--

INSERT INTO `nature_document` (`Code_Nature`, `Nom`, `Delai_Conservation`, `Description`, `Nom_Entite_E`, `Code_Service_E`) VALUES
('spec tech', 'specification technique', 9999, NULL, 'Système d\'information', 'tech');

-- --------------------------------------------------------

--
-- Structure de la table `prestation`
--

DROP TABLE IF EXISTS `prestation`;
CREATE TABLE IF NOT EXISTS `prestation` (
  `Code_Prestation` varchar(20) NOT NULL,
  `Description` text,
  PRIMARY KEY (`Code_Prestation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `prestation`
--

INSERT INTO `prestation` (`Code_Prestation`, `Description`) VALUES
('PHOTO/FAX', 'Recherche photocopie et fax'),
('PHOTO/MAIL', 'Recherche photocopie et mail'),
('RECH/ORIG', 'Recherche Original et livraison');

-- --------------------------------------------------------

--
-- Structure de la table `privilege`
--

DROP TABLE IF EXISTS `privilege`;
CREATE TABLE IF NOT EXISTS `privilege` (
  `num_Privilege` int(11) NOT NULL AUTO_INCREMENT,
  `Menu` varchar(20) NOT NULL,
  `Page` varchar(20) NOT NULL,
  `Ajouter` varchar(10) DEFAULT NULL,
  `Modifier` varchar(10) DEFAULT NULL,
  `Supprimer` varchar(3) DEFAULT NULL,
  `Rechercher` varchar(3) DEFAULT NULL,
  `Export` varchar(3) DEFAULT NULL,
  `Import` varchar(3) DEFAULT NULL,
  `Login` varchar(20) NOT NULL,
  `Nom` varchar(20) NOT NULL,
  `Prenom` varchar(20) NOT NULL,
  PRIMARY KEY (`num_Privilege`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `privilege`
--

INSERT INTO `privilege` (`num_Privilege`, `Menu`, `Page`, `Ajouter`, `Modifier`, `Supprimer`, `Rechercher`, `Export`, `Import`, `Login`, `Nom`, `Prenom`) VALUES
(1, 'Administration', 'Groupes Privileges ', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(2, 'Administration', 'Groupes Privileges ', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(3, 'Administration', 'Utilisateurs', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(4, 'Administration', 'Utilisateurs', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(5, 'Exploitation', 'Entités', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(6, 'Exploitation', 'Entités', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(7, 'Exploitation', 'Correspondants', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(8, 'Exploitation', 'Correspondants', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(9, 'Exploitation', 'Natures', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(10, 'Exploitation', 'Natures', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(11, 'Exploitation', 'Prestations', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(12, 'Exploitation', 'Prestations', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(13, 'Exploitation', 'Versements', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(14, 'Exploitation', 'Versements', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(15, 'Exploitation', 'Unité d\'archivage', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(16, 'Exploitation', 'Unité d\'archivage', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(17, 'Emplacement', 'Local', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(18, 'Emplacement', 'Local', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(19, 'Emplacement', 'Salle', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(20, 'Emplacement', 'Salle', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(21, 'Emplacement', 'Ranger', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(22, 'Emplacement', 'Ranger', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(23, 'Emplacement', 'Travet', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(24, 'Emplacement', 'Travet', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(25, 'Emplacement', 'Etage', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(26, 'Emplacement', 'Etage', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(27, 'Emplacement', 'Affectation', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(28, 'Emplacement', 'Affectation', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(29, 'Travaux Intérieurs', 'Saisie', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(30, 'Travaux Intérieurs', 'Saisie', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(31, 'Travaux Intérieurs', 'Recherche', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(32, 'Travaux Intérieurs', 'Recherche', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(33, 'Travaux Intérieurs', 'Retour', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(34, 'Travaux Intérieurs', 'Retour', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(35, 'Travaux Intérieurs', 'Intégration', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(36, 'Travaux Intérieurs', 'Intégration', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(37, 'Travaux Intérieurs', 'Inventaire', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(38, 'Travaux Intérieurs', 'Inventaire', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(39, 'Exploitation', 'Sorties definitive', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadi2000', 'assaadi', 'soukayna'),
(40, 'Exploitation', 'Sorties definitive', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(65, 'Emplacement', 'Affectation', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiEmplacement', 'assaadi', 'sokayna'),
(66, 'Acces total', 'Acces total', NULL, NULL, NULL, NULL, NULL, NULL, 'Acces total', 'assaadi', 'soukayna'),
(67, 'Exploitation', 'Versements', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiVersements', 'assaadi', 'soukayna'),
(68, 'Travaux Intérieurs', 'Saisie', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiSaisie', 'assaadi', 'soukayna'),
(69, 'Travaux Intérieurs', 'Recherche', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiRecherche', 'assaadi', 'soukayna'),
(70, 'Travaux Intérieurs', 'Retour', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiRetour', 'assaadi', 'soukayna'),
(71, 'Exploitation', 'Sorties definitive', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiSortiesD', 'assaadi', 'soukayna'),
(81, 'Administration', 'Utilisateurs', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiEmplacement', 'assaadi', 'sokayna'),
(82, 'Administration', 'Utilisateurs', NULL, NULL, NULL, NULL, NULL, NULL, 'Acces total', 'assaadi', 'soukayna'),
(83, 'Administration', 'Utilisateurs', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiVersements', 'assaadi', 'soukayna'),
(84, 'Administration', 'Utilisateurs', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiSaisie', 'assaadi', 'soukayna'),
(85, 'Administration', 'Utilisateurs', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiRecherche', 'assaadi', 'soukayna'),
(86, 'Administration', 'Utilisateurs', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiRetour', 'assaadi', 'soukayna'),
(87, 'Administration', 'Utilisateurs', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiSortiesD', 'assaadi', 'soukayna'),
(88, 'Exploitation', 'Entités', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(89, 'Exploitation', 'Entités', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiEmplacement', 'assaadi', 'sokayna'),
(90, 'Exploitation', 'Entités', NULL, NULL, NULL, NULL, NULL, NULL, 'Acces total', 'assaadi', 'soukayna'),
(91, 'Exploitation', 'Entités', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiVersements', 'assaadi', 'soukayna'),
(92, 'Exploitation', 'Entités', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiSaisie', 'assaadi', 'soukayna'),
(93, 'Exploitation', 'Entités', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiRecherche', 'assaadi', 'soukayna'),
(94, 'Exploitation', 'Entités', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiRetour', 'assaadi', 'soukayna'),
(95, 'Exploitation', 'Entités', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiSortiesD', 'assaadi', 'soukayna'),
(96, 'Exploitation', 'Correspondants', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadisoukayna', 'assaadi', 'assaadi'),
(97, 'Exploitation', 'Correspondants', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiEmplacement', 'assaadi', 'sokayna'),
(98, 'Exploitation', 'Correspondants', NULL, NULL, NULL, NULL, NULL, NULL, 'Acces total', 'assaadi', 'soukayna'),
(99, 'Exploitation', 'Correspondants', NULL, NULL, NULL, NULL, NULL, NULL, 'assaadiVersements', 'assaadi', 'soukayna');

-- --------------------------------------------------------

--
-- Structure de la table `ranger`
--

DROP TABLE IF EXISTS `ranger`;
CREATE TABLE IF NOT EXISTS `ranger` (
  `Code_Ranger` varchar(20) NOT NULL,
  `Nombre_Place` int(11) DEFAULT NULL,
  `Description` text,
  `Code_Local_E` varchar(20) NOT NULL,
  `Code_Salle_E` varchar(20) NOT NULL,
  PRIMARY KEY (`Code_Ranger`),
  KEY `Code_Local_E` (`Code_Local_E`),
  KEY `Code_Salle_E` (`Code_Salle_E`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `ranger`
--

INSERT INTO `ranger` (`Code_Ranger`, `Nombre_Place`, `Description`, `Code_Local_E`, `Code_Salle_E`) VALUES
('R01', 400000, 'RANGER01', 'LA', 'S1'),
('R02', 50000, 'RANGER02', 'LA', 'S1'),
('R03', 400000, 'RANGER03', 'LA', 'S1'),
('R04', 7000, 'RANGER04', 'LA', 'S1'),
('R05', 356588, 'RANGER05', 'LA', 'S1'),
('R06', 7688990, 'RANGER06', 'LA', 'S1'),
('R07', 100000, 'RANGER07', 'LA', 'S1'),
('R08', 1098760, 'RANGER08', 'LA', 'S1');

-- --------------------------------------------------------

--
-- Structure de la table `recherche`
--

DROP TABLE IF EXISTS `recherche`;
CREATE TABLE IF NOT EXISTS `recherche` (
  `Numero_Demande` int(11) NOT NULL AUTO_INCREMENT,
  `Numero_Recherche` int(11) DEFAULT NULL,
  `Statut` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Mode_Livraison` varchar(20) NOT NULL,
  `Date_Reception` date DEFAULT NULL,
  `Date_Livraison` date DEFAULT NULL,
  `Libelle` varchar(50) NOT NULL,
  `Annee` varchar(4) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Urgence` varchar(20) NOT NULL,
  `Demandeur` varchar(50) NOT NULL,
  `Adresse_Correspondant` varchar(50) DEFAULT NULL,
  `Notes` text,
  `Localisation` varchar(50) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Observation` text,
  `Nom_Entite_E` varchar(50) NOT NULL,
  `Code_Service_E` varchar(20) NOT NULL,
  `Code_Correspondant_E` varchar(20) NOT NULL,
  `Code_Prestation_E` varchar(20) NOT NULL,
  `Code_Nature_E` varchar(20) NOT NULL,
  `Numero_UA_E` int(11) DEFAULT NULL,
  `Numero_Bordereau_E` int(11) DEFAULT NULL,
  PRIMARY KEY (`Numero_Demande`),
  KEY `Nom_Entite_E` (`Nom_Entite_E`),
  KEY `Code_Service_E` (`Code_Service_E`),
  KEY `Code_Correspondant_E` (`Code_Correspondant_E`),
  KEY `Code_Prestation_E` (`Code_Prestation_E`),
  KEY `Code_Nature_E` (`Code_Nature_E`),
  KEY `Numero_UA_E` (`Numero_UA_E`),
  KEY `Numero_Bordereau_E` (`Numero_Bordereau_E`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `recherche`
--

INSERT INTO `recherche` (`Numero_Demande`, `Numero_Recherche`, `Statut`, `Email`, `Mode_Livraison`, `Date_Reception`, `Date_Livraison`, `Libelle`, `Annee`, `Type`, `Urgence`, `Demandeur`, `Adresse_Correspondant`, `Notes`, `Localisation`, `Date`, `Observation`, `Nom_Entite_E`, `Code_Service_E`, `Code_Correspondant_E`, `Code_Prestation_E`, `Code_Nature_E`, `Numero_UA_E`, `Numero_Bordereau_E`) VALUES
(10, NULL, 'En Consultation', 'demandeRecherche1@gmail.com', 'Transport', '2021-06-26', '2021-06-28', 'Agence', '2021', 'contenu', 'Trés urgente', 'assaadi soukayna', 'agadir Hay Salam', NULL, NULL, NULL, NULL, 'Système d\'information', 'tech', 'Corsp1', 'PHOTO/FAX', 'spec tech', 82, 2),
(11, NULL, 'Document Non Retourner', 'demandeRecherche2@gmail.com', 'Transport', '2021-07-05', '2021-06-09', 'Echec de recherche', '2021', 'contenu', 'urgente', 'assaadi assaadi', 'Agadir Hay Mohammadi', NULL, NULL, NULL, NULL, 'Département du controle médicale', 'tech', 'Corsp1', 'PHOTO/MAIL', 'spec tech', 84, 1);

-- --------------------------------------------------------

--
-- Structure de la table `salle`
--

DROP TABLE IF EXISTS `salle`;
CREATE TABLE IF NOT EXISTS `salle` (
  `Code_Salle` varchar(20) NOT NULL,
  `Nom` varchar(20) NOT NULL,
  `Place_Disponible` double DEFAULT NULL,
  `Code_Local_E` varchar(20) NOT NULL,
  PRIMARY KEY (`Code_Salle`),
  KEY `Code_Locale_E` (`Code_Local_E`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `salle`
--

INSERT INTO `salle` (`Code_Salle`, `Nom`, `Place_Disponible`, `Code_Local_E`) VALUES
('S1', 'Salle1', 100, 'LA'),
('S2', 'Salle2', 100000, 'LW');

-- --------------------------------------------------------

--
-- Structure de la table `service`
--

DROP TABLE IF EXISTS `service`;
CREATE TABLE IF NOT EXISTS `service` (
  `Code_Service` varchar(20) NOT NULL,
  `Nom` varchar(20) NOT NULL,
  `Description` text,
  `Code_Correspondant_E` varchar(50) DEFAULT NULL,
  `Nom_Entite_E` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Code_Service`),
  KEY `Code_Correspondant_E` (`Code_Correspondant_E`),
  KEY `service_ibfk_2` (`Nom_Entite_E`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `service`
--

INSERT INTO `service` (`Code_Service`, `Nom`, `Description`, `Code_Correspondant_E`, `Nom_Entite_E`) VALUES
('tech', 'technique', NULL, 'Corsp1', 'Système d\'information');

-- --------------------------------------------------------

--
-- Structure de la table `sortie_definitive`
--

DROP TABLE IF EXISTS `sortie_definitive`;
CREATE TABLE IF NOT EXISTS `sortie_definitive` (
  `Numero_Sortie_Definitive` int(11) NOT NULL AUTO_INCREMENT,
  `Titre` varchar(100) NOT NULL,
  `Date_Creation` date DEFAULT NULL,
  `Type` varchar(50) NOT NULL,
  `Statut` varchar(20) NOT NULL,
  `Date_Prevu` date DEFAULT NULL,
  `Nombre_UA` int(11) DEFAULT NULL,
  `Commentaire` text,
  `Nom_Entite_E` varchar(50) NOT NULL,
  `Numero_UA_E` int(11) NOT NULL,
  `Numero_Voyage_E` int(11) NOT NULL,
  PRIMARY KEY (`Numero_Sortie_Definitive`),
  KEY `Nom_Entite_E` (`Nom_Entite_E`),
  KEY `Numero_UA_E` (`Numero_UA_E`),
  KEY `Numero_Voyage_E` (`Numero_Voyage_E`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sortie_definitive`
--

INSERT INTO `sortie_definitive` (`Numero_Sortie_Definitive`, `Titre`, `Date_Creation`, `Type`, `Statut`, `Date_Prevu`, `Nombre_UA`, `Commentaire`, `Nom_Entite_E`, `Numero_UA_E`, `Numero_Voyage_E`) VALUES
(3, 'Destruction des spécification fonctionnelle détaillées', '2021-07-14', 'Sortis définitive', 'initialisé', '2021-08-07', NULL, NULL, 'Système d\'information', 82, 2),
(4, 'destruction', '2021-07-17', 'Sortis définitive', 'Validé', '2021-07-20', NULL, NULL, 'Département de la liquidation des prestateurs', 85, 2);

-- --------------------------------------------------------

--
-- Structure de la table `travet`
--

DROP TABLE IF EXISTS `travet`;
CREATE TABLE IF NOT EXISTS `travet` (
  `Code_Travet` varchar(20) NOT NULL,
  `Nombre_Place` double DEFAULT NULL,
  `Description` text,
  `Code_Local_E` varchar(20) NOT NULL,
  `Code_Salle_E` varchar(20) NOT NULL,
  `Code_Ranger_E` varchar(20) NOT NULL,
  PRIMARY KEY (`Code_Travet`),
  KEY `Code_Local_E` (`Code_Local_E`),
  KEY `Code_Salle_E` (`Code_Salle_E`),
  KEY `Code_Ranger_E` (`Code_Ranger_E`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `travet`
--

INSERT INTO `travet` (`Code_Travet`, `Nombre_Place`, `Description`, `Code_Local_E`, `Code_Salle_E`, `Code_Ranger_E`) VALUES
('T01', 20, 'TRAVET01', 'LW', 'S1', 'R01'),
('T02', 50, 'TRAVET02', 'LW', 'S1', 'R01'),
('T03', 20, 'TRAVET03', 'LW', 'S1', 'R01'),
('T04', 20, 'TRAVET04', 'LW', 'S1', 'R01'),
('T05', 20, 'TRAVET05', 'LW', 'S1', 'R01'),
('T06', 20, 'TRAVET06', 'LW', 'S1', 'R01'),
('T07', 30, 'TRAVET07', 'LW', 'S2', 'R02'),
('T08', 30, 'TRAVET08', 'LA', 'S2', 'R03');

-- --------------------------------------------------------

--
-- Structure de la table `unitearchivages`
--

DROP TABLE IF EXISTS `unitearchivages`;
CREATE TABLE IF NOT EXISTS `unitearchivages` (
  `Numero_UA` int(11) NOT NULL AUTO_INCREMENT,
  `Statut` varchar(20) NOT NULL,
  `Date_Entrer` date NOT NULL,
  `Annee` year(4) DEFAULT NULL,
  `Date_Destruction` date DEFAULT NULL,
  `Commentaire` text,
  `Code_Local_E` varchar(20) DEFAULT NULL,
  `Code_Salle_E` varchar(20) DEFAULT NULL,
  `Code_Ranger_E` varchar(20) DEFAULT NULL,
  `Code_Travet_E` varchar(20) DEFAULT NULL,
  `Code_Etage_E` varchar(20) DEFAULT NULL,
  `Code_Service_E` varchar(20) NOT NULL,
  `Code_Nature_E` varchar(20) NOT NULL,
  `Code_Versement_E` varchar(20) NOT NULL,
  `Nom_Entite_E` varchar(50) NOT NULL,
  PRIMARY KEY (`Numero_UA`),
  KEY `Code_Local_E` (`Code_Local_E`),
  KEY `Code_Salle_E` (`Code_Salle_E`),
  KEY `Code_Ranger_E` (`Code_Ranger_E`),
  KEY `Code_Travet_E` (`Code_Travet_E`),
  KEY `Code_Etage_E` (`Code_Etage_E`),
  KEY `Code_Service_E` (`Code_Service_E`),
  KEY `Code_Nature_E` (`Code_Nature_E`),
  KEY `Code_Versement_E` (`Code_Versement_E`),
  KEY `Nom_Entite_E` (`Nom_Entite_E`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `unitearchivages`
--

INSERT INTO `unitearchivages` (`Numero_UA`, `Statut`, `Date_Entrer`, `Annee`, `Date_Destruction`, `Commentaire`, `Code_Local_E`, `Code_Salle_E`, `Code_Ranger_E`, `Code_Travet_E`, `Code_Etage_E`, `Code_Service_E`, `Code_Nature_E`, `Code_Versement_E`, `Nom_Entite_E`) VALUES
(82, 'Normal', '2021-03-30', 2021, '2021-07-20', NULL, 'LA', 'S1', 'R01', 'T01', 'E01', 'tech', 'spec tech', 'vrs1', 'Département de la liquidation des prestateurs'),
(83, 'Normal', '2021-03-30', 2021, '2021-07-01', NULL, 'LW', 'S1', 'R01', 'T01', 'E01', 'tech', 'spec tech', 'vrs1', 'Département de la liquidation des prestateurs'),
(84, 'Normal', '2021-08-06', 2021, '2021-07-24', NULL, 'LW', 'S1', 'R01', 'T01', 'E01', 'tech', 'spec tech', 'vrs1', 'Système d\'information'),
(85, 'Normal', '2021-07-30', 2021, '2021-07-13', NULL, 'LW', 'S1', 'R02', 'T01', 'E03', 'tech', 'spec tech', 'vrs1', 'Département de la liquidation des prestateurs');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CIN` varchar(8) NOT NULL,
  `Login` varchar(20) NOT NULL,
  `Nom` varchar(20) NOT NULL,
  `Prenom` varchar(20) NOT NULL,
  `Tel` varchar(10) NOT NULL,
  `Adresse` varchar(50) DEFAULT NULL,
  `Email` varchar(50) NOT NULL,
  `MDP` varchar(30) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Login` (`Login`),
  UNIQUE KEY `CIN` (`CIN`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `CIN`, `Login`, `Nom`, `Prenom`, `Tel`, `Adresse`, `Email`, `MDP`, `created_at`, `updated_at`, `deleted_at`) VALUES
(15, 'JC605310', 'assaadi2000', 'assaadi', 'soukayna', '0999999999', 'taroudant', 'soukaynaassaadi@gmail.com', 'aaaaaaaaaaaaaaaaaaaa', NULL, '2021-07-22 20:25:48', NULL),
(16, 'JC654321', 'assaadisoukayna', 'assaadi', 'assaadi', '0697654342', 'Agadir', 'assaadi1assaadi@gmail.com', 'assaadiassaadi', NULL, NULL, NULL),
(17, 'JC432111', 'assaadiEmplacement', 'assaadi', 'sokayna', '0678555555', 'Taroudant', 'sokaynaassaadi@gmail.com', 'assaadiEmplacement', NULL, NULL, NULL),
(18, 'JD222222', 'Acces total', 'assaadi', 'soukayna', '0666666666', 'taroudant', 'soukaynaAccestotal@gmail.com', 'soukaynaAccestotal', NULL, NULL, NULL),
(19, 'JC542312', 'assaadiVersements', 'assaadi', 'soukayna', '0867666666', 'taroudant', 'assaadiVersement@gmail.com', 'assaadiVersements', NULL, NULL, NULL),
(20, 'JC432001', 'assaadiSaisie', 'assaadi', 'soukayna', '0546787878', 'taroudant', 'assaadiSaisie@gmail.com', 'assaadiSaisie', NULL, NULL, NULL),
(21, 'JC432189', 'assaadiRecherche', 'assaadi', 'soukayna', '0986543322', 'taroudant', 'assaadiRecherche@gmail.com', 'assaadiRecherche', NULL, NULL, NULL),
(22, 'JC412097', 'assaadiRetour', 'assaadi', 'soukayna', '0678633333', 'Rabat', 'assaadiRetour@gmail.com', 'assaadiRetour', NULL, NULL, NULL),
(23, 'JC418988', 'assaadiSortiesD', 'assaadi', 'soukayna', '0954444444', 'Tanger', 'assaadiSortiesdefinitive@gmail.com', 'assaadiSortiesD', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `versements`
--

DROP TABLE IF EXISTS `versements`;
CREATE TABLE IF NOT EXISTS `versements` (
  `Code_Versement` varchar(20) NOT NULL,
  `Date_Entrer` date NOT NULL,
  `Description` text,
  `Nom_Entite_E` varchar(50) NOT NULL,
  PRIMARY KEY (`Code_Versement`),
  KEY `Nom_Entite_E` (`Nom_Entite_E`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `versements`
--

INSERT INTO `versements` (`Code_Versement`, `Date_Entrer`, `Description`, `Nom_Entite_E`) VALUES
('vrs1', '2021-07-23', NULL, 'Système d\'information'),
('vrs2', '2021-07-01', NULL, 'Département de la liquidation des prestateurs');

-- --------------------------------------------------------

--
-- Structure de la table `voyage`
--

DROP TABLE IF EXISTS `voyage`;
CREATE TABLE IF NOT EXISTS `voyage` (
  `Numero_Voyage` int(11) NOT NULL AUTO_INCREMENT,
  `Date_Sortie` date NOT NULL,
  `Poid` int(11) NOT NULL,
  `Moyen_Transport` varchar(20) NOT NULL,
  `Nombre_Voyage` int(11) DEFAULT NULL,
  `Quantite` int(11) DEFAULT NULL,
  `Commentaire` text,
  PRIMARY KEY (`Numero_Voyage`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `voyage`
--

INSERT INTO `voyage` (`Numero_Voyage`, `Date_Sortie`, `Poid`, `Moyen_Transport`, `Nombre_Voyage`, `Quantite`, `Commentaire`) VALUES
(1, '2021-09-09', 600, 'camion', 3, 1000, NULL),
(2, '2021-06-15', 500, 'camion', 1, 897, NULL);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `bordereau`
--
ALTER TABLE `bordereau`
  ADD CONSTRAINT `bordereau_ibfk_1` FOREIGN KEY (`Code_Correspondant_E`) REFERENCES `correspondant` (`Code_Correspondant`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bordereau_ibfk_3` FOREIGN KEY (`Nom_Entite_E`) REFERENCES `entites` (`Nom_Entite`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `correspondant`
--
ALTER TABLE `correspondant`
  ADD CONSTRAINT `correspondant_ibfk_1` FOREIGN KEY (`Nom_Entite_E`) REFERENCES `entites` (`Nom_Entite`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `docs`
--
ALTER TABLE `docs`
  ADD CONSTRAINT `docs_ibfk_1` FOREIGN KEY (`Numero_UA`) REFERENCES `unitearchivages` (`Numero_UA`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `etage`
--
ALTER TABLE `etage`
  ADD CONSTRAINT `etage_ibfk_1` FOREIGN KEY (`Code_Local_E`) REFERENCES `local` (`Code_Local`) ON UPDATE CASCADE,
  ADD CONSTRAINT `etage_ibfk_2` FOREIGN KEY (`Code_Salle_E`) REFERENCES `salle` (`Code_Salle`) ON UPDATE CASCADE,
  ADD CONSTRAINT `etage_ibfk_3` FOREIGN KEY (`Code_Ranger_E`) REFERENCES `ranger` (`Code_Ranger`) ON UPDATE CASCADE,
  ADD CONSTRAINT `etage_ibfk_4` FOREIGN KEY (`Code_Travet_E`) REFERENCES `travet` (`Code_Travet`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `gestion_indexation`
--
ALTER TABLE `gestion_indexation`
  ADD CONSTRAINT `gestion_indexation_ibfk_1` FOREIGN KEY (`Code_Nature_E`) REFERENCES `nature_document` (`Code_Nature`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `gestion_utilisateur`
--
ALTER TABLE `gestion_utilisateur`
  ADD CONSTRAINT `gestion_utilisateur_ibfk_1` FOREIGN KEY (`Nom_Entite_E`) REFERENCES `entites` (`Nom_Entite`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `inventaire`
--
ALTER TABLE `inventaire`
  ADD CONSTRAINT `inventaire_ibfk_1` FOREIGN KEY (`Numero_UA_E`) REFERENCES `unitearchivages` (`Numero_UA`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `nature_document`
--
ALTER TABLE `nature_document`
  ADD CONSTRAINT `nature_document_ibfk_1` FOREIGN KEY (`Nom_Entite_E`) REFERENCES `entites` (`Nom_Entite`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `nature_document_ibfk_2` FOREIGN KEY (`Code_Service_E`) REFERENCES `service` (`Code_Service`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `ranger`
--
ALTER TABLE `ranger`
  ADD CONSTRAINT `ranger_ibfk_1` FOREIGN KEY (`Code_Local_E`) REFERENCES `local` (`Code_Local`) ON UPDATE CASCADE,
  ADD CONSTRAINT `ranger_ibfk_2` FOREIGN KEY (`Code_Salle_E`) REFERENCES `salle` (`Code_Salle`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `recherche`
--
ALTER TABLE `recherche`
  ADD CONSTRAINT `recherche_ibfk_1` FOREIGN KEY (`Code_Correspondant_E`) REFERENCES `correspondant` (`Code_Correspondant`),
  ADD CONSTRAINT `recherche_ibfk_2` FOREIGN KEY (`Code_Nature_E`) REFERENCES `nature_document` (`Code_Nature`),
  ADD CONSTRAINT `recherche_ibfk_3` FOREIGN KEY (`Code_Prestation_E`) REFERENCES `prestation` (`Code_Prestation`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `recherche_ibfk_4` FOREIGN KEY (`Code_Service_E`) REFERENCES `service` (`Code_Service`),
  ADD CONSTRAINT `recherche_ibfk_5` FOREIGN KEY (`Nom_Entite_E`) REFERENCES `entites` (`Nom_Entite`),
  ADD CONSTRAINT `recherche_ibfk_6` FOREIGN KEY (`Numero_UA_E`) REFERENCES `unitearchivages` (`Numero_UA`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `recherche_ibfk_7` FOREIGN KEY (`Numero_Bordereau_E`) REFERENCES `bordereau` (`Numero_Bordereau`);

--
-- Contraintes pour la table `salle`
--
ALTER TABLE `salle`
  ADD CONSTRAINT `salle_ibfk_1` FOREIGN KEY (`Code_Local_E`) REFERENCES `local` (`Code_Local`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `service`
--
ALTER TABLE `service`
  ADD CONSTRAINT `service_ibfk_1` FOREIGN KEY (`Code_Correspondant_E`) REFERENCES `correspondant` (`Code_Correspondant`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `service_ibfk_2` FOREIGN KEY (`Nom_Entite_E`) REFERENCES `entites` (`Nom_Entite`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `sortie_definitive`
--
ALTER TABLE `sortie_definitive`
  ADD CONSTRAINT `sortie_definitive_ibfk_1` FOREIGN KEY (`Nom_Entite_E`) REFERENCES `entites` (`Nom_Entite`),
  ADD CONSTRAINT `sortie_definitive_ibfk_2` FOREIGN KEY (`Numero_Voyage_E`) REFERENCES `voyage` (`Numero_Voyage`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sortie_definitive_ibfk_3` FOREIGN KEY (`Numero_UA_E`) REFERENCES `unitearchivages` (`Numero_UA`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `travet`
--
ALTER TABLE `travet`
  ADD CONSTRAINT `travet_ibfk_1` FOREIGN KEY (`Code_Local_E`) REFERENCES `local` (`Code_Local`) ON UPDATE CASCADE,
  ADD CONSTRAINT `travet_ibfk_2` FOREIGN KEY (`Code_Salle_E`) REFERENCES `salle` (`Code_Salle`) ON UPDATE CASCADE,
  ADD CONSTRAINT `travet_ibfk_3` FOREIGN KEY (`Code_Ranger_E`) REFERENCES `ranger` (`Code_Ranger`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `unitearchivages`
--
ALTER TABLE `unitearchivages`
  ADD CONSTRAINT `unitearchivages_ibfk_1` FOREIGN KEY (`Code_Local_E`) REFERENCES `local` (`Code_Local`) ON UPDATE CASCADE,
  ADD CONSTRAINT `unitearchivages_ibfk_2` FOREIGN KEY (`Code_Salle_E`) REFERENCES `salle` (`Code_Salle`) ON UPDATE CASCADE,
  ADD CONSTRAINT `unitearchivages_ibfk_3` FOREIGN KEY (`Code_Ranger_E`) REFERENCES `ranger` (`Code_Ranger`) ON UPDATE CASCADE,
  ADD CONSTRAINT `unitearchivages_ibfk_4` FOREIGN KEY (`Code_Travet_E`) REFERENCES `travet` (`Code_Travet`) ON UPDATE CASCADE,
  ADD CONSTRAINT `unitearchivages_ibfk_5` FOREIGN KEY (`Code_Etage_E`) REFERENCES `etage` (`Code_Etage`) ON UPDATE CASCADE,
  ADD CONSTRAINT `unitearchivages_ibfk_6` FOREIGN KEY (`Nom_Entite_E`) REFERENCES `entites` (`Nom_Entite`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `unitearchivages_ibfk_7` FOREIGN KEY (`Code_Service_E`) REFERENCES `service` (`Code_Service`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `unitearchivages_ibfk_8` FOREIGN KEY (`Code_Nature_E`) REFERENCES `nature_document` (`Code_Nature`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `unitearchivages_ibfk_9` FOREIGN KEY (`Code_Versement_E`) REFERENCES `versements` (`Code_Versement`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `versements`
--
ALTER TABLE `versements`
  ADD CONSTRAINT `versements_ibfk_1` FOREIGN KEY (`Nom_Entite_E`) REFERENCES `entites` (`Nom_Entite`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
