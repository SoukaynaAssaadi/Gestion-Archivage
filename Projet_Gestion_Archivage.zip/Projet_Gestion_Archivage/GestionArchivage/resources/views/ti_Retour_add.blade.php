@extends('layouts.travaux_Interieure_Retour_Dashbord')
@section('addstyleRetour')
<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/ajoutBordereau.css') }}">
@endsection
@section('contentTravauxRetour')
<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form action="/ti_Retour_add" method="POST">
            @csrf
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Bordereau de Retour-Ajout</h3>
                    <table> 
                                   <tr>
                                       
                                       <td class="input-box">
                                         <label style="left:45px;top:50px;">Entité:</label><br>
                                           <select style="left:45px; width:380px;top:100px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;"
                                            name="entite_Bordereau" maxlength="50" required >
                                               <option disabled>--- Choisir Une Entitée ---</option>
                                               @foreach ($entites_affich as $item)
                                                   <option value="{{ $item->Nom_Entite }}">{{ $item->Nom_Entite }}</option>
                                               @endforeach
                                          </select><br><br>
                                        </td>
                                        <td class="input-box"  >
                                         <label style="left:450px;top:50px">Correspondant:</label><br>
                                           <select style="left:450px; width:380px;top:100px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;" 
                                            name="correspondant_Bordereau"maxlength="20" required >
                                               <option disabled>--- Choisir Un Correspondant ---</option>
                                               @foreach ($correspondant_affich as $item)
                                                   <option value="{{ $item->Code_Correspondant }}">{{ $item->Nom }} {{ $item->Prenom }}</option>
                                               @endforeach
                                          </select><br><br>
                                        </td>
                                      
                                   </tr>
                                   <tr>
                                  
                                      <td class="input-box">
                                              <label style="left:45px;top:130px;">Date création:</label><br>
                                              <input type="date" name="date_creation_Bordereau" style="width:180px;position:absolute;top:133px;" required />
                                      </td> 
                                  
                                  
                                       <td class="input-box">
                                             <label style="left:250px;top:130px;">Date réception:</label><br>
                                              <input type="date" name="date_reception_Bordereau"style="width:170px;left:230px;position:absolute;top:133px;"  required  />
                                       </td> 
                                      
                                   
                                   
                                      <td class="input-box"  >
                                         <label style="left:450px;top:130px">Statut:</label><br>
                                           <select style="left:450px; width:380px;top:180px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;"
                                            name="statut_Bordereau" maxlength="20" required >
                                               <option>--Votre Choix--</option>
                                               <option style="color:black;" >Initialisé</option>
                                               <option style="color:black;" >Conteneur IN</option>
                                               <option style="color:black;" >Succès</option>
                                               <option style="color:black;" >Echec</option>
                                               <option style="color:black;">Logistique</option>
                                               <option style="color:black;">Inexistant sur inventaire</option>
                                               <option style="color:black;">Document inexistant</option>
                                               <option style="color:black;">En Consultation</option>
                                          </select><br><br>
                                        </td>
                                   </tr>
                                   <tr>
                                       <td class="input-box">
                                              <label style="left:45px;top:210px;">Adresse:</label><br>
                                              <input type="text" name="adresse_Bordereu" maxlength="50"style="width:380px;position:absolute;top:215px;" required />
                                      </td> 
                                      <td class="input-box">
                                              <label style="left:450px;top:210px;">Bureau:</label><br>
                                              <input type="text" name="bureau_Bordereau" maxlength="50"style="width:380px;position:absolute;top:215px;left:430px;" required />
                                      </td> 
                                   </tr>
                                   <tr>
                                      <td class="input-box"  >
                                         <label style="left:45px;top:290px;">Etage:</label><br>
                                           <input type="text" style="left:25px; width:380px;top:295px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;"
                                            name="etage_Bordereau" maxlength="20" required >
                                               <br><br>
                                        </td>
                                        <td class="input-box">
                                              <label style="left:450px;top:290px;">Ville:</label><br>
                                              <input type="text" name="ville_Bordereau" maxlength="20"style="width:380px;position:absolute;top:295px;left:430px;" required />
                                      </td> 
                                       
                                   </tr>
                                   <tr>
                                      <td class="input-box">
                                               <label style="left:45px;top:365px;">Tél:</label><br>
                                              <input type="text" name="tel_Bordereau" maxlength="10"style="width:380px;position:absolute;top:375px;left:25px;" required />
                                      </td> 
                                      <td class="input-box">
                                              <label style="left:450px;top:370px;">Fax:</label><br>
                                              <input type="text" name="fax_Bordereau" maxlength="20"style="width:380px;position:absolute;top:375px;left:430px;" required />
                                      </td> 
                                      
                                   </tr>
                                   <tr>
                                      <td class="input-box">
                                                      <label style="left:45px;top:440px;"> Commentaires:</label><br>
                                                      <textarea name="commentaire_Bordereau" cols="25" rows="2"style="left:45px; width:780px;top:490px;position:absolute;border-radius:4px; 
                                                      margin-bottom: 5px;color:black;background-color:white;height:50px;font-size:15px;" ></textarea> 
                                      </td>
                                   </tr>    
                                   
                      </table>      
                      <button type="submit" class="btn"style="top:555px;left:740px;">Ajouter </button>     
                                    
          </div>
          </form>
        </div>

  <script>
        window.onload = function(){
            document.getElementById("popup-14").classList.toggle("active");
        }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>
@endsection
