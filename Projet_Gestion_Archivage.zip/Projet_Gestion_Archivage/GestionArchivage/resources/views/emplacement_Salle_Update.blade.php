@extends('layouts.emplacementDashbord')
@section('addstyleemplacementt')
<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/ajoutSalle.css') }}">
@endsection
@section('contentemplacement')
<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form  method="POST" action="/emplacement_Salle_Update/{{ $affiche_Salle_To_Edit[0]->Code_Salle }}">
            @csrf
            
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Salle-Modification</h3>        
                   <table>
                     
                                  <tr>
                                  
                                      <td class="input-box">
                                              <label style="left:45px">Nom:</label><br>
                                              <input type="text" name="nom_Salle_update" maxlength="20"
                                               value="{{ $affiche_Salle_To_Edit[0]->Nom }}"/>
                                      </td> 
                                  
                                  
                                       <td class="input-box">
                                             <label style="left:365px">Code:</label><br>
                                              <input type="text" name="code_Salle_update" maxlength="20" 
                                              value="{{ $affiche_Salle_To_Edit[0]->Code_Salle }}"  />
                                       </td> 
                                      
                                   </tr>
                                   <tr>
                                       <td class="input-box" style="top:160px;position:absolute;">
                                             <label style="left:20px;position:absolute;"> Places Disponibles:</label><br>
                                              <input type="number" name="place_Disponible_Salle_update" 
                                              min="1" max="9000000" value="{{ $affiche_Salle_To_Edit[0]->Place_Disponible }}"/>
                                       </td> 
                                       <td class="input-box"  >
                                         <label style="left:365px;top:160px">Local:</label><br>
                                           <select style="left:360px; width:300px;top:230px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;"
                                             maxlength="20" name="local_Salle_update" >
                                               <option style="font-size:15px;color:#000;" disabled>--- Votre Choix ---</option>
                                               @foreach ($afficher_locals as $item)
                                                   <option style="font-size:15px;" value="{{ $item->Code_Local }}">{{ $item->Code_Local }}</option>
                                               @endforeach
                                          </select><br><br>
                                        </td>
                                      
                                   </tr>
                            
                                   </table>              
                
                                   <button type="submit" class="btn">Modifier </button>
    
          </div>
          </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-14").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>

@endsection