@extends('layouts.emplacementDashbord')
@section('addstyleemplacementt')
<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/ajoutLocal.css') }}">
@endsection
@section('contentemplacement')
<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form  method="POST" action="/emplacement_Local_Update/{{ $affiche_Local_To_Edit[0]->Code_Local }}">
            @csrf
            
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Local-Modification</h3>
                   
                   <table>
                                  <tr>
                                  
                                      <td class="input-box">
                                              <label style="left:60px">Nom:</label>
                                              <input type="text" name="nom_Local_update" maxlength="20" 
                                              value="{{ $affiche_Local_To_Edit[0]->Nom }}"/>
                                              
                                      </td> 
                                  </tr>
                                  <tr>
                                       <td class="input-box">
                                             <label style="left:60px">Code:</label>
                                              <input type="text" name="code_Local_update" maxlength="20" 
                                              placeholder="Entrer un nouveau Code!" 
                                              value="{{ $affiche_Local_To_Edit[0]->Code_Local }}"  />
                                       </td> 
                                      
                                   </tr>
                                   <tr>
                                       <td class="input-box">
                                             <label style="left:60px"> Places Disponibles:</label>
                                              <input type="number" name="place_disponible_Local_update" 
                                              min="1" max="9000000" 
                                              value="{{ $affiche_Local_To_Edit[0]->Place_Disponible }}"/>
                                       </td> 
                                      
                                   </tr>
                            
                                   </table>              
                
                                   <button type="submit" class="btn">Modifier </button>

          </div>
          </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-14").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>

@endsection