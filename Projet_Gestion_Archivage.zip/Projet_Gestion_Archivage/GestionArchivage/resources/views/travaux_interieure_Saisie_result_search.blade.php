@extends('layouts.travaux_interieure_Dashbord')
@section('addstyleTravauxInterieurs')

<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/styleAdminGP.css') }}">
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
@endsection


@section('contentTravaux')
<div class="show_users">
    <table id="customers">
            <tr>
                
                
                <th>Statut</th>
                <th>N°UA</th>
                <th>Libellé</th>
                <th>Date mise à jour</th>
                <th>Nombre de page</th>
                
            </tr>
            <?php $i = 0; ?>
            @foreach ($inventaire_search as $item)
                <tr>
                
                   
                  <td><div style="width:130px;" class="cell">{{ $item->Statut  }}</div></td>
                    <td><div style="width:100px;" class="cell">{{ $item->Numero_UA_E  }}</div></td>
                    <td><div style="width:130px;" class="cell">{{ $item->Libelle }}</div></td>
                    <td><div style="width:100px;" class="cell">{{ $item->Date_Modification }}</div></td>
                    <td><div style="width:100px;" class="cell">{{ $item->Nombre_Page  }}</div></td>
                  
                </tr>
                <?php $i++; ?>
            @endforeach
  
                <?php $j = 0; ?>
                @foreach ($inventaire_count as $count)
                    
                    <?php $j++; ?>
                @endforeach
        </table>
     
        <div class="countStyle"> <?php echo $i; ?> sur <?php echo $j; ?> enregistrements</div> 
    </table>                 
    </div>



@endsection
