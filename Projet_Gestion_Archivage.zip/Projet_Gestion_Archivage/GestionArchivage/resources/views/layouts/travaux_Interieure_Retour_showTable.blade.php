@extends('layouts.travaux_Interieure_Retour_Dashbord')
@section('contentRetour')

<form method="POST" action="/ti_Retour_Bordereau">
         @csrf

         <fieldset style="width: 980px; ">
            <legend class="stylelegend">Section Recherche   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               <a href="/ti_Retour_form_add">
                  <i class="fa fa-plus" style="font-size:20px;color:#FFF"></i>
               </a>
            </legend>
            <div class="left">
               <label style="color:black;top:45px;position:absolute;">Entité:</label><br>
               <select style=" width:220px;border-radius:4px;top:70px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
               name="entite_Retour_search" maxlength="20" required>
                    <option disabled>--- Choisir Entitée ---</option>
                    @foreach ($show_Entites as $item)
                        <option value="{{ $item->Nom_Entite }}">{{ $item->Nom_Entite }}</option>
                    @endforeach
                </select>
              </div>
              <div class="left">
               <label style="color:black;left:260px;position:absolute;top:45px;"> Correspondant:</label><br>
               <select style="left:260px; width:220px;border-radius:4px;position:absolute;top:70px;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;"
                name="correspondant_Retour_search" maxlength="20" required>
                <option disabled>--- Choisir Un Correspondant ---</option>
                @foreach ($show_Correspondant as $item)
                    <option value="{{ $item->Code_Correspondant }}">{{ $item->Code_Correspondant }}</option>
                @endforeach
            </select><br><br><br>
                                            
            </div>
            <div class="left">
               <label style="position:absolute;top:45px;color:black;left:507px;">N° Bordereau:</label><br>
               <input type="text" maxlength="11" name="numero_bordereau_Retour_search"
               style=" border-radius: 5px;color: #000;top:70px;left:507px;position:absolute;width:200px;"
                required>
            </div>
            <div class="left">
               <label style="color:black;left:730px;position:absolute;top:45px;"> Statut:</label><br>
               <select style="left:730px; width:220px;border-radius:4px;position:absolute;top:70px;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;"
                name="statut_Retour_search" maxlength="20" required>
                    <option>--Votre Choix--</option>
                <option style="color:black;" >Initialisé</option>
                <option style="color:black;" >Conteneur IN</option>
                <option style="color:black;" >Succès</option>
                <option style="color:black;" >Echec</option>
                <option style="color:black;">Logistique</option>
                <option style="color:black;">Inexistant sur inventaire</option>
                <option style="color:black;">Document inexistant</option>
                <option style="color:black;">En Consultation</option>
            </select><br><br><br><br>
                                            
            </div>
            <div class="left">
               <label style="position:absolute;top:100px;color:black;left:15px;">Date du:</label><br>
               <input type="date"  name="date_du_Retour_search"
               style=" border-radius: 5px;color: #000;top:125px;left:15px;position:absolute;width:200px;" 
               required> 
            </div>
            <div class="left">
               <label style="position:absolute;top:100px;color:black;left:240px;"> au:</label><br>
               <input type="date"  name="date_au_Retour_search"
               style=" border-radius: 5px;color: #000;top:125px;left:240px;position:absolute;width:200px;"
                required>
         </div>
            
         <button type="submit" ><i class="fa fa-search" style="font-size:25px;color:black;left:920px;position:absolute;top:125px;"></i></button>
            
         </fieldset>
         @if (\Session::has('ti_Retour_Bordereau_add'))
          <div class="alert_green" style="text-align: center">
            {{ \Session::get('ti_Retour_Bordereau_add') }}
          </div>
         @endif
         @if (\Session::has('ti_Retour_Bordereau_delete'))
               <div class="alert_erreur" style="text-align: center">
                  {{ \Session::get('ti_Retour_Bordereau_delete') }}
               </div>
         @endif
         @if (\Session::has('ti_Retour_Bordereau_update'))
               <div class="alert_green" style="text-align: center">
                  {{ \Session::get('ti_Retour_Bordereau_update') }}
               </div>
         @endif 
      </form>

      @yield('contentBoredereau')
@endsection
