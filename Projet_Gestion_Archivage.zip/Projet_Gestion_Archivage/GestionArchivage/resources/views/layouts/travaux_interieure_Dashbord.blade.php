<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Accueil</title>
  <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/menu.css') }}">
  <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/styleAdmin.css') }}">
 

   @yield('addstyleTravauxInterieurs')


   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/ajoutUtilisateur.css') }}">

  <script src="{{ asset('assets/JQuery/menuJQuery.js') }}"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
   <div class="dashbord">
    <nav class="sidebar">
            <div class="text">
                Archive+
            </div>
         <div class="scrolling">
         <ul>
            <li>
                <a href="#"  class="TA-btn">
                 <i class='fas fa-users'></i>&nbsp;&nbsp;&nbsp; Travaux Intérieurs
                <span class="fas fa-caret-down TA"></span>
                </a>
                
                <ul class="TA-show" >
                   
                   
                   <li><a href="#" class="saisie-btn">Saisie
                    <span class="fas fa-caret-down saisie"></span>
                   </a>
                    <ul class="saisie-show">
                      <li><a href="/ti_Saisie_Inventaire">Inventaire</a></li>
                     
                    </ul>
                  </li>
                   
                </ul>
             </li>  
            </ul> 
      </div>
      </nav>
   </div>
   <div class="search_users_inside_list">

        @yield('contentTravauxInterieurs')
         <form method="POST" action="/ti_Saisie_Inventaire">    
         @csrf

         <fieldset style="width: 980px; ">
            <legend class="stylelegend">Section Recherche   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               
            </legend>
            <div class="left">
               <label>N°UA Du:</label><br>
               <input type="text" maxlength="20" name="search_inventaire_nUA"style="width:200px;" required>
            </div>
            <div class="left">
               <label>-Au:</label><br>
               <input type="text" maxlength="20" name="search_inventaire_Au"style="width:200px;" required>
            </div>
            
            <div class="">
               <label style="color:black;left:450px;position:absolute;">Entité</label><br>
               <select style="left:450px; width:230px;border-radius:4px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
               name="search_inventaire_entite"
              required >
                    <option disabled>--- Votre Choix ---</option>
                    @foreach ($entites as $item)
                        <option value="{{$item->Nom_Entite}}">{{$item->Nom_Entite}}</option>
                    @endforeach
                </select>
                                            
            </div>
            <div class="">
               <label style="color:black;left:700px;top:45px;position:absolute;">Service</label><br>
               <select style="left:700px; width:210px;border-radius:4px;top:70px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
               name="search_inventaire_service" required>
                    <option disabled>--- Votre Choix ---</option>
                    @foreach ($services as $item)
                        <option value="{{$item->Code_Service}}">{{$item->Code_Service}}</option>
                    @endforeach
                </select>
                                            
            </div>
            <div class="">
               <label style="color:black;left:20px;top:100px;position:absolute;">Nature Document</label><br>
               <select style="left:15px; width:250px;border-radius:4px;top:130px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;"
                 name="search_inventaire_nature" required>
                    <option disabled>--- Votre Choix ---</option>
                    @foreach ($natures as $item)
                        <option value="{{$item->Code_Nature}}">{{$item->Code_Nature}}</option>
                    @endforeach
               </select>
                                            
          </div>
         
            <div class="">
               <label style="top:100px;color:black;left:280px;position:absolute;">Année</label><br>
               <select style="left:15px; width:250px;border-radius:4px;top:130px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;top:130px;position:absolute; 
               left:280px;border-radius: 5px;
               color: #000;"
                 name="search_inventaire_annee" required>
                    <option disabled>--- Votre Choix ---</option>
                    @foreach ($annes as $item)
                        <option value="{{$item->Annee}}">{{$item->Annee}}</option>
                    @endforeach
               </select>
              
            </div>
            
          
          <button type="submit" ><i class="fa fa-search" style="font-size:20px;color:black;left:840px;position:absolute;top:130px;"></i></button>
          <a href="/ti_Saisie_Inventaire_show_table"><i class='fas fa-file-alt' style='font-size:20px;color:black;left:900px;position:absolute;top:130px;'></i></a>

 </fieldset>
      </form>
      @yield('contentTravaux')
    </div>

   
      <script>
      $('.administration-btn').click(function(){
         $('nav ul .administration-show').toggleClass("show");
         $('nav ul .first').toggleClass("rotate");
      });

      $('.emplacement-btn').click(function(){
         $('nav ul .emplacement-show').toggleClass("show1");
         $('nav ul .emplacement').toggleClass("rotate");
      });

      $('.exploitation-btn').click(function(){
         $('nav ul .exploitation-show').toggleClass("show2");
         $('nav ul .exploitation').toggleClass("rotate");
      });

      $('.TA-btn').click(function(){
         $('nav ul .TA-show').toggleClass("show3");
         $('nav ul .TA').toggleClass("rotate");
      });

      $('.integration-btn').click(function(){
         $('nav ul .integration-show').toggleClass("show4");
         $('nav ul .integration').toggleClass("rotate");
      });

      $('.recherche-btn').click(function(){
         $('nav ul .recherche-show').toggleClass("show5");
         $('nav ul .recherche').toggleClass("rotate");
      });

      $('.retour-btn').click(function(){
         $('nav ul .retour-show').toggleClass("show6");
         $('nav ul .retour').toggleClass("rotate");
      });

      $('.saisie-btn').click(function(){
         $('nav ul .saisie-show').toggleClass("show7");
         $('nav ul .resaisietour').toggleClass("rotate");
      });

      $('nav ul li').click(function(){
         $(this).addClass("active").siblings().removeClass("active");
      });

      </script>
</body>
</html>
