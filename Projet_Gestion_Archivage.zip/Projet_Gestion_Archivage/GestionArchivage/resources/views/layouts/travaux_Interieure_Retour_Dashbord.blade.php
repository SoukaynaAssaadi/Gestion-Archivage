<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Accueil</title>
  <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/menu.css') }}">
  <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/styleAdmin.css') }}">
  <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/styleAdminGP.css') }}">

  @yield('addstyleRetour')
  <script src="{{ asset('assets/JQuery/menuJQuery.js') }}"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
   <div class="dashbord">
   <nav class="sidebar">
         <div class="text">
            Archive+
         </div>
         <div class="scrolling">
         <ul>
          
              <li>
                 <a href="#"  class="TA-btn">
                 <i class='fas fa-users'></i>&nbsp;&nbsp;&nbsp; Travaux Intérieurs
                 <span class="fas fa-caret-down TA"></span>
                 </a>
                 <ul class="TA-show" >
                     <li><a href="#"  class="retour-btn">Retour
                        <span class="fas fa-caret-down retour"></span>
                       </a>
                       <ul class="retour-show">
                          <li><a href="/ti_Retour_Bordereau">Bordereau</a></li>
                           <li><a href="/ti_Retour_DocNonRetourne">Docs. non Retournés</a></li>
                       </ul>
                    </li>
                </ul>
               </li>
         </ul>
      </div>
      </nav>
   </div>
   <div class="search_users_inside_list">

@yield('contentRetour')

</div>

@yield('contentTravauxRetour')
      
      <script>
      $('.administration-btn').click(function(){
         $('nav ul .administration-show').toggleClass("show");
         $('nav ul .first').toggleClass("rotate");
      });

      $('.emplacement-btn').click(function(){
         $('nav ul .emplacement-show').toggleClass("show1");
         $('nav ul .emplacement').toggleClass("rotate");
      });

      $('.exploitation-btn').click(function(){
         $('nav ul .exploitation-show').toggleClass("show2");
         $('nav ul .exploitation').toggleClass("rotate");
      });

      $('.TA-btn').click(function(){
         $('nav ul .TA-show').toggleClass("show3");
         $('nav ul .TA').toggleClass("rotate");
      });

      $('.integration-btn').click(function(){
         $('nav ul .integration-show').toggleClass("show4");
         $('nav ul .integration').toggleClass("rotate");
      });

      $('.recherche-btn').click(function(){
         $('nav ul .recherche-show').toggleClass("show5");
         $('nav ul .recherche').toggleClass("rotate");
      });

      $('.retour-btn').click(function(){
         $('nav ul .retour-show').toggleClass("show6");
         $('nav ul .retour').toggleClass("rotate");
      });

      $('.saisie-btn').click(function(){
         $('nav ul .saisie-show').toggleClass("show7");
         $('nav ul .resaisietour').toggleClass("rotate");
      });

      $('nav ul li').click(function(){
         $(this).addClass("active").siblings().removeClass("active");
      });

      </script>
</body>
</html>

