@extends('layouts.exploitation_Sortie_Dashbord')
@section('addstyleSortie')
<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/ajoutVoyage.css') }}">
@endsection
@section('contentexploitationSortie')

<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form action="/exploitation_DD_Voyage_add" method="POST">
              @csrf
          <div class="content"style="top:290px;" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Ajout-Voyage</h3>
                    <table> 
                                   <tr>
                                       
                                       <td class="input-box"  >
                                         <label style="left:45px;top:50px;">Numero Voyage:</label><br>
                                           <input style="left:15px; width:380px;top:65px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;"type="text"
                                            name="numero_Voyage" maxlength="11" required >
                                             
                                        </td>
                                        <td class="input-box"  >
                                         <label style="left:450px;top:50px;">Date Sortie:</label><br>
                                           <input style="left:415px; width:380px;top:65px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;"type="date"
                                             name="date_Sortie_Voyage" required >
                                           
                                        </td>
                                      
                                   </tr>
                                   <tr>
                                  
                                      <td class="input-box">
                                              <label style="left:45px;top:130px;">Poid:</label><br>
                                              <input type="text" name="poid_Voyage" style="width:380px;position:absolute;top:135px;left:15px;"
                                              maxlength="11" required />
                                      </td> 
                            
                                      <td class="input-box"  >
                                         <label style="left:450px;top:130px;">Nombre Voyage:</label><br>
                                           <input style="left:415px; width:380px;top:135px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;"
                                            name="nombre_Voyage"type="text" maxlength="11" required >
                                               
                                              
                                        </td>
                                   </tr>
                                   <tr>
                                       <td class="input-box">
                                              <label style="left:45px;top:210px;">Quantité:</label><br>
                                              <input type="text" name="quantite_Voyege" maxlength="11"style="width:380px;position:absolute;top:215px;left:15px;" required />
                                      </td> 
                                      <td class="input-box">
                                              <label style="left:450px;top:210px;">Moyen Transport:</label><br>
                                              <input type="text" name="moyen_transport_Voyage" maxlength="11"
                                              style="width:380px;position:absolute;top:215px;left:415px;" required />
                                      </td> 
                          
                                   </tr>
                                   </tr>
                                   <tr>
                                      <td class="input-box">
                                                      <label style="left:45px;top:285px;font-size:18px;"> Commentaires:</label><br>
                                                      <textarea name="commentaire_Voyage" cols="25" rows="2"style="left:45px; width:790px;top:340px;position:absolute;border-radius:4px; 
                                                      margin-bottom: 5px;color:black;background-color:white;height:50px;font-size:15px;" ></textarea> 
                                      </td>
                                   </tr>    
                                  
                      </table>      
                      <button type="submit" class="btn"style="top:265px;left:740px;">Ajouter </button>     
                                    
          </div>
          </form>
        </div>


  <script>
      window.onload = function(){
        document.getElementById("popup-14").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>

@endsection

