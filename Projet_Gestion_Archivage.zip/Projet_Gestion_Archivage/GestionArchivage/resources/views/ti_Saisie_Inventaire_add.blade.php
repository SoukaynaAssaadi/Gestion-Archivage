@extends('layouts.travaux_Interieure1_Dashbord')
@section('addstyleTravauxInterieurs')
<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/ajoutInventaire.css') }}">
@endsection
@section('contentTravaux')
<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form action="/ti_Saisie_Inventaire_add" method="POST">
            @csrf
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Ajout-Inventaire</h3>

               
                               
                   
                   <table>   
                                  <tr>
                                       <td class="input-box"  >
                                         <label style="left:30px;top:50px;position:absolute;">N°UA:</label><br>
                                           <select style="left:30px; width:300px;top:100px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;" 
                                            maxlength="20" name="numero_ua_Saisie_Inventaire" required>
                                               <option disabled>--- Choisir une unité d'archivage ---</option>
                                               @foreach ($numero_ua as $item)
                                                   <option value="{{ $item->Numero_UA }}">{{ $item->Numero_UA }}</option>
                                               @endforeach
                                          </select><br><br>
                                      </td>
                                 
                                 
                                       

                                       <td class="input-box">
                                             <label style="left:370px;top:50px;position:absolute;"> Libellé:</label><br>
                                              <input type="text" name="libelle_Saisie_Inventaire"  style="left:350px;position:absolute;top:55px;width:300px;"required  />
                                       </td> 
                                      
                                      
                                  </tr>
                     
                                  <tr>
                                  
                                      <td class="input-box">
                                              <label style="left:30px;top:145px;position:absolute;">Date mise à jour:</label><br>
                                              <input type="Date" maxlength="20"style="left:5px;" name="date_mise_jour_Saisie_Inventaire" required/>
                                      </td> 
                                  
                                  
                                  
                                  
                                       <td class="input-box">
                                             <label style="left:365px;top:145px;">Nombre de page:</label><br>
                                              <input type="text" maxlength="6"style="left:350px;" 
                                              name="nb_page_Saisie_Inventaire" required  />
                                       </td> 
                                      
                                   </tr>
                                  
                            
                                   </table>              
                
                                   <button type="submit" class="btn">Ajouter</button>
          </div>
          </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-14").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>

@endsection
