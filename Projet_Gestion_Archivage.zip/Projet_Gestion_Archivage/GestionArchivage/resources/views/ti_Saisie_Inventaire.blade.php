@extends('layouts.travaux_Interieure1_Dashbord')

@section('addstyleTravauxInterieurs')
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/styleAdminGP.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/stylePopup.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
@endsection

@section('contentTravauxInterieurs')

    <div class="headerCRUDStyle"> 
        <a href="/ti_Saisie_Inventaire_form_add">
            <i class="fa fa-plus" style="font-size:20px;color:#FFF"></i>
        </a> 
    </div>
    @if (\Session::has('ti_Saisie_Inventaire_add'))
          <div class="alert_green" style="text-align: center">
            {{ \Session::get('ti_Saisie_Inventaire_add') }}
          </div>
    @endif
    @if (\Session::has('ti_Saisie_Inventaire_delete'))
          <div class="alert_erreur" style="text-align: center">
            {{ \Session::get('ti_Saisie_Inventaire_delete') }}
          </div>
    @endif
    @if (\Session::has('ti_Saisie_Inventaire_update'))
          <div class="alert_green" style="text-align: center">
            {{ \Session::get('ti_Saisie_Inventaire_update') }}
          </div>
    @endif
       
    <div class="show_users">
        <table id="customers">
            <tr>
                <th></th>
                <th>N°UA</th>
                <th>Libellé</th>
                <th>Date mise à jour</th>
                <th>Nombre de page</th>
                
            </tr>
              <?php $i = 0; ?>
            @foreach ($ti_Saisie_Inventaire as $item)
                <tr>
                
                    <td>
                      <div style="width:60px;" class="cell">
                   
                        <a href="/click_edit_Saisie_Inventaire/{{$item->id_Inventaire}}">
                            <i class="fa fa-edit" style="font-size:15px;color:#0E1C36;" ></i>
                        </a>
                        
                        <a href="/click_delete_Saisie_Inventaire/{{$item->id_Inventaire}}">
                            <i class='fas fa-trash' style='font-size:15px;color:#0E1C36;margin-left:20px;'></i>
                        </a>
                        </div>
                  </td>
                    <td><div style="width:150px;" class="cell">{{ $item->Numero_UA_E  }}</div></td>
                    <td><div style="width:250px;" class="cell">{{ $item->Libelle }}</div></td>
                    <td><div style="width:100px;" class="cell">{{ $item->Date_Modification }}</div></td>
                    <td><div style="width:100px;" class="cell">{{ $item->Nombre_Page  }}</div></td>
                  
                </tr>
                <?php $i++; ?>
            @endforeach
            
            
                
                <?php $j = 0; ?>
                @foreach ($inventaire_count as $count)
                    
                    <?php $j++; ?>
                @endforeach
        </table>
     
        <div class="countStyle"> <?php echo $i; ?> sur <?php echo $j; ?> enregistrements</div>       
    </div>

</div>
    
       
    
    
    <script>
    
        function togglePopup_P1(){
        document.getElementById("popup-1").classList.toggle("active");
        }

        function togglePopup_P2(){
        document.getElementById("popup-2").classList.toggle("active");
        }

        

    </script>
@endsection