@extends('layouts.emplacementDashbord')

@section('addstyleemplacementt')
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/styleAdminGP.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/stylePopup.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
@endsection

@section('contentemplacement')

    <div class="headerCRUDStyle"> 
        <a href="/emplacement_Affecter_form">
            <i class="fa fa-plus" style="font-size:20px;color:#FFF"></i>
        </a>
    </div>
    @if (\Session::has('Doc_add'))
    <div class="alert_green" style="text-align: center">
      {{ \Session::get('Doc_add') }}
    </div>
    @endif
    @if (\Session::has('Doc_delete'))
        <div class="alert_erreur" style="text-align: center">
            {{ \Session::get('Doc_delete') }}
        </div>
    @endif
   
    <div class="show_users">
        <table id="customers">
            <tr>
                <th></th>
                <th>N° Document</th>
                <th>N° Unité Archivage</th>
                <th>Local</th>
                <th>Salle</th>
                <th>Rangée</th>
                <th>Travée</th>
                <th>Etage</th>
                <th>Fichier</th>
                
            </tr>

            <?php $i = 0; ?>
            @foreach ($adresse_UA as $item)
                <tr>
                
                    <td>
                    <div style="width:40px;" class="cell">
                        
                        <a href="/click_delete_Doc/{{$item->Numero_Doc}}">
                            <i class='fas fa-trash' style='font-size:15px;color:#0E1C36;margin-left:10px;'></i>
                        </a>
                        </div>
                    </td>
                    <td><div style="width:40px;" class="cell">{{ $item->Numero_Doc }}</div></td>
                    <td><div style="width:40px;" class="cell">{{ $item->Numero_UA }}</div></td>
                    <td><div style="width:90px;" class="cell">{{ $item->Code_Local_E }}</div></td>
                    <td><div style="width:90px;" class="cell">{{ $item->Code_Salle_E }}</div></td>
                    <td><div style="width:90px;" class="cell">{{ $item->Code_Ranger_E }}</div></td>
                    <td><div style="width:90px;" class="cell">{{ $item->Code_Travet_E }}</div></td>
                    <td><div style="width:90px;" class="cell">{{ $item->Code_Etage_E }}</div></td>
                    <td><a href="/click_Affiche_Doc/{{ $item->Numero_Doc  }}" 
                        style="color:#0E1C36;text-decoration: none;">Voir Document</a></td>
                </tr>
                <?php $i++; ?>
            @endforeach
            
            <?php $j = 0; ?>
            @foreach ($select_all_docs_count as $count)
                
                <?php $j++; ?>
            @endforeach
        </table>
               <a href="" class="refrech">
                 <i class='fas fa-sync-alt' style='font-size:16px;color:#FFF'></i>
              </a> 
                 <div class="countStyle">   
                     <?php echo $i; ?> sur <?php echo $j; ?> enregistrements
                  </div>       
    </div>

    
       
    
    
    <script>
    
        function togglePopup_P1(){
        document.getElementById("popup-1").classList.toggle("active");
        }

        function togglePopup_P2(){
        document.getElementById("popup-2").classList.toggle("active");
        }

        

    </script>
@endsection

