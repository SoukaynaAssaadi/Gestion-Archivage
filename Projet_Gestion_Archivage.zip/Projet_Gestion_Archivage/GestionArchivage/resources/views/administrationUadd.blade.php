@extends('layouts.master1')

@section('styleAdministrationUadd')
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/styleAdministrationUadd.css') }}">
@endsection

@section('contentPopupAdminGPupdate')

   <div class="popup" id="popup-4"> 
        <div class="overlay"></div>
        <form  method="POST" action="/administrationU_ADD_data_base">
            @csrf
     <div class="content" >
         <div class="close-btn" onclick="togglePopup_P4()">×</div>

           <h3 style='font-size:30px;color:#0E1C36;'>Utilisateurs-Ajout</h3>
           <div class="custom-info">


                          <fieldset>
                           <table>
                                <legend>Infos Connexion</legend>
                                  <tr>
                                      <td class="input-box"  >
                                           <label>Login:</label><br>
                                            <input type="text" name="loginUadd" maxlength="20"/>
                                            
                                      </td> 
                                        <td class="input-box">
                                              <label>Mot de passe:</label><br>
                                              <input type="password" name="passwordUadd" maxlength="30"/>
                                      </td> 
                                   </tr> 
                                  <tr>  
                                       <td class="input-box" colpan="2">
                                           <label>Confirmation MDP:</label><br>
                                           <input type="password" name="c_passwordUadd" maxlength="30"/>
                                      </td> 
                                        <td class="input-box">
                                             <label>Date Création:</label><br>
                                              <input type="Date" name="date_creation_Uadd"/>
                                       </td> 
                                   </tr>
                                    <tr>
                                          <td class="input-box">
                                              <label>Statut:</label><br>
                                               <input type="text" name="statut_Uadd" maxlength="20"/>
                                         </td> 
         
                                            <td class="input-box">
                                                     <label>Date Début:</label><br>
                                                    <input type="Date" name="date_debut_Uadd"/>
                                           </td> 
                                   </tr>
                                     <tr>
                                            <td class="input-box">
                                                     <label>Date fin:</label><br>
                                                     <input type="Date" name="date_fin_Uadd"/>
                                             </td>
                                           <td class="input-box">
                                                     <label>Dernier changement MDP:</label><br>
                                                      <input type="Date" name="d_c_Uadd"/>
                                          </td> 
                                   </tr>
                            </table>
                            
                        </fieldset> 
                        <fieldset>
                             <legend>Infos Personnelles</legend>
                                <table>
                                     <tr>
                                       <td class="input-box" >
                                            <label>Nom:</label><br>
                                             <input type="text" name="nom_Uadd" maxlength="20"/>
                                      </td>
                                      <td class="input-box">
                                             <label>Prénom:</label><br>
                                             <input type="text" name="prenom_Uadd" maxlength="20"/>
                                     </td> 
                                     </tr> 
                                      <tr>  
                                           <td class="input-box" colpan="2">
                                                  <label>Tel:</label><br>
                                                     <input type="phone" name="tel_Uadd" maxlength="10"/>
                                           </td> 
                                           <td class="input-box">
                                                    <label>Email:</label><br>
                                                    <input type="email" name="email_Uadd" maxlength="50"/>
                                          </td> 
                                        </tr>
                                        <tr>
                                             <td class="input-box">
                                                   <label>CIN:</label><br>
                                                   <input type="text" name="cin_Uadd" maxlength="8"/>
                                           </td> 
         
                                             <td class="input-box">
                                                <label>Adresse:</label><br>
                                                <input type="text" name="adresse_Uadd" maxlength="50"/>
                                             </td> 
                                             </tr>
                                              <tr>
                                                   <td class="input-box">
                                                      <label> Ville:</label><br>
                                                             <input type="text" name="ville_Uadd" maxlength="20"/>
                                                    </td>
                                                   <td class="input-box">
                                                            <label>Pays:</label><br>
                                                            <input type="text" name="pays_Uadd" maxlength="20"/>
                                                  </td> 
                                                  </tr>
                                                   <tr>
                                                     <td class="input-box">
                                                           <label>Commentaires</label><br>
                                                          <input type="text" name="commentaires_Uadd"/>
                                                   </td> 
                                                 </tr>
                                            </table>
                                       </fieldset>
                                       
                 </div>
                 <button type="submit" type="submit" class="submit" style="width: 200px; height: 50px; color: #FFF; background-color: #0E1C36;margin-top: 20px; margin-left: 90px; border-radius: 20px;top:90%;left:41%">Ajouter</button>


        </div>
    </form>
    </div>

     <script>
         window.onload = function(){
            document.getElementById("popup-4").classList.toggle("active");
         }

        function togglePopup_P4(){
         document.getElementById("popup-4").classList.toggle("active");
         }
      </script>
@endsection
