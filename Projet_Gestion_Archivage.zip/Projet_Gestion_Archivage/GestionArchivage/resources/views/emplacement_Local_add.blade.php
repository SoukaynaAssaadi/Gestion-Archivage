@extends('layouts.emplacementDashbord')
@section('addstyleemplacementt')
<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/ajoutLocal.css') }}">
@endsection
@section('contentemplacement')
<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form action="/emplacement_Local_add" method="POST">
              @csrf
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Local-Ajout</h3>
                   
                   <table>
                                  <tr>
                                  
                                      <td class="input-box">
                                              <label style="left:60px">Nom:</label>
                                              <input type="text" name="nom_Local" maxlength="20" required/>
                                              
                                      </td> 
                                  </tr>
                                  <tr>
                                       <td class="input-box">
                                             <label style="left:60px">Code:</label>
                                              <input type="text" name="code_Local" maxlength="20" 
                                              placeholder="Entrer un nouveau Code!" required  />
                                       </td> 
                                      
                                   </tr>
                                   <tr>
                                       <td class="input-box">
                                             <label style="left:60px"> Places Disponibles:</label>
                                              <input type="number" name="place_disponible_Local" 
                                              min="1" max="9000000"/>
                                       </td> 
                                      
                                   </tr>
                            
                                   </table>              
                
                                   <button type="submit" class="btn">Ajouter </button>

          </div>
          </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-14").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>

@endsection