@extends('layouts.master')   

@section('content')

    <div class="show_users">
        @if (\Session::has('Ud'))
            <div style="width: 100%;padding-top: 10px;padding-bottom: 10px;background-color:#FFC0CB;
            color: #B22222;text-align: center;">
            {{ \Session::get('Ud') }}
            </div>
         @endif
         @if (\Session::has('impossibleS'))
            <div style="width: 100%;padding-top: 10px;padding-bottom: 10px;background-color:#FFC0CB;
            color: #B22222;text-align: center;">
            {{ \Session::get('impossibleS') }}
            </div>
         @endif
            <table id="customers">
                <tr>
                    
                    <th></th>
                    <th>Login</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>CIN</th>
                    <th>Téléphone</th>
                    <th>Adresse</th>
                </tr>

                <?php $i = 0; ?>
                @foreach ($user_search as $item)
                    <tr>
                        <td>
                            <div style="width:60px;" class="cell">
                                <a href="click_editU/{{ $item->id }}">
                                    <i class="fa fa-edit" style="font-size:15px;color:#0E1C36"></i>
                                </a>
                                &nbsp;&nbsp;&nbsp;
                                <a href="click_deleteU/{{ $item->id }}">
                                    <i class='fas fa-trash' style='font-size:15px;color:#0E1C36'></i>
                                </a>
                            </div>
                        </td>
                        <td><div style="width:170px;" class="cell">{{ $item->Login }}</div></td>
                        <td><div style="width:150px;" class="cell">{{ $item->Nom }}</div></td>
                        <td><div style="width:150px;" class="cell">{{ $item->Prenom }}</div></td>
                        <td>{{ $item->CIN }}</td>
                        <td>{{ $item->Tel }}</td>
                        <td><div style="width:150px;" class="cell">{{ $item->Adresse }}</div></td>
                    </tr>
                    <?php $i++; ?>
                @endforeach
                
                <?php $j = 0; ?>
                @foreach ($user_count as $count)
                    
                    <?php $j++; ?>
                @endforeach
            </table>
            <div class="countStyle"> <?php echo $i; ?> sur <?php echo $j; ?> enregistrements</div>       
    </div>
@endsection


