@extends('layouts.adminDashbord')

@section('addstyleAdminGP')
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/stylePopupAdmin_U_update.css') }}">
@endsection

@section('contentAdminGP')

   <div class="popup" id="popup-5"> 
        <div class="overlay"></div>
        <form method="POST" action="/administrationU_update">
          @csrf
       <div class="content" >
        <button type="submit" style="border:none;margin-left:430px;margin-top:0px;top:20px;background-color:transparent;"><i class="fa fa-check" style='font-size:25px;color:#0E1C36;'></i></button>

           <div class="close-btn" onclick="togglePopup_P5()">×</div>

           <div class="accordion_area">
                  <div class="accordion_box ">
                      <h3 class="acc_trigger" style='font-size:20px;color:black;' >Section Modification 
                        <i class="fa fa-chevron-circle-down" style="font-size:17px"></i></h3>

                        <div class="acc_container">
                        <div class="custom-info">


<fieldset>
    <legend>Infos Connexion</legend>
    
 <table>
      
      @foreach ($afficheU_To_Edit as $item)
          
      
        <tr>
            <td class="input-box"  >
                 <label>Login:</label><br>
                  <input type="text" name="loginU_update" value="{{ $item->Login }}" readonly/>
                  
            </td> 
              <td class="input-box">
                    <label>Mot de passe:</label><br>
                    <input type="password" name="passwordU_update" value="{{ $item->MDP }}"/>
            </td> 
         </tr> 
        <tr>  
             <td class="input-box" colpan="2">
                 <label>Confirmation MDP:</label><br>
                 <input type="password" name="c_passwordU_update" value="{{ $item->MDP }}"/>
            </td> 
              <td class="input-box">
                   <label>Date Création:</label><br>
                    <input type="Date" name="date_creationU_update" value="{{ $item->Date_Creation }}"/>
             </td> 
         </tr>
          <tr>
                <td class="input-box">
                    <label>Statut:</label><br>
                     <input type="text" name="statutU_update" value="{{ $item->Statut }}"/>
               </td> 

                  <td class="input-box">
                           <label>Date Début:</label><br>
                          <input type="Date" name="date_debutU_update" value="{{ $item->Date_Debut }}"/>
                 </td> 
         </tr>
           <tr>
                  <td class="input-box">
                           <label>Date fin:</label><br>
                           <input type="Date" name="date_finU_update" value="{{ $item->Date_Fin }}"/>
                   </td>
                 <td class="input-box">
                           <label>Dernier changement MDP:</label><br>
                            <input type="Date" name="d_c_U_update" value="{{ $item->Derniere_changement_MDP }}"/>
                </td> 
         </tr>
  </table>
  
</fieldset> 
<fieldset>
   <legend>Infos Personnelles</legend>
      <table>
           <tr>
             <td class="input-box" >
                  <label>Nom:</label><br>
                   <input type="text" name="nomU_update" value="{{ $item->Nom }}"/>
            </td>
            <td class="input-box">
                   <label>Prénom:</label><br>
                   <input type="text" name="prenomU_update" value="{{ $item->Prenom }}"/>
           </td> 
           </tr> 
            <tr>  
                 <td class="input-box" >
                        <label>Tel:</label><br>
                           <input type="text" name="telU_update" value="{{ $item->Tel }}"/>
                 </td> 
                 <td class="input-box">
                          <label>Email:</label><br>
                          <input type="email" name="emailU_update" value="{{ $item->Email}}"/>
                </td> 
              </tr>
              <tr>
                   <td class="input-box">
                         <label>CIN:</label><br>
                         <input type="text" name="cinU_update"  value="{{ $item->CIN}}" readonly/>
                 </td> 

                   <td class="input-box">
                      <label>Adresse:</label><br>
                      <input type="text" name="adresseU_update"  value="{{ $item->Adresse }}"/>
                   </td> 
                   </tr>
                    <tr>
                         <td class="input-box">
                            <label> Ville:</label><br>
                                   <input type="text" name="villeU_update" value="{{ $item->Ville }}"/>
                          </td>
                         <td class="input-box">
                                  <label>Pays:</label><br>
                                  <input type="text" name="paysU_update" value="{{ $item->Pays  }}"/>
                        </td> 
                        </tr>
                         <tr>
                           <td class="input-box">
                                 <label>Commentaires</label><br>
                                <input type="text" name="commentairesU_update" value="{{ $item->Commentaire }}"/>
                         </td> 
                       </tr>
                  </table>
             </fieldset>
             
         </div>
         
                        </div>
                  </div>
        </div>
                          
        <div class="accordion_area">
                  <div class="accordion_box ">
                      <h3 class="acc_trigger" style='font-size:20px;color:black;' >Liste Entité<i class="fa fa-chevron-circle-down" style="font-size:17px"></i></h3>

                        <div class="acc_container">   

                        <table id="customers">
                            <tr>
                                <th>
                                    
                                </th>
                                <th>Entité</th>
                            </tr>                             
                            <tr>
                                <td>
                                    <div style="width:60px;" class="cell">
                                        
                                    </div>
                                </td>
                                <td>
                                    <div style="width:800px;" class="cell">
                                        <select name="selectEntite" style="width: 100%; color: #000;font-size: 16px;">
                                            <option selected disabled>--- Choisir une Entite ---</option>
                                            @foreach ($entite_select as $item)
                                                <option value="{{ $item->Nom_Entite }}">{{ $item->Nom_Entite }}</option>
                                            @endforeach
                                        </select>    
                                    </div>
                                </td>
                            </tr>
                       
                @endforeach
           </table>
                    

                      
                    </div>

                       </div>
               </div>
       </div>                 
      </form>            

   </div>

   <div>


  

<script>
    window.onload = function(){
        document.getElementById("popup-5").classList.toggle("active");
    }
   function togglePopup_P5(){
    document.getElementById("popup-5").classList.toggle("active");
    }
 </script>
 <script>

$(document).ready(function(){
$('.accordion_box:first').addClass('active')
$('.accordion_box:first').children('.acc_trigger').children('i').addClass('fa-minus')
$('.accordion_box:first').children('.acc_trigger').addClass('selected').next('.acc_container').show()


  $('.acc_trigger').click(function(event){
         if($(this).hasClass('selected')){
           $(this).removeClass('selected');
           $(this).children('i').removeClass('fa-minus');
           $(this).next().slideUp();
           $(this).parent().removeClass('active');

         }else{
               $('.acc_trigger').removeClass('selected');
               $(this).addClass('selected');
               $('.acc_trigger').children('i').removeClass('fa-minus');
               $(this).children('i').addClass('fa-minus');
               $('.acc_trigger').next().slideUp();
               $(this).next().slideDown();
               $('.accordion_box').removeClass('active');
               $(this).parent().addClass('active');



         }

  });

});
    </script>
@endsection
