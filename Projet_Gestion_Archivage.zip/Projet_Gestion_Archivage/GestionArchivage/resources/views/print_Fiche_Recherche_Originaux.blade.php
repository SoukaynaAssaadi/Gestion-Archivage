<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
        .gras{
            font-size: 18px;
            font-weight: bold;
        }
        label{
            font-size:16px;
        }
    </style>
</head>
<body>
    <div style="margin-left:70px; margin-top:200px;">
        
        <table>
        <caption>
            <h2>Fiche de Recherche Originale</h2>
        </caption>
            <tr>
                <td style="width:200px;"><label>N° Prestation :</label></td>
                <td class="gras">{{$affiche_Demande_To_Print[0]->Code_Prestation_E}}</td>
            </tr>
            <tr>
                <td><label>Date Livraison :</label></td>
                <td class="gras">{{$affiche_Demande_To_Print[0]->Date_Livraison}}</td>
            </tr>
            <tr>
                <td><label>Nom Entité :</label></td>
                <td class="gras">{{$affiche_Demande_To_Print[0]->Nom_Entite_E}}</td>
            </tr>
            <tr>
                <td><label>Code Service :</label></td>
                <td class="gras">{{$affiche_Demande_To_Print[0]->Code_Service_E}}</td>
            </tr>
            <tr>
                <td><label>N° UA :</label></td>
                <td class="gras">{{$affiche_Demande_To_Print[0]->Numero_UA_E}}</td>
            </tr>
            <tr>
                <td><label>Adresse UA :</label></td>
                <td class="gras">{{$adresse_UA[0]->Code_Local_E}} * {{$adresse_UA[0]->Code_Salle_E}} * {{$adresse_UA[0]->Code_Ranger_E}}
                * {{$adresse_UA[0]->Code_Travet_E}} * {{$adresse_UA[0]->Code_Etage_E}}
                </td>
            </tr>
            <tr>
                <td><label>Libelle de Recherche:</label></td>
                <td class="gras">{{$affiche_Demande_To_Print[0]->Libelle}}</td>
            </tr>
        </table>
    </div>
      <script>
        window.print();
      </script>
</body>
</html>

