@extends('layouts.travaux_Interieure_Retour_DocNonRetourne_form')
@section('tableau')

<div class="show_users">
    <table id="customers">
                <tr>
                    
                    <th></th>
                    <th>N°</th>
                    <th>UA</th>
                    <th>Statut</th>
                    <th>Libellé</th>
                    <th>Entité</th>
                    <th>Service</th>
                    <th>Nature</th>
                    <th>Date Livraison</th>
                    
                </tr>
                
                
                <?php $i = 0; ?>
            @foreach ($DocNonRetourne_search as $item)
                <tr>
                    <td>
                        <div style="width:40px;" class="cell">
                        <a href="/click_edit_ti_Retour_DocNonRetourne_popup{{$item->Numero_Demande}}" >

                            <i class="fa fa-gears" style="font-size:19px;color:#000;">
                            </i>
                        </a>
                        </div>
                    </td>
                    <td><div style="width:60px;" class="cell">{{ $item->Numero_Demande }}</div></td>
                    <td><div style="width:50px;" class="cell">{{ $item->Numero_UA_E }}</div></td>
                    <td><div style="width:100px;" class="cell">{{ $item->Statut }}</div></td>
                    <td><div style="width:90px;" class="cell">{{ $item->Libelle }}</div></td>
                    <td><div style="width:100px;" class="cell">{{ $item->Nom_Entite_E }}</div></td>
                    <td><div style="width:90px;" class="cell">{{ $item->Code_Service_E }}</div></td>
                    <td><div style="width:80px;" class="cell">{{ $item->Code_Nature_E }}</div></td>
                    <td><div style="width:70px;" class="cell">{{ $item->Date_Livraison  }}</div></td>
                </tr>
                <?php $i++; ?>
            @endforeach
            
            <?php $j = 0; ?>
            @foreach ($DocNonRetourne_count as $count)
                
                <?php $j++; ?>
            @endforeach
        </table>
        <a href="" class="refrech">
            <i class='fas fa-sync-alt' style='font-size:16px;color:#FFF'></i>
        </a> 
        <div class="countStyle">   
             <?php echo $i; ?> sur <?php echo $j; ?> enregistrements
        </div>       
                     
    </div>

@endsection

