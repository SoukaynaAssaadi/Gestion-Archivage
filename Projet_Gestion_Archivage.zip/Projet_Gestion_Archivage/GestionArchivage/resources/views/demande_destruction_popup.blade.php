@extends('layouts.exploitation_Sortie_Dashbord')
@section('addstyleSortie')
<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/demandeDestruction.css') }}">
@endsection
@section('contentexploitationSortie')

<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form action="/cree_DDestruction" method="POST">
              @csrf
          <div class="content"style="top:290px;" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Demande de Destruction</h3>
                    <table> 
                                   <tr>
                                       
                                       <td class="input-box"  >
                                         <label style="left:45px;top:50px;">Entité:</label><br>
                                           <select style="left:45px; width:380px;top:100px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;"
                                            name="entite_DD_creer" maxlength="50" required >
                                               <option disabled>--- Choisir Entité ---</option>
                                               @foreach ($show_entite as $item)
                                                   <option value="{{ $item->Nom_Entite}}">{{ $item->Nom_Entite }}</option>
                                               @endforeach
                                          </select><br><br>
                                        </td>
                                        <td class="input-box"  >
                                         <label style="left:450px;top:50px;">Statut:</label><br>
                                           <select style="left:450px; width:380px;top:100px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;" 
                                            name="statut_DD_creer"maxlength="20" required >
                                               <option disabled>--Votre Choix--</option>
                                               <option style="color:black;" >initialisé</option>
                                               <option style="color:black;">Terminé</option>
                                               <option style="color:black;">Validé</option>
                                          </select><br><br>
                                        </td>
                                      
                                   </tr>
                                   <tr>
                                  
                                      <td class="input-box">
                                              <label style="left:45px;top:130px;">Date création:</label><br>
                                              <input type="date" name="date_creation_DD_creer" style="width:180px;position:absolute;top:133px;left:15px;" required />
                                      </td> 
                                  
                                  
                                       <td class="input-box">
                                             <label style="left:250px;top:130px;">Date prévu:</label><br>
                                              <input type="date" name="date_prevu_DD_creer"style="width:170px;left:220px;position:absolute;top:133px;"  required  />
                                       </td> 
                                      
                                   
                                   
                                      <td class="input-box"  >
                                         <label style="left:450px;top:130px;">Type:</label><br>
                                           <select style="left:450px; width:380px;top:180px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;"
                                            name="type_DD_creer" maxlength="20" required >
                                               <option disabled>--Votre Choix--</option>
                                               <option style="color:black;" >Listing des conteneurs</option>
                                               <option style="color:black;" >Ponctuel</option>
                                               <option style="color:black;" >Sortis définitive</option>
                                              
                                        </td>
                                   </tr>
                                   <tr>
                                       <td class="input-box">
                                              <label style="left:45px;top:210px;">Titre:</label><br>
                                              <input type="text" name="titre_DD_creer" maxlength="100"style="width:380px;position:absolute;top:215px;left:15px;" required />
                                      </td> 
                                      <td class="input-box">
                                              <label style="left:450px;top:210px;">N°UA:</label><br>
                                              <input type="text" name="numero_ua_DD_creer"
                                              value="{{ $Numero_UA }}" maxlength="50"
                                              style="width:380px;position:absolute;top:215px;left:420px;" readonly />
                                      </td> 
                                   </tr>
                                   </tr>
                                   <tr>
                                      <td class="input-box">
                                        <label style="left:450px;top:285px;font-size:18px;"> Commentaires:</label><br>
                                        <textarea name="commentaire_DD_creer" cols="25" rows="2"style="left:450px; width:380px;top:340px;position:absolute;border-radius:4px; 
                                        margin-bottom: 5px;color:black;background-color:white;height:50px;font-size:15px;" ></textarea> 
                                        </td>
                                        <td class="input-box">
                                                <label style="left:45px;top:285px;">Numero voyage:</label><br>
                                                <select style="left:45px; width:380px;top:340px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;"
                                            name="numero_voyage_DD_creer" maxlength="50" required >
                                               <option disabled>--- Choisir Numero de Voyage ---</option>
                                               @foreach ($show_nv as $item)
                                                   <option value="{{ $item->Numero_Voyage}}">{{ $item->Numero_Voyage }}</option>
                                               @endforeach
                                          </select><br><br>
                                                
                                        </td>
                                   </tr>    
                                  
                      </table>      
                      <button type="submit" class="btn"style="top:265px;left:740px;">Créer</button>     
                                    
          </div>
          </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-14").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>
@endsection

