@extends('layouts.travaux_Interieure_Retour_showTable')
@section('contentBoredereau')
<div class="show_users">
    <table id="customers">
                <tr>
                    
                    <th></th>
                    <th>N°</th>
                    <th>Entité</th>
                    <th>Correspondant</th>
                    <th>Statut</th>
                    <th>Date Création</th>
                    <th>Date Réception</th>
                    <th>Adresse</th>
              </tr> 
              <?php $i = 0; ?>
            @foreach ($Bordereau_search as $item)
                <tr>
                    
                <td>
                    <div style="width:60px;" class="cell">
                   
                        <a href="/click_edit_ti_Retour_Bordereau/{{$item->Numero_Bordereau}}">
                            <i class="fa fa-edit" style="font-size:15px;color:#0E1C36;" ></i>
                        </a>
                        
                        <a href="/click_delete_ti_Retour_Bordereau/{{$item->Numero_Bordereau}}'">
                            <i class='fas fa-trash' style='font-size:15px;color:#0E1C36;margin-left:20px;'></i>
                        </a>
                        </div>
                    </td>
                    <td><div style="width:70px;" class="cell">{{ $item->Numero_Bordereau }}</div></td>
                    <td><div style="width:120px;" class="cell">{{ $item->Nom_Entite_E }}</div></td>
                    <td><div style="width:180px;" class="cell">{{ $item->Nom }} {{ $item->Prenom }}</div></td>
                    <td><div style="width:100px;" class="cell">{{ $item->Statut }}</div></td>
                    <td><div style="width:100px;" class="cell">{{ $item->Date_Creation }}</div></td>
                    <td><div style="width:100px;" class="cell">{{ $item->Date_Reception }}</div></td>
                    <td><div style="width:100px;" class="cell">{{ $item->Adresse }}</div></td>
                </tr>
                <?php $i++; ?>
            @endforeach
            
            <?php $j = 0; ?>
            @foreach ($Bordereau_count as $count)
                
                <?php $j++; ?>
            @endforeach
        </table>
        <a href="" class="refrech">
            <i class='fas fa-sync-alt' style='font-size:16px;color:#FFF'></i>
        </a> 
        <div class="countStyle">   
             <?php echo $i; ?> sur <?php echo $j; ?> enregistrements
        </div>       
</div> 
           
@endsection
