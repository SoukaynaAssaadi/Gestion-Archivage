@extends('layouts.emplacementDashbord')
@section('addstyleemplacementt')
<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/ajoutLocal.css') }}">
@endsection
@section('contentemplacement')
<div class="popup" id="popup-33"> 
          <div class="overlay"></div>
          <form action="/emplacement_Affecter_form_add" method="POST" enctype="multipart/form-data">
              @csrf
          <div class="content"style="height:320px;" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Document-Ajout</h3>
                   
                   <table>
                                  <tr>
                                  
                                      <td class="input-box">
                                              <label style="left:20px; position:absolute;">N° UA:</label>
                                              <select type="text" name="numero_UA" 
                                              maxlength="20" 
                                              style="top:80px;position:absolute;left:184px;color:black;
                                              background-color:white;padding-top:3px; paddin-bottom: 3px;">
                                                  <option disabled>---Votre Choix---</option>
                                                @foreach ($select_all_UA as $item)
                                                    <option value="{{$item->Numero_UA}}">{{ $item->Numero_UA }}</option>
                                                @endforeach
                                              </select>
                                              
                                      </td> 
                                  </tr>
                                  <tr>
                                       <td class="input-box">
                                             <label style="left:20px;position:absolute;top:150px;">Choisir un  Fichier:</label>
                                             
                                              <input type="file" name="photo" maxlength="20"style="top:60px;left:120px;" 
                                               required  />
                                       </td> 
                                      
                                   </tr>
                                
                            
                                   </table>              
                
                                   <button type="submit" class="btn" style="top:90px;font-size:15px;">Enregistrer </button>

          </div>
          </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-33").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-33").classList.toggle("active");
          }
   </script>

@endsection