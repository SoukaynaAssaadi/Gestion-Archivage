@extends('layouts.adminDashbord')


@section('addstyleAdminGP')
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/styleAdminGP.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/stylePopup.css') }}">
    <script>
    window.onload = function(){
        document.getElementById("popup-2").classList.toggle("active");
    }
    </script>
@endsection


@section('contentAdminGPUpdateForm')
    <!-- Popup UPDATE GP-->
    <div class="popup" id="popup-2" >
        <div class="overlay"></div>
        <div class="content">
          <div class="close-btn" onclick="togglePopup_P2()">×</div>
          <br>
            <form action="/formUpdateGP/{{ $afficheGP_To_Edit[0]->id_Privilege }}" method="POST" id="editForm">
                @csrf
                
                <table>
                    <tr>
                        <td  class="color">Code</td>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" maxlength="20" size="20px" class="styleInput" name="codeGPupdate" value="{{ $afficheGP_To_Edit[0]->Code_Privilege }}" >
                        </td>
                    </tr>
                    <tr>
                        <td  class="color"><br>Description</td>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" maxlength="50" size="20px" class="styleInput" name="descriptionGPupdate" value="{{ $afficheGP_To_Edit[0]->Description}}">
                        </td>
                    </tr>
                    
                    <tr>
                        <td><br>
                            <input type="submit" class="btnAdd" value="Modifier">
                        </td>
                    </tr>    
                </table>
            </form>
        </div>
    </div>
    <script>
        function togglePopup_P2(){
        document.getElementById("popup-2").classList.toggle("active");
        }
    </script>
    
@endsection