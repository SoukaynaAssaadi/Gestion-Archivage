
<?php $__env->startSection('addstyleemplacementt'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajoutLocal.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentemplacement'); ?>
<div class="popup" id="popup-33"> 
          <div class="overlay"></div>
          <form action="/emplacement_Affecter_form_add" method="POST" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
          <div class="content"style="height:320px;" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Document-Ajout</h3>
                   
                   <table>
                                  <tr>
                                  
                                      <td class="input-box">
                                              <label style="left:20px; position:absolute;">N° UA:</label>
                                              <select type="text" name="numero_UA" 
                                              maxlength="20" 
                                              style="top:80px;position:absolute;left:184px;color:black;
                                              background-color:white;padding-top:3px; paddin-bottom: 3px;">
                                                  <option disabled>---Votre Choix---</option>
                                                <?php $__currentLoopData = $select_all_UA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->Numero_UA); ?>"><?php echo e($item->Numero_UA); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </select>
                                              
                                      </td> 
                                  </tr>
                                  <tr>
                                       <td class="input-box">
                                             <label style="left:20px;position:absolute;top:150px;">Choisir un  Fichier:</label>
                                             
                                              <input type="file" name="photo" maxlength="20"style="top:60px;left:120px;" 
                                               required  />
                                       </td> 
                                      
                                   </tr>
                                
                            
                                   </table>              
                
                                   <button type="submit" class="btn" style="top:90px;font-size:15px;">Enregistrer </button>

          </div>
          </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-33").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-33").classList.toggle("active");
          }
   </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.emplacementDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views//emplacement_Affecter_form.blade.php ENDPATH**/ ?>