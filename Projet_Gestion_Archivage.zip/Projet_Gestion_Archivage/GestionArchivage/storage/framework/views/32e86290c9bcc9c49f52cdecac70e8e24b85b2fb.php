

<?php $__env->startSection('styleExploitationEntiteUpdate'); ?>
 <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/nature.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

      <div class="popup" id="popup-13"> 
          <div class="overlay"></div>
          <form action="/exploitation_Nature_add" method="POST">
              <?php echo csrf_field(); ?>
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Nature-Ajout</h3>

               <table>
                               
                                  <tr>
                                      <td class="input-box"  >
                                           <label style="left:60px;font-size:18px;">Entité:</label>
                                           <br><br>
                                            <select name="entite_Nature" style="left:60px; width:265px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" required>
                                                <option style="font-size:15px;color:#000;" readonly>--- Choisir Entitée ---</option>
                                                <?php $__currentLoopData = $showEntites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option style="font-size:17px;" value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                            </select>
                                            <br>
                                            
                                      </td> 
                                  
                                  
                                        <td class="input-box">
                                              <label style="left:360px;font-size:18px;">Service:</label>
                                              <br><br>
                                            <select name="service_Nature" style="left:370px; width:265px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" required>
                                                <option style="font-size:15px;color:#000;" readonly>--- Choisir Service ---</option>
                                                <?php $__currentLoopData = $showService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option style="font-size:17px;" value="<?php echo e($item->Code_Service); ?>"><?php echo e($item->Code_Service); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                            </select>
                                            <br>
                                      </td> 
                                   </tr> 
                                   <tr>
                                        <td class="input-box">
                                             <label style="left:60px;font-size:18px;">Code:</label>
                                              <input type="text" name="code_Nature" maxlength="20" required />
                                       </td> 
                                       <td class="input-box">
                                             <label style="left:360px;font-size:18px;">Nom:</label>
                                              <input type="text" name="nom_Nature" maxlength="100" required/>
                                       </td> 
                                   </tr>
                                   <tr>
                                        <td class="input-box">
                                             <label style="left:60px;font-size:18px;">Délai Conservation:</label>
                                              <input type="text" name="delai_conservation_Nature" maxlength="4" />
                                       </td> 
                                       <td class="input-box">
                                             <label style="left:360px;font-size:18px;">Description:</label>
                                              <input type="text" name="description_Nature"  />
                                       </td> 
                                   </tr>    
                            </table>
                            

                  </table>
                  <button type="submit" class="btn" >Ajouter</button>
                   
              
                  

          

          </div>
          </form>
        </div>


  <script>
        window.onload = function(){
            document.getElementById("popup-13").classList.toggle("active");
        }
         function togglePopup(){
         document.getElementById("popup-13").classList.toggle("active");
          }
   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.exploitationEntite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Nature_add.blade.php ENDPATH**/ ?>