

<?php $__env->startSection('contentStyle'); ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentBareAjout'); ?>
    <div class="headerCRUDStyle"> 
        <a onclick="togglePopup_P1();">
            <i class="fa fa-plus" style="font-size:20px;color:#FFF"></i>
        </a>
    </div>

    <script>
        function togglePopup_P1(){
        document.getElementById("popup-3").classList.toggle("active");
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/administrationU.blade.php ENDPATH**/ ?>