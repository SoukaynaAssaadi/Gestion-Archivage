


<?php $__env->startSection('styleExploitationEntiteUpdate'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajouteService.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

      <div class="popup" id="popup-12"> 
          <div class="overlay"></div>
          <form method="POST" action="/exploitation_Service_add">
            <?php echo csrf_field(); ?>
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:20px;color:#0E1C36;'>Ajouter Service</h3>

                   <label for="fname" style="font-size:17px">Code Service:</label>
                   <input type="text" name="code_service" style='width:400px;'maxlength="20" ><br>
                   <label for="lname" style="font-size:17px">Nom:</label>
                   <input type="text"  name="nom_service" style='width:400px;'maxlength="20"><br>


                   <label style="font-size:17px;left:50px;">Code Correspondant:</label>
                   <br><br> 
                   <select name="code_Correspondant_service" style="color:#000;width:400px;height:30px;font-size:15px;">
                      <option style="font-size:15px;color:#000;" readonly>--- Choisir Code Corresponadant ---</option>
                      <?php $__currentLoopData = $show_all_correspondant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option style="font-size:17px;" value="<?php echo e($item->Code_Correspondant); ?>"><?php echo e($item->Code_Correspondant); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select><br>


                   <label style="font-size:17px;left:50px;">Nom Entite:</label>
                   <br><br>
                   <select name="nom_Entite_service" style="color:#000;width:400px;height:30px;font-size:15px;">
                    <option style="font-size:15px;" readonly>--- Choisir Entites ---</option>
                    <?php $__currentLoopData = $show_all_entites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option style="font-size:17px;" value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                  </select><br>
                  
                   <label for="description" style="font-size:17px">Description:</label>
                   <input type="text" name="description_service" style='width:400px;' >
                   <button type="submit" class="btn">Ajouter </button>

          </div>
        </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-12").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-12").classList.toggle("active");
          }
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.exploitationEntite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Service_add.blade.php ENDPATH**/ ?>