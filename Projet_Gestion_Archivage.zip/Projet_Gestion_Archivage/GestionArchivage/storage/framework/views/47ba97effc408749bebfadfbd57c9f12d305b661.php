
<?php $__env->startSection('addstyleTravauxInterieurs'); ?>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleAdminGP.css')); ?>">
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contentTravaux'); ?>
<div class="show_users">
    <table id="customers">
            <tr>
                
                
                <th>Statut</th>
                <th>N°UA</th>
                <th>Libellé</th>
                <th>Date mise à jour</th>
                <th>Nombre de page</th>
                
            </tr>
            <?php $i = 0; ?>
            <?php $__currentLoopData = $inventaire_search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                
                   
                  <td><div style="width:130px;" class="cell"><?php echo e($item->Statut); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Numero_UA_E); ?></div></td>
                    <td><div style="width:130px;" class="cell"><?php echo e($item->Libelle); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Date_Modification); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Nombre_Page); ?></div></td>
                  
                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
                <?php $j = 0; ?>
                <?php $__currentLoopData = $inventaire_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php $j++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
     
        <div class="countStyle"> <?php echo $i; ?> sur <?php echo $j; ?> enregistrements</div> 
    </table>                 
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.travaux_interieure_Dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views//travaux_interieure_Saisie_result_search.blade.php ENDPATH**/ ?>