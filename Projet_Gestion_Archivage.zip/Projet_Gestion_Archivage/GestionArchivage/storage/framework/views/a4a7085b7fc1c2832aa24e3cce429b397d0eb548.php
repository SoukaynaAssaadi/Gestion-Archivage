<!DOCTYPE html>
<html>
<head>
	<title>Registre</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
  <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700,800&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleIconPassword.css')); ?>">
</head>
<body>   
  <div class="cont">
    <div class="sub-cont">
      <div class="img">
        <div class="img-text m-up">
          <h2>Archiv+</h2>
          <p>Vous avez déjà un compte ? Connectez-vous</p>
        </div>
        <div class="pos">
          <div class="img-btn">
            <span class="m-up">
              <a href="/login" style="position:absolute; z-index: 5; text-decoration:none; color:#fff">
                SE CONNECTER
              </a>
            </span>
          </div>
        </div>
      </div>

      <div class="form sign-up">
        <form method="POST" action="/registre">
           <?php echo csrf_field(); ?>
        <h2>Inscription</h2>
        <table style= "border-collapse: separate;
        border-spacing:25px 0px;" class="form-group">
          <tr>
            <td>
              <label>
                <input type="text" placeholder="Nom" maxlength="20" name="nom" class="form-control" value="<?php echo e(old('nom')); ?>">
                <div class="alert-danger"><?php echo e($errors->first('nom')); ?></div>
              </label>
            </td>
            <td>
              <label>
                <input type="text" placeholder="Prénom" maxlength="20" name="prenom" class="form-control" value="<?php echo e(old('prenom')); ?>">
                <div class="alert-danger"><?php echo e($errors->first('prenom')); ?></div>
              </label>
            </td>
          </tr>
          <tr>
            <td>
              <label>
                <input type="text" placeholder="CIN" maxlength="8" name="cin" class="form-control" value="<?php echo e(old('cin')); ?>">
                <div class="alert-danger"><?php echo e($errors->first('cin')); ?></div>
              </label> 
            </td>
            <td>
              <label>
                <input type="phone" placeholder="Téléphone" maxlength="10" name="tel" class="form-control" value="<?php echo e(old('tel')); ?>">
                <div class="alert-danger"><?php echo e($errors->first('tel')); ?></div>
              </label>
            </td>
          </tr>
          <div>
          <tr>
              <td colspan="2">
                <label style="width:100%">
                  <input type="email" placeholder="Email" style="width: 100%" maxlength="50" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
                  <div class="alert-danger"><?php echo e($errors->first('email')); ?></div>
                </label>
              </td>
          </tr>
          <tr>
            <td colspan="2">
              <label style="width:100%">
                <input type="address" placeholder="Adresse" style="width: 100%" maxlength="50" name="adresse" class="form-control" value="<?php echo e(old('adresse')); ?>">
                <div class="alert-danger"><?php echo e($errors->first('prenom')); ?></div>
              </label>
            </td>
          </tr>
          <tr>
            <td colspan="2">
              <label style="width:100%">
                <input type="text" placeholder="Login" style="width: 100%" maxlength="20" name="login_Registre"class="form-control" value="<?php echo e(old('login_Registre')); ?>">
                <div class="alert-danger"><?php echo e($errors->first('login_Registre')); ?></div>
              </label>
            </td>
          </tr>
          <tr>
            <td>
              <label style="width:100%" class="labelPos">
                <input type="password" placeholder="Mot de passe" style="width: 100%" maxlength="20" name="password_Registre" class="form-control" title="MDP" value="<?php echo e(old('password_Registre')); ?>" id="passwordPos">
                <div class="password-icon">
                  <i data-feather="eye" class="poseEye"></i>
                  <i data-feather="eye-off"></i>
                </div>
              </label>
              <div class="alert-danger" style="text-align: center"><?php echo e($errors->first('password_Registre')); ?></div>
            </td>
            <td>
              <label style="width:100%" class="labelPos">
                <input type="password" placeholder="Confirmer le mot de passe" style="width: 100%" maxlength="20" name="confirmer_password_Registre" class="form-control" title="MDP" value="<?php echo e(old('confirmer_password_Registre')); ?>" id="passwordPos">
                <div class="password-icon">
                  <i data-feather="eye" class="poseEye"></i>
                  <i data-feather="eye-off"></i>
                </div>
              </label>
              <div class="alert-danger"  style="text-align: center"><?php echo e($errors->first('confirmer_password_Registre')); ?></div>
            </td>
          </tr>
        </div>
        </table> 
        <div class="pos_button">
          <button type="submit" class="submit">S'INSCRIRE</button>
        </div>
        </form>
      </div>
    </div>
  </div>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/icon.js')); ?>"></script>
  <script>
    feather.replace();
    </script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/styleIconPassword.js')); ?>"></script>
</body>
</html><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/register.blade.php ENDPATH**/ ?>