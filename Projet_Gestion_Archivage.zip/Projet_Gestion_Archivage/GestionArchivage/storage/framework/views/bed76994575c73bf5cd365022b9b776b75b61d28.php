
<?php $__env->startSection('addstyleemplacementt'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajoutEtage.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentemplacement'); ?>
<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form action="/emplacement_Etage_add" method="POST">
              <?php echo csrf_field(); ?>
          <div class="content" style="height:550px" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Etage-Ajout</h3>      
                   <table>
                                  <tr>
                                      <td class="input-box">
                                              <label style="left:45px">Code:</label><br>
                                              <input type="text" name="code_Etage" 
                                              placeholder="Entrer un nouveau code d'Etage !" maxlength="20" required />
                                      </td> 
                                  
                                  
                                       <td class="input-box">
                                             <label style="left:365px">Nb place:</label><br>
                                              <input type="number" name="nb_place_Etage" min="1" max="9000000" />
                                       </td> 
                                      
                                   </tr>
                                   <tr>
                                       
                                       <td class="input-box"  >
                                         <label style="left:45px;top:160px;">Local:</label><br>
                                           <select style="left:45px; width:300px;top:230px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;" 
                                            maxlength="20" name="local_Etage" required >
                                               <option style="font-size:15px;color:#000;" disabled>--- Votre Choix ---</option>
                                               <?php $__currentLoopData = $affiche_L; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option style="font-size:15px;" value="<?php echo e($item->Code_Local); ?>"><?php echo e($item->Code_Local); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select><br><br>
                                        </td>
                                        <td class="input-box"  >
                                         <label style="left:365px;top:160px">Salle:</label><br>
                                           <select style="left:365px; width:300px;top:230px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;" 
                                            maxlength="20" name="salle_Etage" required >
                                               <option style="font-size:15px;color:#000;" disabled>--- Votre Choix ---</option>
                                               <?php $__currentLoopData = $affiche_S; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option style="font-size:15px;" value="<?php echo e($item->Code_Salle); ?>"><?php echo e($item->Code_Salle); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select><br><br>
                                        </td>
                                      
                                   </tr>
                                   <tr>
                                   <td class="input-box"  >
                                         <label style="left:45px;top:270px;">Rangée:</label><br>
                                           <select style="left:45px; width:300px;top:335px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;" 
                                            maxlength="20" name="ranger_Etage" required  >
                                                <option style="font-size:15px;color:#000;" disabled>--- Votre Choix ---</option>
                                                <?php $__currentLoopData = $affiche_R; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option style="font-size:15px;" value="<?php echo e($item->Code_Ranger); ?>"><?php echo e($item->Code_Ranger); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select><br><br>
                                        </td>
                                        <td class="input-box"  >
                                         <label style="left:365px;top:265px">Travée:</label><br>
                                           <select style="left:365px; width:300px;top:335px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;"
                                            name="travet_Etage" maxlength="20" required >
                                               <option style="font-size:15px;color:#000;" disabled>--- Votre Choix ---</option>
                                               <?php $__currentLoopData = $affiche_T; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option style="font-size:15px;" value="<?php echo e($item->Code_Travet); ?>"><?php echo e($item->Code_Travet); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select><br><br>
                                        </td>
                                       
                                   </tr>
                                   <tr>
                                      <td class="input-box">
                                                      <label style="left:45px;top:360px;"> Description:</label><br>
                                                      <textarea name="description_Etage" cols="25" rows="2"style="left:45px; width:615px;top:430px;position:absolute;border-radius:4px; 
                                                      margin-bottom: 5px;color:black;background-color:white;height:50px;font-size:15px;" ></textarea> 
                                                         
                                                      
                                       </td>
                                   </tr>
                            
                                   </table>        
                                   <button type="submit" class="btn"style="top:135px;">Ajouter </button>      
                
          </div>
          </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-14").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.emplacementDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/emplacement_Etage_add.blade.php ENDPATH**/ ?>