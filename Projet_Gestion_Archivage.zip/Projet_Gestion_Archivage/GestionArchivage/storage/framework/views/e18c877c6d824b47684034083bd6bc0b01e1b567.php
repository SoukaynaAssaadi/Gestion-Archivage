<!DOCTYPE html>
<html>
<head>
    <title>tessssssssst</title>
</head>
<body>
    <h4>pppppppppppppppp</h4>
</body>
</html>    <?php /**PATH C:\wamp\www\GestionArchivage\resources\views/test.blade.php ENDPATH**/ ?>