
<?php $__env->startSection('contentBoredereau'); ?>
<div class="show_users">
    <table id="customers">
                <tr>
                    
                    <th></th>
                    <th>N°</th>
                    <th>Entité</th>
                    <th>Correspondant</th>
                    <th>Statut</th>
                    <th>Date Création</th>
                    <th>Date Réception</th>
                    <th>Adresse</th>
              </tr> 
              <?php $i = 0; ?>
            <?php $__currentLoopData = $Bordereau_search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                <td>
                    <div style="width:60px;" class="cell">
                   
                        <a href="/click_edit_ti_Retour_Bordereau/<?php echo e($item->Numero_Bordereau); ?>">
                            <i class="fa fa-edit" style="font-size:15px;color:#0E1C36;" ></i>
                        </a>
                        
                        <a href="/click_delete_ti_Retour_Bordereau/<?php echo e($item->Numero_Bordereau); ?>'">
                            <i class='fas fa-trash' style='font-size:15px;color:#0E1C36;margin-left:20px;'></i>
                        </a>
                        </div>
                    </td>
                    <td><div style="width:70px;" class="cell"><?php echo e($item->Numero_Bordereau); ?></div></td>
                    <td><div style="width:120px;" class="cell"><?php echo e($item->Nom_Entite_E); ?></div></td>
                    <td><div style="width:180px;" class="cell"><?php echo e($item->Nom); ?> <?php echo e($item->Prenom); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Statut); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Date_Creation); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Date_Reception); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Adresse); ?></div></td>
                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $j = 0; ?>
            <?php $__currentLoopData = $Bordereau_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php $j++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <a href="" class="refrech">
            <i class='fas fa-sync-alt' style='font-size:16px;color:#FFF'></i>
        </a> 
        <div class="countStyle">   
             <?php echo $i; ?> sur <?php echo $j; ?> enregistrements
        </div>       
</div> 
           
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.travaux_Interieure_Retour_showTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views//travaux_interieure_Retour_result_search.blade.php ENDPATH**/ ?>