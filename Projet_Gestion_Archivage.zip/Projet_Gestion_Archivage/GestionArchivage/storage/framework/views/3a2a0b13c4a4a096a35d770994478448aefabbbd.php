
<?php $__env->startSection('addstyleRecherche'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/demandeRecherche.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentTravauxRecherche'); ?>

 <div class="popup" id="popup-14"> 
    <div class="overlay"></div>
       <form action="/ti_Recherche_DR_Update/<?php echo e($affiche_Recherche_DR_To_Edit[0]->Numero_Demande); ?>" method="POST">
           <?php echo csrf_field(); ?>
         <div class="content"  >
                 <div class="close-btn" onclick="togglePopup()">×</div>

                  <h3 style='font-size:20px;color:#0E1C36;'>Demande Recherche-Modification</h3>

                  <table>

                     <tr>
                                       
                                       <td class="input-box"  >
                                         <label style="left:30px;top:75px;color:black;position:absolute;">Entité:</label><br>
                                           <select style="left:25px; width:230px;top:100px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;" maxlength="20"
                                            name="entite_DR_update" required>
                                               <option disabled>--- Choisir Entité ---</option>
                                               <?php $__currentLoopData = $entites_show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select><br><br>
                                        </td>
                                        <td class="input-box"  >
                                         <label style="left:270px;top:75px;color:black;position:absolute;">Service:</label><br>
                                           <select style="left:270px; width:230px;top:100px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;" maxlength="20" 
                                            name="service_DR_update" required >
                                               <option disabled>--- Choisir Service ---</option>
                                               <?php $__currentLoopData = $services_show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option value="<?php echo e($item->Code_Service); ?>"><?php echo e($item->Code_Service); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select><br><br>
                                        </td>
                                        <td class="input-box"  >
                                         <label style="left:520px;top:75px;color:black;position:absolute;">Nature:</label><br>
                                           <select style="left:515px; width:230px;top:100px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;" maxlength="20"
                                            name="nature_DR_update" required  >
                                               <option disabled>--- Choisir Nature de Document ---</option>
                                               <?php $__currentLoopData = $natures_show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option value="<?php echo e($item->Code_Nature); ?>"><?php echo e($item->Code_Nature); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select><br><br>
                                        </td>
                                        
                                      <td class="input-box">
                                              <label style="margin-left:735px;color:black;">Année:</label><br>
                                              <input type="text"  maxlength="4"
                                               style="left:760px;position:absolute;width:230px;height:35px;border-color:gray;border-radius:4px;
                                               color:#000;"
                                               name="annee_DR_update" maxlength="4" 
                                               value="<?php echo e($affiche_Recherche_DR_To_Edit[0]->Annee); ?>" />
                                      </td> 
                      </tr>
                      <tr>
                                       <td class="input-box"  >
                                         <label style="left:30px;top:145px;color:black;position:absolute;">Correspondant:</label><br>
                                           <select style="left:25px; width:230px;top:170px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;" maxlength="20"  
                                            name="correspondant_DR_update" required >
                                               <option disabled>--- Choisir un Correspondant ---</option>
                                               <?php $__currentLoopData = $correspondant_show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option value="<?php echo e($item->Code_Correspondant); ?>"><?php echo e($item->Code_Correspondant); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select><br><br>
                                       </td>
                                       <td class="input-box"  >
                                         <label style="left:270px;top:145px;color:black;position:absolute;">Statut:</label><br>
                                           <select style="left:270px; width:230px;top:170px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;" maxlength="20" 
                                            name="statut_DR_update" required>
                                               <option>Initialisé</option>
                                               <option>Inexistant sur Inventaire</option>
                                               <option>Conteneur In</option>
                                               <option>Echec</option>
                                               <option>Logistique</option>
                                               <option>Succés</option>
                                               <option>Document Inexistant</option>
                                               <option>En Consultation</option>
                                          </select><br><br>
                                        </td>
                                        <td class="input-box"  >
                                         <label style="left:520px;top:145px;color:black;position:absolute;">Type:</label><br>
                                           <input type="text" style="left:515px; width:230px;top:170px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;color:#000;" maxlength="20" 
                                            name="type_DR_update" value="<?php echo e($affiche_Recherche_DR_To_Edit[0]->Type); ?>"  >
                                               
                                        </td>
                                        <td class="input-box"  >
                                         <label style="left:760px;top:145px;color:black;position:absolute;">Urgence:</label><br>
                                           <input type="text" style="left:760px; width:230px;top:170px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;" maxlength="20" 
                                            name="urgence_DR_update" value="<?php echo e($affiche_Recherche_DR_To_Edit[0]->Urgence); ?>" >
                                               
                                        </td>



                      </tr>
                      <tr>
                                        <td class="input-box"  >
                                         <label style="left:30px;top:215px;color:black;position:absolute;">Prestation:</label><br>
                                           <select style="left:25px; width:230px;top:238px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;" maxlength="20"
                                             name="prestation_DR_update" required >
                                               <option disabled>--- Choisir Code Prestation ---</option>
                                               <?php $__currentLoopData = $prestation_show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option value="<?php echo e($item->Code_Prestation); ?>"><?php echo e($item->Code_Prestation); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select><br><br>
                                       </td>
                                       <td class="input-box">
                                              <label style="margin-left:250px;color:black;top:215px;position:absolute;">Email:</label><br>
                                              <input type="text" name="email_DR_update" maxlength="50" 
                                              style="color:#000;left:270px;top:239px;position:absolute;width:230px;
                                              height:35px;border-color:gray;border-radius:4px;"
                                              value="<?php echo e($affiche_Recherche_DR_To_Edit[0]->Email); ?>" />
                                       </td> 
                                       <td class="input-box">
                                              <label style="margin-left:490px;color:black;top:215px;position:absolute;">N°Demande:</label><br>
                                              <input type="text" name="numero_demande_DR_update" maxlength="11" placeholder="Entrer un nouveau numero de demande!"
                                              style="color:#000;left:515px;top:239px;position:absolute;
                                              width:230px;height:35px;border-color:gray;border-radius:4px;" 
                                              value="<?php echo e($affiche_Recherche_DR_To_Edit[0]->Numero_Demande); ?>" />
                                       </td> 
                                       <td class="input-box">
                                              <label style="margin-left:340px;color:black;top:215px;position:absolute;">Demandeur:</label><br>
                                              <input type="text" name="demandeur_DR_update" maxlength="50" 
                                              style="color:#000;left:760px;top:239px;position:absolute;width:230px;
                                              height:35px;border-color:gray;border-radius:4px;" 
                                              value="<?php echo e($affiche_Recherche_DR_To_Edit[0]->Demandeur); ?>" />
                                       </td> 
                      </tr>
                      <tr> 
                                       <td class="input-box">
                                              <label style="margin-left:10px;color:black;top:285px;position:absolute;">Mode Livraison:</label><br>
                                              <input type="text" name="mode_livraison_DR_update" maxlength="50" 
                                              style="color:#000;left:25px;top:310px;position:absolute;width:230px;
                                              height:35px;border-color:gray;border-radius:4px;" 
                                               	value="<?php echo e($affiche_Recherche_DR_To_Edit[0]->Mode_Livraison); ?>"  />
                                       </td> 
                                       <td class="input-box">
                                              <label style="margin-left:250px;color:black;top:285px;position:absolute;">Adresse Correspondant:</label><br>
                                              <input type="text" name="adresse_correspondant_DR_update" maxlength="50" 
                                              style="color:#000;left:270px;top:310px;position:absolute;width:230px;
                                              height:35px;border-color:gray;border-radius:4px;" 
                                              value="<?php echo e($affiche_Recherche_DR_To_Edit[0]->Adresse_Correspondant); ?>" />
                                       </td> 
                                       <td class="input-box">
                                              <label style="margin-left:490px;color:black;top:285px;position:absolute;">Date Réception:</label><br>
                                              <input type="Date" name="date_reception_DR_update"  
                                              style="color:#000;left:515px;top:310px;position:absolute;width:230px;
                                              height:35px;border-color:gray;border-radius:4px;" 
                                              value="<?php echo e($affiche_Recherche_DR_To_Edit[0]->Date_Reception); ?>" />
                                       </td> 
                                       <td class="input-box">
                                              <label style="margin-left:340px;color:black;top:285px;position:absolute;">Date Livraison Prévu:</label><br>
                                              <input type="Date" name="date_livraison_prevu_DR_update" 
                                               style="color:#000;left:760px;top:310px;position:absolute;width:230px;
                                               height:35px;border-color:gray;border-radius:4px;" 
                                               value="<?php echo e($affiche_Recherche_DR_To_Edit[0]->Date_Livraison); ?>" />
                                       </td> 
                                      
                                      </tr>
                                      <tr>
                      
                                       <td class="input-box">
                                          <label style="margin-left:10px;color:black;top:355px;position:absolute;">Numero UA:</label><br>
                                          <select maxlength="50" 
                                          style="left:25px;top:380px;position:absolute;width:230px;height:35px;
                                          border-color:gray;border-radius:4px;color:#000;"
                                          name="numero_uarchiv_DR_update" required >
                                          <option disabled>--- Choisir Unité archivage ---</option>
                                               <?php $__currentLoopData = $ua_show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option value="<?php echo e($item->Numero_UA); ?>"><?php echo e($item->Numero_UA); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                       </td> 

                                        <td class="input-box">
                                            <label style="left:270px;color:black;top:355px;position:absolute;"> Libellé:</label><br>
                                            <textarea name="libelle_DR_update" cols="25" rows="2"style="left:270px;top:380px; width:230px;position:absolute;border-radius:4px; 
                                              margin-bottom: 5px;color:black;background-color:white;height:40px;font-size:15px;" 
                                              ><?php echo e($affiche_Recherche_DR_To_Edit[0]->Libelle); ?></textarea> 
                                                        
                                        </td>
                                       
                                       <td class="input-box"  >
                                        <label style="left:520px;top:355px;color:black;position:absolute;">N°Bordereau:</label><br>
                                          <select style="left:520px; width:230px;top:380px;position:absolute;border-radius:4px; 
                                           margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;"
                                            maxlength="20" name="numero_bordereau_DR_update" required  >
                                            <option disabled>--- Choisir Un Bordereau ---</option>
                                            <?php $__currentLoopData = $bordereau; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->Numero_Bordereau); ?>"><?php echo e($item->Numero_Bordereau); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </select><br><br>
                                       </td>
                                      
                                      <td class="input-box">
                                          <label style="left:760px;color:black;top:355px;position:absolute;"> Notes:</label><br>
                                         <textarea  name="notes_DR_update" cols="25" rows="2"style="left:760px;top:380px; width:230px;position:absolute;border-radius:4px; 
                                           margin-bottom: 5px;color:black;background-color:white;height:40px;font-size:15px;" >
                                           <?php echo e($affiche_Recherche_DR_To_Edit[0]->Notes); ?></textarea> 
                                                      
                                      </td>
                      </tr>

                      
                  </table>     
                  <button style="width: 150px; height: 50px; color: #FFF; background-color: #0E1C36;margin-top: 213px; margin-left: 390px; border-radius: 20px;" type="submit">
        <span style="font-size: 15px;padding-bottom: 5px;">Modifier</span></button>   


          </div>
      </form>
</div>

  <script>
      window.onload = function(){
        document.getElementById("popup-14").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>
        
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.travaux_Interieure_Recherche_Dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/ti_Recherche_DR_Update.blade.php ENDPATH**/ ?>