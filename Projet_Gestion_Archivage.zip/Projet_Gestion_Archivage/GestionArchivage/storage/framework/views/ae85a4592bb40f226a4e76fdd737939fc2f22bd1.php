
<?php $__env->startSection('traitement'); ?>
<div class="show_users">
    <table id="customers">
                <tr>
                    
                    <th></th>
                    <th>N°</th>
                    <th>Type</th>
                    <th>Statut</th>
                    <th>Titre</th>
                    <th>Date Création</th>
                    <th>Date Prévu</th>
                    <th>Entité</th>
              </tr> 
              <?php $i = 0; ?>
            <?php $__currentLoopData = $sortie_definitive_search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                <td>
                    <div style="width:60px;" class="cell">
                   
                        <a href="/click_edit_exploitation_Sortie_Definitive/<?php echo e($item->Numero_Sortie_Definitive); ?>">
                            <i class="fa fa-edit" style="font-size:15px;color:#0E1C36;" ></i>
                        </a>
                        
                        <a href="/click_delete_exploitation_Sortie_Definitive/<?php echo e($item->Numero_Sortie_Definitive); ?>">
                            <i class='fas fa-trash' style='font-size:15px;color:#0E1C36;margin-left:20px;'></i>
                        </a>
                        </div>
                    </td>
                    <td><div style="width:70px;" class="cell"><?php echo e($item->Numero_Sortie_Definitive); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Type); ?></div></td>
                    <td><div style="width:90px;" class="cell"><?php echo e($item->Statut); ?></div></td>
                    <td><div style="width:90px;" class="cell"><?php echo e($item->Titre); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Date_Creation); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Date_Prevu); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Nom_Entite_E); ?></div></td>
                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $j = 0; ?>
            <?php $__currentLoopData = $sortie_definitive_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php $j++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <a href="" class="refrech">
            <i class='fas fa-sync-alt' style='font-size:16px;color:#FFF'></i>
        </a> 
        <div class="countStyle">   
             <?php echo $i; ?> sur <?php echo $j; ?> enregistrements
        </div>       
              
</div> 
           
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.exploitation_DemandeDestruction_recherche_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views//exploitation_DemandeDestruction_result_search.blade.php ENDPATH**/ ?>