   

<?php $__env->startSection('content'); ?>

    <div class="show_users">
        <?php if(\Session::has('Ud')): ?>
            <div class="alert_erreur" style="text-align: center">
            <?php echo e(\Session::get('Ud')); ?>

            </div>
         <?php endif; ?>
            <table id="customers">
                <tr>
                    
                    <th></th>
                    <th>Login</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>CIN</th>
                    <th>Téléphone</th>
                    <th>Adresse</th>
                </tr>

                <?php $i = 0; ?>
                <?php $__currentLoopData = $user_search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div style="width:60px;" class="cell">
                                <a href="click_editU/<?php echo e($item->id); ?>">
                                    <i class="fa fa-edit" style="font-size:15px;color:#0E1C36"></i>
                                </a>
                                &nbsp;&nbsp;&nbsp;
                                <a href="click_deleteU/<?php echo e($item->id); ?>">
                                    <i class='fas fa-trash' style='font-size:15px;color:#0E1C36'></i>
                                </a>
                            </div>
                        </td>
                        <td><div style="width:170px;" class="cell"><?php echo e($item->Login); ?></div></td>
                        <td><div style="width:150px;" class="cell"><?php echo e($item->Nom); ?></div></td>
                        <td><div style="width:150px;" class="cell"><?php echo e($item->Prenom); ?></div></td>
                        <td><?php echo e($item->CIN); ?></td>
                        <td><?php echo e($item->Tel); ?></td>
                        <td><div style="width:150px;" class="cell"><?php echo e($item->Adresse); ?></div></td>
                    </tr>
                    <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php $j = 0; ?>
                <?php $__currentLoopData = $user_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php $j++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div class="countStyle"> <?php echo $i; ?> sur <?php echo $j; ?> enregistrements</div>       
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/administration.blade.php ENDPATH**/ ?>