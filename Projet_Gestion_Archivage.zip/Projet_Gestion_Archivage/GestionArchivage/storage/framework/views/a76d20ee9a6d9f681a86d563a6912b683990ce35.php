

<?php $__env->startSection('contentResultRecherche'); ?>
<div class="show_users">
    
<table id="customers">
    
                <tr>
                    
                    <th></th>
                    <th>N° Demande</th>
                    <th>Date Livraison</th>
                    <th>Entité</th>
                    <th>Corresp</th>
                    <th>N°UA</th>
                    <th>Libellé</th>
                    <th>Service</th>
                    <th>Nature Document</th>
                    <th>Statut</th>
                    
                </tr>
                <?php $i=0;?>
                <?php $__currentLoopData = $DR_search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                     <td>   
                            <div style="width:60px;" class="cell">
                   
                                <a href="/click_edit_ti_Recherche_DR/<?php echo e($item->Numero_Demande); ?>">
                                    <i class="fa fa-edit" style="font-size:15px;color:#0E1C36;" ></i>
                                </a>
                                
                                <a href="/click_delete_ti_Recherche_DR/<?php echo e($item->Numero_Demande); ?>">
                                    <i class='fas fa-trash' style='font-size:15px;color:#0E1C36;margin-left:20px;'></i>
                                </a>
                            </div>
                        </td>
                        <td><div style="width:50px;" class="cell"><?php echo e($item->Numero_Demande); ?></div></td>
                        <td><div style="width:80px;" class="cell"><?php echo e($item->Date_Livraison); ?></div></td>
                        <td><div style="width:90px;" class="cell"><?php echo e($item->Nom_Entite_E); ?></div></td>
                        <td><div style="width:80px;" class="cell"><?php echo e($item->Code_Correspondant_E); ?></div></td>
                        <td><div style="width:80px;" class="cell"><?php echo e($item->Numero_UA_E); ?></div></td>
                        <td><div style="width:90px;" class="cell"><?php echo e($item->Libelle); ?></div></td>
                        
                        <td><div style="width:80px;" class="cell"><?php echo e($item->Code_Service_E); ?></div></td>
                        <td><div style="width:70px;" class="cell"><?php echo e($item->Code_Nature_E); ?></div></td>
                        <td><div style="width:80px;" class="cell"><?php echo e($item->Statut); ?></div></td>    
                    
                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $j = 0; ?>
            <?php $__currentLoopData = $DR_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php $j++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table> 
                <a href="" class="refrech">
                    <i class='fas fa-sync-alt' style='font-size:16px;color:#FFF;'
                    ></i>
                 </a> 
                    <div class="countStyle">   
                        
                        <?php echo $i; ?> sur <?php echo $j; ?> enregistrements
                     </div>  

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.travaux_Interieure_Recherche_showTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views//travaux_interieure_Recherche_result_search.blade.php ENDPATH**/ ?>