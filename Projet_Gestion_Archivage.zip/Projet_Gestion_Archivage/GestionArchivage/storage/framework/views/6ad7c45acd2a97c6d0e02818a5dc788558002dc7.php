

<?php $__env->startSection('styleAdministrationUadd'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/entiteUpdate.css')); ?>">
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentPopupAdminGPupdate'); ?>
<div class="popup" id="popup-11" >
        <div class="overlay"></div>
        <form  method="POST" action="/administration_Entite_update/<?php echo e($affiche_Entite_To_Edit[0]->Nom_Entite); ?>">
          <?php echo csrf_field(); ?>
        <div class="content">
        
        <button type="submit" class="submit" style="width: 200px; height: 50px; color: #FFF; background-color: #0E1C36;margin-top: 20px;
         margin-left: 575px; border-radius: 20px;top:2%;left:41%">Modifier</button>
        
           

           <div class="accordion_area">
                  <div class="accordion_box ">
                      <h3 class="acc_trigger" style='font-size:20px;color:black;width:950px;' >Entité<i class="fa fa-chevron-circle-down" style="font-size:17px"></i></h3>

                        <div class="acc_container">
                            
                        <div class="custom-info">

                            
                               <fieldset>
                                  <table>
                                    <legend>Infos Entité</legend>
                                      <tr>
                                           <td class="input-box"  >
                                               <label>Nom:</label><br>
                                               <input type="text" name="nom_entite_update" maxlength="50" value="<?php echo e($affiche_Entite_To_Edit[0]->Nom_Entite); ?>"/>
                                           </td> 
                                           <td class="input-box">
                                              <label>Code:</label><br>
                                              <input type="text" name="code_entite_update" maxlength="11" value="<?php echo e($affiche_Entite_To_Edit[0]->Code_Entite); ?>"/>
                                            </td> 
                                      </tr> 
                                       <tr>
                                          <td class="input-box">
                                            <label>Date Création:</label><br>
                                            <input type="Date" name="date_creation_update" value="<?php echo e($affiche_Entite_To_Edit[0]->Date_Creation); ?>"/>
                                          </td> 
                                     </tr>
          
                                 </table>
                            </fieldset>

                            <fieldset>
                             <legend>Infos Diverses</legend>
                                <table>
                                     <tr>
                                       <td class="input-box" >
                                            <label>Adresse:</label><br>
                                             <input type="text" name="adresse_entite_update" maxlength="20" value="<?php echo e($affiche_Entite_To_Edit[0]->Adresse); ?>"/>
                                      </td>
                                      <td class="input-box">
                                             <label>Ville:</label><br>
                                             <input type="text" name="ville_entite_update" maxlength="20" value="<?php echo e($affiche_Entite_To_Edit[0]->Ville); ?>"/>
                                     </td> 
                                     </tr> 
                                      <tr>  
                                           <td class="input-box" colpan="2">
                                                  <label>Code Postal:</label><br>
                                                     <input type="text" name="code_postal_entite_update" maxlength="20" value="<?php echo e($affiche_Entite_To_Edit[0]->Code_Postal); ?>"/>
                                           </td> 
                                           <td class="input-box">
                                                    <label>Pays:</label><br>
                                                    <input type="text" name="pays_entite_update" maxlength="20" value="<?php echo e($affiche_Entite_To_Edit[0]->Pays); ?>"/>
                                          </td> 
                                        </tr>
                                        <tr>
                                             <td class="input-box">
                                                   <label>Tel:</label><br>
                                                   <input type="text" name="tel_entite_update" maxlength="10" value="<?php echo e($affiche_Entite_To_Edit[0]->Tel); ?>"/>
                                           </td> 
         
                                             <td class="input-box">
                                                <label>Email:</label><br>
                                                <input type="email" name="email_entite_update" maxlength="50" value="<?php echo e($affiche_Entite_To_Edit[0]->Email); ?>"/>
                                             </td> 
                                             </tr>
                                              <tr>
                                                   <td class="input-box">
                                                      <label> Observations:</label><br>
                                                      <textarea name="observation_entite_update" cols="10" rows="5"style="color:black;" 
                                                      value="<?php echo e($affiche_Entite_To_Edit[0]->Observation); ?>"></textarea> 
                                                         
                                                      
                                                    </td>
                                                </tr>
                                            </table>
                                       </fieldset>
                                      
                          </div>
                           
                    </div>
            </div>
            </div>




            <div class="accordion_area">
                  <div class="accordion_box ">
                      <h3 class="acc_trigger" style='font-size:20px;color:black;width:950px;' >Correspondant<i class="fa fa-chevron-circle-down" style="font-size:17px"></i></h3>

                        <div class="acc_container">
                        <table id="customers" style="width:930px;">
                          <tr>
                            
                           <th>NOM</th>
                          <th>Prenom</th>
                          <th>Code</th>
                          <th>Code Postal</th>
                          <th>Adresse</th>
                          <th>Ville</th>
                            <th>Entité</th>
                           </tr>
                           
                           
                           
                           <?php $__currentLoopData = $affiche_Correspondant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                    
                           <td><div style="width:150px;text-align:left;" class="cell"><?php echo e($item->Nom); ?></div></td>
                           <td><div style="width:150px;text-align:left;" class="cell"><?php echo e($item->Prenom); ?></div></td>
                           <td><div style="width:80px;text-align:left;" class="cell"><?php echo e($item->Code_Correspondant); ?></div></td>
                           <td><div style="width:50px;text-align:left;" class="cell"><?php echo e($item->Code_Postal); ?></div></td>
                           <td><div style="width:100px;text-align:left;" class="cell"><?php echo e($item->Adresse); ?></div></td>
                           <td><div style="width:100px;text-align:left;" class="cell"><?php echo e($item->Ville); ?></div></td>
                           <td><div style="width:200px;text-align:left;" class="cell"><?php echo e($item->Nom_Entite_E); ?></div></td>
                    
                           </tr>
                           
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </table>
                       

            
        </table>
             
       </div>
  
         </div>
                   
        </div>
           
               
            <div class="accordion_area">
                  <div class="accordion_box ">
                      <h3 class="acc_trigger" style='font-size:20px;color:black;width:950px;' >Service<i class="fa fa-chevron-circle-down" style="font-size:17px"></i></h3>

                        <div class="acc_container">
                        <table id="customers" style="width:930px;">
                          <tr>
                                <th> <div style="width:10px;">
                                  <a href="/exploitation_Service_form_add">
                                    <i class="fa fa-plus" style="font-size:20px;color:#0E1C36;margin-left:28px;"></i>
                                  </a></div></th>
                                 <th>Code</th>
                                 <th>Nom</th>
                                  <th>Description</th>
                                  <th>Entité</th>
                         
                           </tr>
                      
                           <?php $__currentLoopData = $affiche_Service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                         <tr>
                                 <td>
                                     
                                       <div style="width:40px;margin-left:30px;" class="cell">
                                        <a href="/click_deleteService/<?php echo e($item->Code_Service); ?>">
                                          <i class='fas fa-trash' style='font-size:15px;color:#0E1C36;left:50px;'></i>
                                        </a>
                                       </div>
                       
                                  </td>
                    
                              <td><div style="width:100px;text-align:left;" class="cell"><?php echo e($item->Code_Service); ?></div></td>
                              <td><div style="width:100px;text-align:left;" class="cell"><?php echo e($item->Nom); ?></div></td>
                               <td><div style="width:100px;text-align:left;" class="cell"><?php echo e($item->Description); ?></div></td>
                               <td><div style="width:200px;text-align:left;" class="cell"><?php echo e($item->Nom_Entite_E); ?></div></td>
                          
                    
                    
                        </tr>
                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </table>
             
</div>
  
  </div>
                   
</div>






 </div>
</form>
</div>


<script>
  window.onload = function(){
    document.getElementById("popup-11").classList.toggle("active");
  }
  
 </script>
 <script>

$(document).ready(function(){
$('.accordion_box:first').addClass('active')
$('.accordion_box:first').children('.acc_trigger').children('i').addClass('fa-minus')
$('.accordion_box:first').children('.acc_trigger').addClass('selected').next('.acc_container').show()


  $('.acc_trigger').click(function(event){
         if($(this).hasClass('selected')){
           $(this).removeClass('selected');
           $(this).children('i').removeClass('fa-minus');
           $(this).next().slideUp();
           $(this).parent().removeClass('active');

         }else{
               $('.acc_trigger').removeClass('selected');
               $(this).addClass('selected');
               $('.acc_trigger').children('i').removeClass('fa-minus');
               $(this).children('i').addClass('fa-minus');
               $('.acc_trigger').next().slideUp();
               $(this).next().slideDown();
               $('.accordion_box').removeClass('active');
               $(this).parent().addClass('active');



         }

  });

});
    </script>


<?php $__env->stopSection(); ?>
    



<?php echo $__env->make('layouts.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Entite_Update.blade.php ENDPATH**/ ?>