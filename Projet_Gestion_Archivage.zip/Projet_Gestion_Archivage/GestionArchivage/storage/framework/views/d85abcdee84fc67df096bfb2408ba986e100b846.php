
<?php $__env->startSection('addstyleRetour'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/documentNonRetourner.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentTravauxRetour'); ?>
<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form action="/ti_Retour_DocNonRetourne_popup_UpdateStatut/<?php echo e($affich_DocNonRetourn_To_Edit[0]->Numero_Demande); ?>" method="POST">
              <?php echo csrf_field(); ?>
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               
                    
                    <div class="input-box">
                            <label style="left:20px;font-size:25px;">Statut:</label><br>

                            <input type="radio" name="statut_Document"
                            style="left:5px;position:absolute;top:50px;"
                            value="Document Non Retourner">
                            <label  style="left:200px;position:absolute;top:65px;">Document Non Retourner</label><br>
                            
                            <input type="radio" name="statut_Document"
                            style="left:5px;position:absolute;top:95px;"
                            value="Document Retourner">
                            <label style="left:200px;position:absolute;top:110px;">Document Retourner</label><br>
                            
                            <input type="radio"  name="statut_Document"
                            style="left:5px;position:absolute;top:140px;"
                            value="Document à Retourner" >
                             <label style="left:200px;position:absolute;top:155px;">Document à Retourner</label><br><br>
                             <button type="submit" class="btn"style="top:250px;left:260px;font-size:15px;">Modifier </button>
                      </div>
                          
                          
                                    
          </div>
          </form>
        </div>

  <script>
        window.onload = function(){
            document.getElementById("popup-14").classList.toggle("active");
        }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.travaux_Interieure_Retour_Dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/ti_Retour_DocNonRetourne_popup.blade.php ENDPATH**/ ?>