
<?php $__env->startSection('addstyleTravauxInterieurs'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajoutInventaire.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentTravaux'); ?>
<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form action="/ti_Saisie_Inventaire_add" method="POST">
            <?php echo csrf_field(); ?>
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Ajout-Inventaire</h3>

               
                               
                   
                   <table>   
                                  <tr>
                                       <td class="input-box"  >
                                         <label style="left:30px;top:50px;position:absolute;">N°UA:</label><br>
                                           <select style="left:30px; width:300px;top:100px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;" 
                                            maxlength="20" name="numero_ua_Saisie_Inventaire" required>
                                               <option disabled>--- Choisir une unité d'archivage ---</option>
                                               <?php $__currentLoopData = $numero_ua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option value="<?php echo e($item->Numero_UA); ?>"><?php echo e($item->Numero_UA); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select><br><br>
                                      </td>
                                 
                                 
                                       

                                       <td class="input-box">
                                             <label style="left:370px;top:50px;position:absolute;"> Libellé:</label><br>
                                              <input type="text" name="libelle_Saisie_Inventaire"  style="left:350px;position:absolute;top:55px;width:300px;"required  />
                                       </td> 
                                      
                                      
                                  </tr>
                     
                                  <tr>
                                  
                                      <td class="input-box">
                                              <label style="left:30px;top:145px;position:absolute;">Date mise à jour:</label><br>
                                              <input type="Date" maxlength="20"style="left:5px;" name="date_mise_jour_Saisie_Inventaire" required/>
                                      </td> 
                                  
                                  
                                  
                                  
                                       <td class="input-box">
                                             <label style="left:365px;top:145px;">Nombre de page:</label><br>
                                              <input type="text" maxlength="6"style="left:350px;" 
                                              name="nb_page_Saisie_Inventaire" required  />
                                       </td> 
                                      
                                   </tr>
                                  
                            
                                   </table>              
                
                                   <button type="submit" class="btn">Ajouter</button>
          </div>
          </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-14").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.travaux_Interieure1_Dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/ti_Saisie_Inventaire_add.blade.php ENDPATH**/ ?>