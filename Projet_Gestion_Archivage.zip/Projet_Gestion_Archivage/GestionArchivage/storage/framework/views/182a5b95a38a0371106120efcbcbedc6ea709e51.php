<!DOCTYPE html>
<html>
<head>
	<title>Login et Registre</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
  <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700,800&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/sass/sample.css')); ?>">
</head>
<body>   
  <div class="cont">
    <div class="sub-cont">
      <div class="img">
        <div class="img-text m-up">
          <h2>Archiv+</h2>
          <p>Vous avez déjà un compte ? Connectez-vous</p>
        </div>

        <div class="img-btn">
          <span class="m-up">SE CONNECTER</span>
          
        </div>
      </div>

      <div class="form sign-up">
        <form method="POST" action="submit" class="needs-validation" novalidate id="forms">
           <?php echo csrf_field(); ?>
        <h2>Inscription</h2>
        <table style= "border-collapse: separate;
        border-spacing:25px 0px;" >
          <tr>
            <td class="form-group row">
                <label>
                  <div class="col-md-6 position-relative">
                    <input type="text" placeholder="Nom" maxlength="20" name="nom" class="form-control" id="validationTooltip03" required="">
                    <div class="invalid-tooltip">
                      Please provide a valid city.
                    </div>
                  </div>
                  
              </label>
            </td>
            
            <td>
              <label>
                <input type="text" placeholder="Prénom" maxlength="20" name="prenom" class="form-control">
              </label>
            </td>
          </tr>
          <tr>
            <td>
              <label>
                <input type="text" placeholder="CIN" maxlength="8" name="cin" class="form-control">
              </label> 
            </td>
            <td>
              <label>
                <input type="phone" placeholder="Téléphone" maxlength="10" name="tel" class="form-control">
              </label>
            </td>
          </tr>
          <div>
          <tr>
              <td colspan="2">
                <label style="width:100%">
                  <input type="email" placeholder="Email" style="width: 100%" maxlength="50" name="email" class="form-control">
                </label>
              </td>
          </tr>
          <tr>
            <td colspan="2">
              <label style="width:100%">
                <input type="address" placeholder="Adresse" style="width: 100%" maxlength="50" name="adresse" class="form-control">
              </label>
            </td>
          </tr>
          <tr>
            <td colspan="2">
              <label style="width:100%">
                <input type="text" placeholder="Login" style="width: 100%" maxlength="20" name="login_Registre"class="form-control">
              </label>
            </td>
          </tr>
          <tr>
            <td>
              <label style="width:100%">
                <input type="password" placeholder="Mot de passe" style="width: 100%" maxlength="10" name="password_Registre" class="form-control">
               
              </label>
            </td>
            <td>
              <label style="width:100%">
                <input type="password" placeholder="Confirmer le mot de passe" style="width: 100%" maxlength="10" name="confirmer_password_Registre" class="form-control">
              </label>
            </td>
          </tr>
        </div>
        </table> 
        <button type="submit" class="submit">S'INSCRIRE</button>
        </form>
      </div>
    </div>
  </div>
<script type="text/javascript" src="<?php echo e(asset('assets/js/js/bootstrap.min.js')); ?>"></script>

</body>
</html><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/loginetregistre.blade.php ENDPATH**/ ?>