<!DOCTYPE html>
<html>
<head>
	<title>Changer Mot de Passe</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleLogin.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleIconPassword.css')); ?>">
  <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700,800&display=swap" rel="stylesheet">
  
</head>
<body>       
  <div class="cont">
    <div class="form sign-in">
      <form method="POST" action="/changerMDP" >
        <?php echo csrf_field(); ?>
       
      <h2>Choisissez un nouveau mot de passe</h2>
      <div>
        <?php if(\Session::has('refuser')): ?>
          <div class="alert alert-danger" role="alert" style="text-align: center">
            <?php echo e(\Session::get('refuser')); ?>

          </div>
        <?php endif; ?>
      </div>
      <label>
        <span>Login</span>
        <input type="text" name="nouveau_login_Login" maxlength="20" class="form-control" value="<?php echo e(old('nouveau_login_Login')); ?>">
      </label>
      <div class="alert-danger" id="designAlert"><?php echo e($errors->first('nouveau_login_Login')); ?></div>
      

      <label class="labelPos">
        <span>Nouveau mot de passe</span>
        <input type="password"  name="nouveau_password_Login" maxlength="20" class="form-control" title="MDP" value="<?php echo e(old('nouveau_password_Login')); ?>" id="passwordPos">
        <div class="password-icon">
          <i data-feather="eye" class="poseEye"></i>
          <i data-feather="eye-off" ></i>
        </div>
      </label>
      <div class="alert-danger" id="designAlert"><?php echo e($errors->first('nouveau_password_Login')); ?></div>

      <label class="labelPos">
        <span>Confirmez le nouveau mot de passe</span>
        <input type="password"  name="confirmer_nouveau_password_Login" maxlength="20" class="form-control" title="MDP" value="<?php echo e(old('confirmer_nouveau_password_Login')); ?>" id="passwordPos">
        <div class="password-icon">
          <i data-feather="eye" class="poseEye"></i>
          <i data-feather="eye-off"></i>
        </div>
      </label>
      <div class="alert-danger" id="designAlert"><?php echo e($errors->first('confirmer_nouveau_password_Login')); ?></div>
      
      <button type="submit" class="submit">
          <a style="text-decoration:none; color:#fff">
              Valider
          </a>
      </button>
    </form>
    </div>
    <div class="sub-cont">
        <div class="img">
            <div class="img-text m-up">
                <h2>Archiv+</h2>
                <p>Vous avez déjà un compte ? Connectez-vous</p>
            </div>
            <div class="pos">
                <div class="img-btn">
                    <span class="m-up">
                        <a href="/login" style="position:absolute; z-index: 5; text-decoration:none; color:#fff">
                        SE CONNECTER
                        </a>
                    </span>
                </div>
            </div>
        </div>
    </div>
  </div>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/icon.js')); ?>"></script>
  <script>
    feather.replace();
    </script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/styleIconPassword.js')); ?>"></script>
</body>
</html><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/Forget_Password.blade.php ENDPATH**/ ?>