
<?php $__env->startSection('contentRetour'); ?>

<form method="POST" action="/ti_Retour_DocNonRetourne">
         <?php echo csrf_field(); ?>

      
         <fieldset style="width: 980px; ">
            <legend class="stylelegend">Section Recherche    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              
            </legend>
            
              <div class="left">
               <label style="color:black;top:45px;position:absolute;">Entité:</label><br>
               <select style=" width:200px;border-radius:4px;top:70px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
               name="entite_Recherche_DO_search" maxlength="20" required>
                <option disabled>--- Choisir Entité ---</option>
                <?php $__currentLoopData = $entites_s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="left">
               <label style="color:black;left:220px;position:absolute;top:45px;">Service Document:</label><br>
               <select style="left:220px; width:200px;border-radius:4px;position:absolute;top:70px;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
               name="service_Recherche_DO_search" maxlength="20" required>
                    <option disabled>--- Choisir Service ---</option>
                    <?php $__currentLoopData = $services_s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->Code_Service); ?>"><?php echo e($item->Code_Service); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                                            
            </div>
            <div class="left">
               <label style="color:black;left:430px;top:45px;position:absolute;">Nature Document:</label><br>
               <select style="left:425px; width:200px;border-radius:4px;top:70px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;"
                name="nature_Recherche_DO_search" maxlength="20" required>
                <option disabled>--- Choisir Nature Document ---</option>
                <?php $__currentLoopData = $natures_s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->Code_Nature); ?>"><?php echo e($item->Code_Nature); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
                                            
            </div>
            <div class="left">
               <label style="color:black;left:635px;top:45px;position:absolute;">Statut:</label><br>
               <select style="left:635px; width:160px;border-radius:4px;top:70px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
               name="statut_Recherche_DO_search" maxlength="20" required >
                <option disabled>--- Choisir Statut ---</option>
                <?php $__currentLoopData = $statut_s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->Statut); ?>"><?php echo e($item->Statut); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                                            
            </div>
            <div class="left">
               <label style="color:black;left:810px;top:45px;position:absolute;">Bordereau:</label><br>
               <select style="left:810px; width:160px;border-radius:4px;top:70px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
               name="bordereau_Recherche_DO_search" maxlength="20" required>
                <option disabled>--- Choisir Bordereau ---</option>
                <?php $__currentLoopData = $bordereaus_s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->Numero_Bordereau); ?>"><?php echo e($item->Numero_Bordereau); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select><br><br><br><br>
           </div>
           <div class="left">
               <label style="position:absolute;top:100px;color:black;left:20px;">Libellé:</label><br>
               <input type="text" maxlength="50" name="libele_Recherche_DO_search"
               style=" border-radius: 5px;color: #000;top:125px;left:15px;position:absolute;width:200px;"
               required>
            </div>
            <div class="left">
               <label style="color:black;left:225px;top:100px;position:absolute;">UA du:</label><br>
               <input type="text" maxlength="20" name="ua_du_Recherche_DO_search"
               style=" border-radius: 5px;color: #000;top:125px;left:225px;position:absolute;width:120px;" 
               required>
                                            
            </div>
            <div class="left">
               <label style="color:black;left:355px;top:100px;position:absolute;">Au:</label><br>
               <input type="text" maxlength="20" name="au_Recherche_DO_search"
               style=" border-radius: 5px;color: #000;top:125px;left:355px;position:absolute;width:120px;"
               required>
               
                                            
            </div>
            <div class="left">
               <label style="color:black;left:485px;top:100px;position:absolute;">#Demande:</label><br>
               <input type="text" maxlength="11" name="numero_demande_Recherche_DO_search"
               style=" border-radius: 5px;color: #000;top:125px;left:485px;position:absolute;width:120px;"
               required>
               
                                            
            </div>
            
            <button type="submit" ><i class="fa fa-search" style="font-size:25px;color:black;left:810px;position:absolute;top:125px;"></i></button>
         </fieldset>
         <?php if(\Session::has('ti_Retour_DocNonRetourne_updateStatut')): ?>
          <div class="alert_green" style="text-align: center">
            <?php echo e(\Session::get('ti_Retour_DocNonRetourne_updateStatut')); ?>   
          </div>
        <?php endif; ?>  

</form>
<?php echo $__env->yieldContent('tableau'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.travaux_Interieure_Retour_Dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/layouts/travaux_Interieure_Retour_DocNonRetourne_form.blade.php ENDPATH**/ ?>