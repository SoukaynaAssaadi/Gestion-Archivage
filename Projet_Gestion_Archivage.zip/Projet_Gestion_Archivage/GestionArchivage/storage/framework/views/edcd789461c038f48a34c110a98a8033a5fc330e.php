

<?php $__env->startSection('styleExploitationEntiteUpdate'); ?>
 <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/nature.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

      <div class="popup" id="popup-13"> 
          <div class="overlay"></div>
          <form action="/exploitation_Nature_update/<?php echo e($affiche_Nature_To_Edit[0]->Code_Nature); ?>" method="POST">
            <?php echo csrf_field(); ?>
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Modification-Nature</h3>

               <table>
                               
                                  <tr>
                                      <td class="input-box"  >
                                           <label style="left:60px;font-size:18px;">Entité:</label>
                                           <br><br>
                                           <select name="entite_Nature_update" style="left:60px; width:265px;position:absolute;border-radius:4px; 
                                           margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" required>
                                               <option style="font-size:15px;color:#000;" disabled>--- Choisir Entite ---</option>
                                               <?php $__currentLoopData = $show_all_entite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option style="font-size:17px;" value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                           </select>
                                           <br>
                                            
                                      </td> 
                                  
                                  
                                        <td class="input-box">
                                              <label style="left:360px;font-size:18px;">Service:</label>
                                              <br><br>
                                           <select name="service_Nature_update" style="left:370px; width:265px;position:absolute;border-radius:4px; 
                                           margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" required>
                                               <option style="font-size:15px;color:#000;" disabled>--- Choisir Service ---</option>
                                               <?php $__currentLoopData = $show_all_service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option style="font-size:17px;" value="<?php echo e($item->Code_Service); ?>"><?php echo e($item->Code_Service); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                           </select>
                                           <br>
                                      </td> 
                                   </tr> 
                                   <tr>
                                        <td class="input-box">
                                             <label style="left:60px;font-size:18px;">Code:</label>
                                              <input type="text"  name="code_Nature_update" maxlength="20" value="<?php echo e($affiche_Nature_To_Edit[0]->Code_Nature); ?>" />
                                       </td> 
                                       <td class="input-box">
                                             <label style="left:360px;font-size:18px;">Nom:</label>
                                              <input type="text" name="nom_Nature_update" maxlength="100" value="<?php echo e($affiche_Nature_To_Edit[0]->Nom); ?>" />
                                       </td> 
                                   </tr>
                                   <tr>
                                        <td class="input-box">
                                             <label style="left:60px;font-size:18px;">Délai Conservation:</label>
                                              <input type="text" name="delai_conservation_Nature_update" maxlength="4" value="<?php echo e($affiche_Nature_To_Edit[0]->Delai_Conservation); ?>"/>
                                       </td> 
                                       <td class="input-box">
                                             <label style="left:360px;font-size:18px;">Description:</label>
                                              <input type="text" name="description_Nature_update" value="<?php echo e($affiche_Nature_To_Edit[0]->Description); ?>" />
                                       </td> 
                                   </tr>    
                            </table>
                            

                  </table>
                  <button type="submit" class="btn">Modifier</button>

          </div>
          </form>
        </div>


  <script>
      window.onload = function(){
        document.getElementById("popup-13").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-13").classList.toggle("active");
          }
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.exploitationEntite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Nature_Update.blade.php ENDPATH**/ ?>