

<?php echo $__env->yieldContent('styleDR'); ?>

<?php $__env->startSection('contentRecherche'); ?>
<form method="POST" action="/ti_Recherche_DR">
    <?php echo csrf_field(); ?>

    <fieldset style="width: 980px; ">
       <legend class="stylelegend">Section Recherche   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="/ti_Recherche_DR_form_add">
             <i class="fa fa-plus" style="font-size:20px;color:#FFF"></i>
          </a>
       </legend>
         <div class="left">
          <label style="color:black;">Entité</label><br>
          <select style=" width:200px;border-radius:4px;
          margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
          name="entite_DR_search" maxlength="20" required>
                <option disabled>--- Choisir Entitée ---</option>
                <?php $__currentLoopData = $entites_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
                                       
     </div>
       <div class="left">
          <label style="color:black;">Service Document</label><br>
          <select style=" width:200px;border-radius:4px;position:absolute;
          margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
          name="service_DR_search" maxlength="20" required>
            <option disabled>--- Choisir Service ---</option>
            <?php $__currentLoopData = $services_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->Code_Service); ?>"><?php echo e($item->Code_Service); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
                                       
       </div>
       <div class="left">
          <label style="color:black;left:450px;position:absolute;">Nature Document</label><br>
          <select style=" left:445px;width:200px;border-radius:4px;top:70px;position:absolute;
          margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
          name="nature_DR_search" maxlength="20" required>
            <option disabled>--- Votre Choix ---</option>
            <?php $__currentLoopData = $natures_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->Code_Nature); ?>"><?php echo e($item->Code_Nature); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
                                       
       </div>
       <div class="left">
          <label style="color:black;left:655px;top:45px;position:absolute;">Statut</label><br>
          <select style="left:655px; width:150px;border-radius:4px;top:70px;position:absolute;
          margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
          name="statut_DR_search" maxlength="20" required>
            <option disabled>--- Votre Choix ---</option>
            <option>Initialisé</option>
            <option>Inexistant sur Inventaire</option>
            <option>Conteneur In</option>
            <option>Echec</option>
            <option>Logistique</option>
            <option>Succés</option>
            <option>Document Inexistant</option>
            <option>En Consultation</option>
            
        </select>
                                       
       </div>
       <div class="left">
          <label style="color:black;left:820px;top:45px;position:absolute;">Type</label><br>
          <select style="left:820px; width:150px;border-radius:4px;top:70px;position:absolute;
          margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
          name="type_DR_search"  maxlength="20" required>
            <option disabled>--- Votre Choix ---</option>
            <?php $__currentLoopData = $types_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->Type); ?>"><?php echo e($item->Type); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
                                       
       </div><br><br><br><br>
       
       
       <div class="left">
          <label style="color:black;left:20px;top:102px;position:absolute;">Correspondant</label><br>
          <select style="left:20px; width:200px;border-radius:4px;top:126px;position:absolute;
          margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
          name="correspondant_DR_search" maxlength="20" required>
           <option disabled>--- Votre Choix ---</option>
           <?php $__currentLoopData = $correspondant_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($item->Code_Correspondant); ?>"><?php echo e($item->Code_Correspondant); ?></option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select>
                                       
       </div>
       <div class="left">
          <label style="position:absolute;top:102px;color:black;left:240px;">Urgence</label><br>
          <input type="text" maxlength="20" name="urgence_DR_search" 
          style=" border-radius: 5px;color: #000;top:125px;left:240px;position:absolute;width:100px;" 
          required>
       </div>
       <div class="left">
          <label style="color:black;left:350px;top:102px;position:absolute;">Prestation</label><br>
          <select style="left:350px; width:100px;border-radius:4px;top:125px;position:absolute;
          margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
          name="prestation_DR_search" mawlength="20" required>
            <option disabled>--- Votre Choix ---</option>
            <?php $__currentLoopData = $prestation_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->Code_Prestation); ?>"><?php echo e($item->Code_Prestation); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
                                       
       </div>
       <div class="left">
          <label style="color:black;left:460px;top:102px;position:absolute;">UA</label><br>
          <select maxlength="50" name="ua_DR_search"
          style=" border-radius: 5px;color: #000;top:125px;left:460px;position:absolute;width:100px;"
          required>
          <option disabled>--- Choisir Unité archivage ---</option>
            <?php $__currentLoopData = $ua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->Numero_UA); ?>"><?php echo e($item->Numero_UA); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select>                             
       </div>
       <div class="left">
          <label style="color:black;left:570px;top:102px;position:absolute;">Demande</label><br>
          <input type="text" maxlength="11" name="demende_DR_search"
          style=" border-radius: 5px;color: #000;top:125px;left:570px;position:absolute;width:100px;"
          required>
                                
       </div>
     
      
       <button type="submit" ><i class="fa fa-search" style="font-size:25px;color:black;left:700px;position:absolute;top:123px;"></i></button>
      
    </fieldset>
    
    <?php if(\Session::has('ti_Recherche_DR_add')): ?>
          <div class="alert_green" style="text-align: center">
            <?php echo e(\Session::get('ti_Recherche_DR_add')); ?>

          </div>
    <?php endif; ?>
    <?php if(\Session::has('ti_Recherche_DR_delete')): ?>
          <div class="alert_erreur" style="text-align: center">
            <?php echo e(\Session::get('ti_Recherche_DR_delete')); ?>

          </div>
    <?php endif; ?>
    <?php if(\Session::has('ti_Recherche_DR_update')): ?>
          <div class="alert_green" style="text-align: center">
            <?php echo e(\Session::get('ti_Recherche_DR_update')); ?>

          </div>
    <?php endif; ?>
    
 </form>
 <?php echo $__env->yieldContent('contentResultRecherche'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.travaux_Interieure_Recherche_Dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/layouts/travaux_Interieure_Recherche_showTable.blade.php ENDPATH**/ ?>