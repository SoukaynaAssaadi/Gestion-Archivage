
<?php $__env->startSection('styleExploitationEntiteUpdate'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajouterCorrespondants.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

   <div class="popup" id="popup-13"> 
        <div class="overlay"></div>
        <form  method="POST" action="/exploitation_Correspondant_update/<?php echo e($afficher_Correspondant_To_Edit[0]->Code_Correspondant); ?>">
            <?php echo csrf_field(); ?>
     <div class="content" >
         <div class="close-btn" onclick="togglePopup()">×</div>

           <h3 style='font-size:30px;color:#0E1C36;'>Correspondant-Modification</h3>
           <div class="custom-info">


                          <fieldset>
                           <table>
                                <legend>Infos Contact</legend>
                                  <tr>
                                      <td class="input-box"  >
                                           <label>Nom:</label><br>
                                            <input type="text" name="nom_correspondant_update" maxlength="20" value="<?php echo e($afficher_Correspondant_To_Edit[0]->Nom); ?>" required/>
                                            
                                      </td> 
                                  
                                  
                                        <td class="input-box">
                                              <label>Prénom:</label><br>
                                              <input type="text" name="prenom_correspondant_update" maxlength="20" value="<?php echo e($afficher_Correspondant_To_Edit[0]->Prenom); ?>" required/>
                                      </td> 
                                   </tr> 
                                   <tr>
                                        <td class="input-box">
                                             <label>Entité:</label>
                                             <br>
                                            <select name="entite_correspondant_update" style="color:#000;height:30px;font-size:15px;width:205px;background-color:#FFF;" required>
                                                <option style="font-size:15px;color:#000;" disabled>--- Choisir Entites ---</option>
                                                <?php $__currentLoopData = $afficher_Entite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option style="font-size:17px;" value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                            </select>
                                            
                                       </td> 
                                       <td class="input-box">
                                             <label>Code:</label><br>
                                              <input type="text" name="code_correspondant_update" maxlength="50" value="<?php echo e($afficher_Correspondant_To_Edit[0]->Code_Correspondant); ?>" required/>
                                       </td> 
                                   </tr>
                                   <tr>
                                       <td class="input-box">
                                             <label>Tel:</label><br>
                                              <input type="phone" name="tel_corresponadant_update" maxlength="10" value="<?php echo e($afficher_Correspondant_To_Edit[0]->Tel); ?>" required/>
                                       </td> 
                                       <td class="input-box">
                                             <label>Fax:</label><br>
                                              <input type="phone" name="fax_correspondant_update" maxlength="20" value="<?php echo e($afficher_Correspondant_To_Edit[0]->Fax); ?>"/>
                                       </td> 
                                   </tr>
                                   <tr>
                                       <td class="input-box">
                                             <label>Email:</label><br>
                                              <input type="email" name="email_correspondant_update" maxlength="50" value="<?php echo e($afficher_Correspondant_To_Edit[0]->Email); ?>" required/>
                                       </td> 
                                          <td class="input-box">
                                                      <label> Observations:</label><br>
                                                      <textarea name="observation_correspondant_update" cols="10" rows="2"style="color:#000;" value="<?php echo e($afficher_Correspondant_To_Edit[0]->Observation); ?>"></textarea> 
                                                         
                                                      
                                                    </td>
                                   </tr>
                                    
                            </table>
                            
                        </fieldset> 
                        <fieldset>
                             <legend>Infos Adresse</legend>
                                <table>
                                     <tr>
                                       <td class="input-box" >
                                            <label>Ville:</label><br>
                                             <input type="text" name="ville_correspondant_update" maxlenght="20" value="<?php echo e($afficher_Correspondant_To_Edit[0]->Ville); ?>"/>
                                      </td>
                                      <td class="input-box">
                                             <label>Code Postal:</label><br>
                                             <input type="text" name="code_postal_correspondant_update" maxlenght="11" value="<?php echo e($afficher_Correspondant_To_Edit[0]->Code_Postal); ?>"/>
                                     </td> 
                                     </tr> 
                                      <tr>  
                                           <td class="input-box" colpan="2">
                                                  <label>Pays:</label><br>
                                                     <input type="text" name="pays_correspondant_update" maxlenght="20" value="<?php echo e($afficher_Correspondant_To_Edit[0]->Pays); ?>"/>
                                           </td> 
                                           <td class="input-box">
                                                    <label>Adresse:</label><br>
                                                    <input type="text" name="adresse_correspondant_update" maxlenght="20" value="<?php echo e($afficher_Correspondant_To_Edit[0]->Adresse); ?>"/>
                                          </td> 
                                        </tr>
                                        <tr>
                                            <td class="input-box">
                                                
                                                <input type="radio" name="check_type_update" value="Actif"><span style="color: #000;"> Actif ?</span>
                                                
                                            </td>
                                            <td class="input-box">
                                                <input type="radio" name="check_type_update" value="Majeur"><span style="color: #000;"> Majeur ?<span>
                                            </td>
                                        </tr>
                                        
                                            </table>
                                       </fieldset>
                                       
                 </div>
                 <button style="width: 150px; height: 50px; color: #FFF; background-color: #0E1C36;margin-top: 165px; margin-left: 390px; border-radius: 20px;" type="submit">
        <span style="font-size: 15px;padding-bottom: 5px;">Modifier</span></button>


        </div>
    </form>
    </div>

     <script>
         window.onload = function(){
            document.getElementById("popup-13").classList.toggle("active");  
         }
        function togglePopup(){
         document.getElementById("popup-13").classList.toggle("active");
         }
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.exploitationEntite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Correspondant_Update.blade.php ENDPATH**/ ?>