<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
  
  <script src="<?php echo e(asset('assets/JQuery/menuJQuery.js')); ?>"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
   
    
      <div class="img">
        
        <?php 
            if($path == "pdf"){
        ?>
        <embed src="<?php echo e(asset('storage/' . $affichage[0]->photo)); ?>"  width="1000px" height="1010px" style="margin-left:0px; margin-top:0px;">

        <?php  
            }else{  
        ?>
        <img src="<?php echo e(asset('storage/' . $affichage[0]->photo)); ?>" width="1037px" height="300px">

        <?php } ?>
      </div>
      <script>
      

      </script>
</body>
</html>

<?php /**PATH C:\wamp\www\GestionArchivage\resources\views//affichage_Document.blade.php ENDPATH**/ ?>