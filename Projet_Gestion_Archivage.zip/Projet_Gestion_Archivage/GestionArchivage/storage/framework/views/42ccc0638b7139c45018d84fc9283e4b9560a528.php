

<?php $__env->startSection('addstyleAdminGP'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/stylePopupAdminGPupdate.css')); ?>">
    <style>input::placeholder{
      color: gray;
    }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentAdminGP'); ?>

<div class="popup" id="popup-3">
  <div class="overlay"></div>
  <form  method="POST" action="/click_Button_Affecter">
    <?php echo csrf_field(); ?>
    
        
   <div class="content">
    <button type="submit" class="submit" style="width: 200px; height: 50px; color: #FFF; background-color: #0E1C36;margin-top: 20px; margin-left: 90px; border-radius: 20px;top:2%;left:41%"
    >Affecter</button>  
              <div class="accordion_area">
                  <div class="accordion_box ">
                      <h3 class="acc_trigger">Liste Privilèges&nbsp;&nbsp;<i class='fas fa-chevron-circle-down' style='font-size:17px;color:#000'></i></h3>
                        
                        <div class="acc_container">

                        <table id="customers">
                          <tr>
                            <th></th>
                           <th>Menu</th>
                          <th>Page</th>
                           </tr>
                           
                           
                           
                           <?php $__currentLoopData = $listePrivilege; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                                 <td>
                        
                        
                                 &nbsp;&nbsp;&nbsp;
                        <a href="/softDeleteListePrivilege/<?php echo e($item->id); ?>" onclick="alert('un Element est Supprimer');">
                            <i class='fas fa-trash' style='font-size:15px;color:#0E1C36'></i>
                        </a>
                    </td>
                    <td style="text-align: left;"><div style="width:200px;" class="cell"><input type="hidden" value="<?php echo e($item->Menu); ?>" name="Menuuu"><?php echo e($item->Menu); ?></div></td>
                    <td style="text-align: left;"><div style="width:200px;" class="cell"><input type="hidden" value="<?php echo e($item->Page); ?>" name="Pageee"><?php echo e($item->Page); ?></div></td>
                    
                    
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                       
                       </table>
                      
                    </div>

                    
                </div>
               
            </div>
            <div class="accordion_area">
                  <div class="accordion_box">
                      <h3 class="acc_trigger" >Section Utilisateurs&nbsp;&nbsp;<i class='fas fa-chevron-circle-down' style='font-size:17px;color:#000'></i></h3>

                        <div class="acc_container">

                        

                          <table id="customers" style="text-align:left;">
                            <tr>
                                <th></th>
                                <th>Login</th>
                                <th>Nom</th>
                                <th>Prenom</th>
  
                           </tr>
                     
                            <?php $__currentLoopData = $utilisateurLNP; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                              <td>
                               <a href="/click_deleteSectionUtilisateurGP/<?php echo e($item->id); ?>">
                                 <i class='fas fa-trash' style='font-size:15px;color:#0E1C36' onclick="alert('un Element est Supprimer');"></i>
                             </a>
                              </td>
                                 <td><div style="width:300px;" class="cell"><input type="hidden" value="<?php echo e($item->Login); ?>" name="Loginnn"><?php echo e($item->Login); ?></div></td>
                                  <td><div style="width:250px;" class="cell"><?php echo e($item->Nom); ?></div></td>
                                  <td><div style="width:250px;" class="cell"><?php echo e($item->Prenom); ?></div></td>

                             </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            

                    </table>

                     
                        </div>


                </div>

            </div>

   </div>
</form>  
</div>

<script>
   function togglePopup_P3(){
    document.getElementById("popup-3").classList.toggle("active");
    }
    window.onload = function(){
    document.getElementById("popup-3").classList.toggle("active");
    }
 </script>
 <script>

$(document).ready(function(){
$('.accordion_box:first').addClass('active')
$('.accordion_box:first').children('.acc_trigger').children('i').addClass('fa-minus')
$('.accordion_box:first').children('.acc_trigger').addClass('selected').next('.acc_container').show()


  $('.acc_trigger').click(function(event){
         if($(this).hasClass('selected')){
           $(this).removeClass('selected');
           $(this).children('i').removeClass('fa-minus');
           $(this).next().slideUp();
           $(this).parent().removeClass('active');

         }else{
               $('.acc_trigger').removeClass('selected');
               $(this).addClass('selected');
               $('.acc_trigger').children('i').removeClass('fa-minus');
               $(this).children('i').addClass('fa-minus');
               $('.acc_trigger').next().slideUp();
               $(this).next().slideDown();
               $('.accordion_box').removeClass('active');
               $(this).parent().addClass('active');



         }

  });

});
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views//adminPopupGPupdate.blade.php ENDPATH**/ ?>