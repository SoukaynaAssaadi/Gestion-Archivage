
<?php $__env->startSection('contentPopupAdminGPupdate'); ?>
<div class="popup" id="popup-3">
  <div class="overlay"></div>
  <div class="content">
      <form action="" method="POST">
          <?php echo csrf_field(); ?>
         <div class="close-btn" onclick="togglePopup_P3()">×</div>
   
              <div class="accordion_area">
                  <div class="accordion_box ">
                      <h3 class="acc_trigger" >Liste Privilèges&nbsp;&nbsp;<i class='fas fa-chevron-circle-down' style='font-size:17px;color:#000'></i></h3>

                        <div class="acc_container">

                        <table id="customers">
                          <tr>
                            <th><a href="#""><i class="fa fa-check" style="color:#0E1C36;"></i></a></th>
                           <th>Menu</th>
                          <th>Page</th>
                          <th>Ajout</th>
                          <th>Modif</th>
                          <th>Suppr</th>
                          <th>Recherche</th>
                          <th>Export</th>
                          <th>Import</th>
                           </tr>
                           <?php $i = 0; ?>
                           
                           
                           <?php $__currentLoopData = $listePrivilege; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                                 <td>
                        
                        
                                 &nbsp;&nbsp;&nbsp;
                        <a href="#">
                            <i class='fas fa-trash' style='font-size:15px;color:#0E1C36'></i>
                        </a>
                    </td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Menu); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Page); ?></div></td>
                    <td><div style="width:100px;" class="cell"></div><input type="checkbox" id="scales" name="scales"
                        checked></td>
                    <td><div style="width:100px;" class="cell"></div><input type="checkbox" id="scales" name="scales"
         checked></td>
                    <td><div style="width:15px;" class="cell"></div><input type="checkbox" id="scales" name="scales"
         checked></td>
                    <td><div style="width:15px;" class="cell"></div><input type="checkbox" id="scales" name="scales"
         checked></td>
                    <td><div style="width:15px;" class="cell"></div><input type="checkbox" id="scales" name="scales"
         checked></td>
                    <td><div style="width:20px;" class="cell"><input type="checkbox" id="scales" name="scales"
         checked></td>
                    
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                       
                       </table>
                      
                    </div>

                    
                </div>
               
            </div>
            <div class="accordion_area">
                  <div class="accordion_box">
                      <h3 class="acc_trigger" >Section Utilisateurs&nbsp;&nbsp;<i class='fas fa-chevron-circle-down' style='font-size:17px;color:#000'></i></h3>

                        <div class="acc_container">

                        

                          <table id="customers">
                            <tr>
                                <th><a href="#"><i class="fa fa-check" style="color:#0E1C36;"></i></a></th>
                                <th>Login</th>
                                <th>Nom</th>
                                <th>Prenom</th>
  
                           </tr>
                     <?php $i = 0; ?>
     
                           <tr>
                              <td>


                                 &nbsp;&nbsp;&nbsp;
                               <a href="#">
                                 <i class='fas fa-trash' style='font-size:15px;color:#0E1C36'></i>
                             </a>
                              </td>
                                 <td><div style="width:100px;" class="cell"></div></td>
                                  <td><div style="width:100px;" class="cell"></div></td>
                                  <td><div style="width:100px;" class="cell"></div></td>


                             </tr>
                               <?php $i++; ?>

                    </table>

                     
                        </div>


                </div>

            </div>


    

   </div>
</div>

<script>
   function togglePopup_P3(){
    document.getElementById("popup-3").classList.toggle("active");
    }
    window.onload = function(){
    document.getElementById("popup-3").classList.toggle("active");
    }
 </script>
 <script>

$(document).ready(function(){
$('.accordion_box:first').addClass('active')
$('.accordion_box:first').children('.acc_trigger').children('i').addClass('fa-minus')
$('.accordion_box:first').children('.acc_trigger').addClass('selected').next('.acc_container').show()


  $('.acc_trigger').click(function(event){
         if($(this).hasClass('selected')){
           $(this).removeClass('selected');
           $(this).children('i').removeClass('fa-minus');
           $(this).next().slideUp();
           $(this).parent().removeClass('active');

         }else{
               $('.acc_trigger').removeClass('selected');
               $(this).addClass('selected');
               $('.acc_trigger').children('i').removeClass('fa-minus');
               $(this).children('i').addClass('fa-minus');
               $('.acc_trigger').next().slideUp();
               $(this).next().slideDown();
               $('.accordion_box').removeClass('active');
               $(this).parent().addClass('active');



         }

  });

});
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/adminPopupGPupdate.blade.php ENDPATH**/ ?>