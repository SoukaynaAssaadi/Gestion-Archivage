

<?php $__env->startSection('styleExploitationEntiteUpdate'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajouteEntite.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

   <div class="popup" id="popup-10"> 
        <div class="overlay"></div>
        <form  method="POST" action="/exploitation_Entite_add">
            <?php echo csrf_field(); ?>
     <div class="content" >
         <div class="close-btn" onclick="togglePopup()">×</div>

           <h3 style='font-size:30px;color:#0E1C36;'>Entité-Ajout</h3>
           <div class="custom-info">


                          <fieldset>
                           <table>
                                <legend>Infos Entité</legend>
                                  <tr>
                                      <td class="input-box"  >
                                           <label>Nom:</label><br>
                                            <input type="text" name="nom_entite" maxlength="50" />
                                            
                                      </td> 
                                  
                                  
                                        <td class="input-box">
                                              <label>Code:</label><br>
                                              <input type="text" name="code_entite" maxlength="11"/>
                                      </td> 
                                   </tr> 
                                   <tr>
                                        <td class="input-box">
                                             <label>Date Création:</label><br>
                                              <input type="Date" name="date_creation_entite" />
                                       </td> 
                                   </tr>
                                    
                            </table>
                            
                        </fieldset> 
                        <fieldset>
                             <legend>Infos Adresse</legend>
                                <table>
                                     <tr>
                                       <td class="input-box" >
                                            <label>Adresse:</label><br>
                                             <input type="text" name="adresse_entite" maxlength="20"/>
                                      </td>
                                      <td class="input-box">
                                             <label>Ville:</label><br>
                                             <input type="text" name="ville_entite" maxlength="20"/>
                                     </td> 
                                     </tr> 
                                      <tr>  
                                           <td class="input-box" colpan="2">
                                                  <label>Code Postal:</label><br>
                                                     <input type="text" name="code_postal_entite" maxlength="11"/>
                                           </td> 
                                           <td class="input-box">
                                                    <label>Pays:</label><br>
                                                    <input type="text" name="pays_entite" maxlength="20"/>
                                          </td> 
                                        </tr>
                                        <tr>
                                            <td class="input-box" colpan="2">
                                                <label>Tel:</label><br>
                                                   <input type="phone" name="tel_entite" maxlength="10"/>
                                         </td>
                                             <td class="input-box">
                                                <label>Email:</label><br>
                                                <input type="email" name="email_entite" maxlength="50"/>
                                             </td> 
                                             </tr>
                                              <tr>
                                                   <td class="input-box">
                                                      <label> Observations:</label><br>
                                                      <textarea name="observation_entite" cols="10" rows="5"style="color:black;" ></textarea> 
                                                         
                                                      
                                                    </td>
                                                </tr>
                                            </table>
                                       </fieldset>                       
                 </div>
                 <button style="width: 150px; height: 50px; color: #FFF; background-color: #0E1C36;margin-top: 220px; margin-left: 390px; border-radius: 20px;padding-top:5px;" type="submit">
                    <span style="font-size: 15px;padding-bottom: 5px;">Ajouter</span></button>
        </div>
    </form>
    </div>



     <script>
         window.onload = function(){
            document.getElementById("popup-10").classList.toggle("active");
         }
        function togglePopup(){
         document.getElementById("popup-10").classList.toggle("active");
         }
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.exploitationEntite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Entite_add.blade.php ENDPATH**/ ?>