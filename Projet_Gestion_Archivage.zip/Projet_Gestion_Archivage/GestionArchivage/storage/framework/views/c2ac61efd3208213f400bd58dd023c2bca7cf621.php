

<?php $__env->startSection('addstyleAdminGP'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleAdminGP.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/stylePopup.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentAdminGP'); ?>

    <div class="headerCRUDStyle"> 
        <a onclick="togglePopup_P1();">
            <i class="fa fa-plus" style="font-size:20px;color:#FFF"></i>
        </a>
        &nbsp;&nbsp;&nbsp;  
        <a href="/listPrivilegeGP_AND_sectionUtilisateurGP">
            <i class="fa fa-edit" style="font-size:19px;color:#FFF"></i>
        </a> 
    </div>
    <?php if(\Session::has('GPd')): ?>
          <div class="alert_erreur" style="text-align: center">
            <?php echo e(\Session::get('GPd')); ?>

          </div>
    <?php endif; ?>
     <?php if(\Session::has('GPu')): ?>
        <div class="alert_green" style="text-align: center">
          <?php echo e(\Session::get('GPu')); ?>

        </div>
    <?php endif; ?>    
    <div class="show_users">
        <table id="customers">
            <tr>
                <th></th>
                <th>Code</th>
                <th>Description</th>
            </tr>

            <?php $i = 0; ?>
            <?php $__currentLoopData = $gp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="click_editGP/<?php echo e($item->id_Privilege); ?>">
                            <i class="fa fa-edit" style="font-size:15px;color:#0E1C36"></i>
                        </a>
                        &nbsp;&nbsp;&nbsp;
                        <a href="click_deleteGP/<?php echo e($item->id_Privilege); ?>">
                            <i class='fas fa-trash' style='font-size:15px;color:#0E1C36'></i>
                        </a>
                    </td>
                    <td><div style="width:170px;" class="cell"><?php echo e($item->Code_Privilege); ?></div></td>
                    <td><div style="width:150px;" class="cell"><?php echo e($item->Description); ?></div></td>
                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $j = 0; ?>
            <?php $__currentLoopData = $gp_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php $j++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <a href="/administration_Groupe_Privilege" class="refrech">
            <i class='fas fa-sync-alt' style='font-size:16px;color:#FFF'></i>
        </a> 
        <div class="countStyle">   
             <?php echo $i; ?> sur <?php echo $j; ?> enregistrements
        </div>       
    </div>

    <!-- Popup ADD GP-->
    <div class="popup" id="popup-1">
        <div class="overlay"></div>
        <div class="content">
          <div class="close-btn" onclick="togglePopup_P1()">×</div>
          <br>
            <form action="/administration_Groupe_Privilege_ADD" method="POST" id="positionForm">
                <?php echo csrf_field(); ?>

                <table>
                    <tr>
                        <td  class="color">Code</td>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" maxlength="20" size="20px" class="styleInput" name="codeGP">
                        </td>
                    </tr>
                    <tr>
                        <td  class="color"><br>Description</td>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" maxlength="50" size="20px" class="styleInput" name="descriptionGP">
                        </td>
                    </tr>
                    
                    <tr>
                        <td><br>
                            <input type="submit" class="btnAdd" value="Ajouter">
                        </td>
                    </tr>    
                </table>
            </form>
        </div>
    </div>
       
    
    
    <script>
    
        function togglePopup_P1(){
        document.getElementById("popup-1").classList.toggle("active");
        }

        function togglePopup_P2(){
        document.getElementById("popup-2").classList.toggle("active");
        }

        

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.adminDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views//administrationGP.blade.php ENDPATH**/ ?>