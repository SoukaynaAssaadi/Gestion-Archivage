
<?php $__env->startSection('addstyleAdminGP'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajoutIndex.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentAdminGPUpdateForm'); ?>
<div class="popup" id="popup-15" >
        <div class="overlay"></div>
        <div class="content">
          <div class="close-btn" onclick="togglePopup_P15()">×</div>
          <br>
            <form action="/exploitation_Nature_Indexation_add" method="POST" >
                <?php echo csrf_field(); ?>
                
                <table>
                    <tr>
                        <td  class="color">Code clés d’indexation</td>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" maxlength="20" size="20px" class="styleInput" name="Code_Index"
                             placeholder="Entrer un nouveau Code!" required>
                        </td>
                    </tr>
                    <tr>
                        <td  class="color"><br>Type</td>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" maxlength="20" size="20px"class="styleInput"  name="Type_Index" required>
                        </td>
                    </tr>
                    <tr>
                        <td  class="color"><br>Valeur</td>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" maxlength="20" size="20px" class="styleInput" name="Valeur_Index">
                        </td>
                    </tr>


                    <tr>
                        <td  class="color"><br>Code Nature de Document</td>
                    </tr>
                    <tr>
                        <td>
                            
                            <select name="code_Nature_Index" style="left:30px; width:290px;position:absolute;border-radius:20px; 
                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" required>
                                <option style="font-size:15px;color:#000;" disabled>--- Choisir Code Nature ---</option>
                                <?php $__currentLoopData = $show_code_nature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option style="font-size:17px;" value="<?php echo e($item->Code_Nature); ?>"><?php echo e($item->Code_Nature); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </select>
                            <br>
                        </td>
                    </tr>


                    <tr>
                        <td  class="color"><br>Description</td>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" maxlength="20" size="20px" class="styleInput" name="description_Index" required>
                        </td>
                    </tr>
                    <tr>
                        <td><br>
                            <input type="submit" class="btnAdd" value="Ajouter">
                        </td>
                    </tr>  
                    
                </table>
            </form>
        </div>
    </div>
    
    <script>
        window.onload = function(){
            document.getElementById("popup-15").classList.toggle("active");
        }
        function togglePopup_P15(){
        document.getElementById("popup-15").classList.toggle("active");
        }
    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admindashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Nature_Indexation_add.blade.php ENDPATH**/ ?>