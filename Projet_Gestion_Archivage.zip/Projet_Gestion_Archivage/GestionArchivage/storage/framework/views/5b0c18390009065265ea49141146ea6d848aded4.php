
<?php $__env->startSection('addstyleversement'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajoutversement.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentversement'); ?>
<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form action="/exploitation_Versement_add" method="POST">
              <?php echo csrf_field(); ?>
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:20px;color:#0E1C36;'>Ajout-Versement</h3>

               <table>
                               
                                  <tr>
                                      <td class="input-box" colspan="2" >
                                         <label style="left:55px;">Entite:</label><br><br>
                                           <select name="entite_Versement_add" style="left:60px; width:580px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" required >
                                               <option style="font-size:15px;color:#000;" disabled>--- Choisir Entitée ---</option>
                                               <?php $__currentLoopData = $show_Entite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option style="font-size:17px;" value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                          </select><br><br>
                                            
                                      </td>
                                 </tr> 
                                  <tr>
                                  
                                      <td class="input-box">
                                              <label style="left:60px">Code:</label>
                                              <input type="text" name="code_Versement_add" maxlength="20" required/>
                                      </td> 
                                       <td class="input-box">
                                             <label style="left:360px">Date Entrée:</label>
                                              <input type="date" name="date_entree_Versement_add" required  />
                                       </td> 
                                      
                                   </tr>
                                   <tr>
                                       <td class="input-box" colspan="2">
                                            <label style="left:60px;"> Description:</label><br><br>
                                            <textarea name="description_Versement_add" cols="40" rows="9"style="left:60px; width:580px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:50px;font-size:15px;" ></textarea> 
                                                         
                                                      
                                        </td>
                                   </tr>    
                            </table>
                            

                  </table>
                  <button type="submit" class="btn">Ajouter </button>  

          </div>
          </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-14").classList.toggle("active");   
      }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.versementDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Versement_add.blade.php ENDPATH**/ ?>