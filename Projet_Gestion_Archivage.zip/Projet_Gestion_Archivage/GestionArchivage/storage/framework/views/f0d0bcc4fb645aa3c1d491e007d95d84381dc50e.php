
<?php $__env->startSection('proposition'); ?>
<div class="show_users">
    <table id="customers">
                <tr>
                    
                    <th></th>
                    <th>N°UA</th>
                    <th>Local</th>
                    <th>Salle</th>
                    <th>Ranger</th>
                    <th>Travet</th>
                    <th>Etage</th>
                    <th>Statut</th>
                    <th>Date Entrée</th>
                    <th>Entité</th>
                    <th>Service</th>
                    <th>Nature</th>
                    <th>Année</th>

              </tr> 
              <?php $i = 0; ?>
            <?php $__currentLoopData = $uarchivage_search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                   
                <td>
                    <div style="width:20px;" class="cell">
                   
                        <a href="/click_cree_DDestruction<?php echo e($item->Numero_UA); ?>">
                          <i class="fa fa-fire" style="font-size:20px;color:#0E1C36;"></i>
                        </a>
                  </div>
             </td>
                    
                    <td><div style="width:50px;" class="cell"><?php echo e($item->Numero_UA); ?></div></td>
                    <td><div style="width:60px;" class="cell"><?php echo e($item->Code_Local_E); ?></div></td>
                    <td><div style="width:60px;" class="cell"><?php echo e($item->Code_Salle_E); ?></div></td>
                    <td><div style="width:60px;" class="cell"><?php echo e($item->Code_Ranger_E); ?></div></td>
                    <td><div style="width:60px;" class="cell"><?php echo e($item->Code_Travet_E); ?></div></td>
                    <td><div style="width:60px;" class="cell"><?php echo e($item->Code_Etage_E); ?></div></td>
                    <td><div style="width:80px;" class="cell"><?php echo e($item->Statut); ?></div></td>
                    <td><div style="width:90px;" class="cell"><?php echo e($item->Date_Entrer); ?></div></td>
                    <td><div style="width:60px;" class="cell"><?php echo e($item->Nom_Entite_E); ?></div></td>
                    <td><div style="width:60px;" class="cell"><?php echo e($item->Code_Service_E); ?></div></td>
                    <td><div style="width:50px;" class="cell"><?php echo e($item->Code_Nature_E); ?></div></td>
                    <td><div style="width:40px;" class="cell"><?php echo e($item->Annee); ?></div></td>
                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $j = 0; ?>
            <?php $__currentLoopData = $uarchivage_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php $j++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <a href="" class="refrech">
            <i class='fas fa-sync-alt' style='font-size:16px;color:#FFF'></i>
        </a> 
        <div class="countStyle">   
             <?php echo $i; ?> sur <?php echo $j; ?> enregistrements
        </div>       
                           
    </div>

           
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.exploitation_PD_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views//exploitation_PD_result_search.blade.php ENDPATH**/ ?>