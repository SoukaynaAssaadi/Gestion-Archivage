

<?php $__env->startSection('styleExploitationEntiteUpdate'); ?>
 <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajoutePrestation.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

      <div class="popup" id="popup-13"> 
          <div class="overlay"></div>
          <form method="POST" action="/exploitation_Prestation_add" >
              <?php echo csrf_field(); ?>
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:24px;color:#0E1C36;'>Ajouter-Prestation</h3>

                
                   
              
                   <label for="fname">Code:</label>
                   <input type="text" name="Code_Prestation" style='width:400px;'maxlength="20" 
                   placeholder="Entrer un nouveau Code !" required><br>
                   <label for="lname">Description:</label>
                   <input type="text"  name="Description_Prestation"style='width:400px;'><br>
                   <button type="submit" class="btn">Ajouter </button>
                  

          

          </div>
          </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-13").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-13").classList.toggle("active");
          }
   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.exploitationEntite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Prestation_add.blade.php ENDPATH**/ ?>