

<?php $__env->startSection('addstyleSortie'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/modifieSortieDefinitive.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentexploitationSortie'); ?>

   <div class="popup" id="popup-5"> 
        <div class="overlay"></div>
        <form action="/exploitation_Sortie_Definitive_Update/<?php echo e($affiche_Demande_Destruction_To_Edit[0]->Numero_Sortie_Definitive); ?>" 
            method="POST">
              <?php echo csrf_field(); ?>
       <div class="content" >
           <div class="close-btn" onclick="togglePopup()">×</div>

           <div class="accordion_area">
                  <div class="accordion_box ">
                      <h3 class="acc_trigger" style='font-size:20px;color:black;' >Sorties définitive-Modification<i class="fa fa-chevron-circle-down" style="font-size:17px"></i></h3>

                        <div class="acc_container">
                         <fieldset>
                            <table> 
                                <tr>
                                    
                                    <td class="input-box"  >
                                      <label style="left:45px;top:100px;">Entité:</label><br>
                                        <select style="left:45px; width:380px;top:150px;position:absolute;border-radius:4px; 
                                         margin-bottom: 5px;color:black;background-color:white;height:35px;"
                                         name="entite_DD_update" maxlength="50" required >
                                            <option disabled>--- Choisir Entité ---</option>
                                            <?php $__currentLoopData = $show_E; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select><br><br>
                                     </td>
                                     <td class="input-box"  >
                                      <label style="left:450px;top:100px;">Statut:</label><br>
                                        <select style="left:450px; width:380px;top:150px;position:absolute;border-radius:4px; 
                                         margin-bottom: 5px;color:black;background-color:white;height:35px;" 
                                         name="statut_DD_update"maxlength="20" required >
                                            <option disabled>--Votre Choix--</option>
                                            <option style="color:black;" >initialisé</option>
                                            <option style="color:black;">Terminé</option>
                                            <option style="color:black;">Validé</option>
                                       </select><br><br>
                                     </td>
                                   
                                </tr>
                                <tr>
                               
                                   <td class="input-box">
                                           <label style="left:45px;top:170px;">Date création:</label><br>
                                           <input type="date" name="date_creation_DD_update" 
                                           style="width:180px;position:absolute;top:175px;left:15px;" 
                                           value="<?php echo e($affiche_Demande_Destruction_To_Edit[0]->Date_Creation); ?>" />
                                   </td> 
                               
                               
                                    <td class="input-box">
                                          <label style="left:250px;top:170px;">Date prévu:</label><br>
                                           <input type="date" name="date_prevu_DD_update"
                                           style="width:170px;left:220px;position:absolute;top:175px;"  
                                           value="<?php echo e($affiche_Demande_Destruction_To_Edit[0]->Date_Prevu); ?>"  />
                                    </td> 
                                   
                                
                                
                                   <td class="input-box"  >
                                      <label style="left:450px;top:170px;">Type:</label><br>
                                        <select style="left:450px; width:380px;top:220px;position:absolute;border-radius:4px; 
                                         margin-bottom: 5px;color:black;background-color:white;height:35px;"
                                         name="type_DD_update" maxlength="20" required >
                                            <option disabled>--Votre Choix--</option>
                                            <option style="color:black;" >Listing des conteneurs</option>
                                            <option style="color:black;" >Ponctuel</option>
                                            <option style="color:black;" >Sortis définitive</option>
                                           
                                     </td>
                                </tr>
                                <tr>
                                    <td class="input-box">
                                           <label style="left:45px;top:240px;">Titre:</label><br>
                                           <input type="text" name="titre_DD_update"
                                            maxlength="50"style="width:380px;position:absolute;top:240px;left:15px;" 
                                            value="<?php echo e($affiche_Demande_Destruction_To_Edit[0]->Titre); ?>" />
                                   </td> 
                                   <td class="input-box">
                                           <label style="left:450px;top:240px;">N°UA:</label><br>
                                           <input type="text" name="numero_ua_DD_update"
                                           value="<?php echo e($affiche_Demande_Destruction_To_Edit[0]->Numero_UA_E); ?>" maxlength="50"
                                           style="width:380px;position:absolute;top:240px;left:420px;" />
                                   </td> 
                                </tr>
                                </tr>
                                <tr>
                                   <td class="input-box">
                                     <label style="left:450px;top:300px;font-size:18px;"> Commentaires:</label><br>
                                     <textarea name="commentaire_DD_update" cols="25" rows="2"style="left:450px; width:380px;top:350px;position:absolute;border-radius:4px; 
                                     margin-bottom: 5px;color:black;background-color:white;height:50px;font-size:15px;" >
                                     <?php echo e($affiche_Demande_Destruction_To_Edit[0]->Commentaire); ?></textarea> 
                                     </td>
                                     <td class="input-box">
                                             <label style="left:45px;top:300px;">Numero voyage:</label><br>
                                             <input type="text" name="numero_voyage_DD_update" 
                                             maxlength="11"style="width:380px;position:absolute;top:310px;left:15px;" 
                                             value="<?php echo e($affiche_Demande_Destruction_To_Edit[0]->Numero_Voyage_E); ?>" />
                                     </td>
                                </tr>    
                               
                   </table>      
                   

                      <button type="submit" class="btn"style="top:270px;left:800px;font-size:15px;position:absolute;">Modifier </button>
                       
                   </fieldset>         

                       </div>
                        
                  </div>
        </div>
                          
           <div class="accordion_area">
                  <div class="accordion_box ">
                      <h3 class="acc_trigger" style='font-size:20px;color:black;' >UA<i class="fa fa-chevron-circle-down" style="font-size:17px"></i></h3>

                      <div class="acc_container">
                        <div class="show_users">
                          <table id="customers">
                                <tr>
                                   <th>N°UA</th>
                                   <th>Statut</th>
                                   <th>Location</th>
                                  
                                 </tr> 
                                 <?php $i = 0; ?>
            <?php $__currentLoopData = $afficher_UA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                       
                    
                    <td><div  class="cell" style="width:80px;text-align:left;"><?php echo e($item->Numero_UA); ?></div></td>
                    <td><div class="cell" style="width:150px;text-align:left;"><?php echo e($item->Statut); ?></div></td>
                    <td><div class="cell" style="width:400px;text-align:left;">
                        <?php echo e($item->Code_Local_E); ?> * <?php echo e($item->Code_Salle_E); ?> * <?php echo e($item->Code_Ranger_E); ?> * 
                        <?php echo e($item->Code_Travet_E); ?> * <?php echo e($item->Code_Etage_E); ?>

                    </div></td>
                   
    
                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
        </table>
            
                           </table>
                        </div>
                      </div>
                  </div>
             </div>
             <div class="accordion_area">
                  <div class="accordion_box ">
                      <h3 class="acc_trigger" style='font-size:20px;color:black;' >Voyages<i class="fa fa-chevron-circle-down" style="font-size:17px"></i></h3>

                      <div class="acc_container">
                        <div class="show_users">
                          <table id="customers">
                                <tr>
                                  <th>  <a href="/exploitation_DD_Voyage_form_add"> <i class="fa fa-plus" style="font-size:20px;color:#0E1C36"></i></a>  </th>
                                   <th>N°</th>
                                   <th>Date Sortie</th>
                                   <th>Quantité</th>
                                   <th>Moyen Transport</th>
                                   <th>Poid</th>
                                   <th>Commentaire</th>
                                  
                                 </tr>
                                 <?php $i = 0; ?>
            <?php $__currentLoopData = $afficher_Voyage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="/click_delete_exploitation_DD_Voyage/<?php echo e($item->Numero_Voyage); ?>'">
                            <i class='fas fa-trash' style='font-size:15px;color:#0E1C36;margin-left:4px;'></i>
                        </a>
                    </td>
                    <td><div  class="cell" style="width:70px;text-align:left;"><?php echo e($item->Numero_Voyage); ?></div></td>
                    <td><div  class="cell" style="width:150px;text-align:left;"><?php echo e($item->Date_Sortie); ?></div></td>
                    <td><div  class="cell" style="width:150px;text-align:left;"><?php echo e($item->Quantite); ?></div></td>
                    <td><div class="cell" style="width:150px;text-align:left;" ><?php echo e($item->Moyen_Transport); ?></div></td>
                    <td><div  class="cell" style="width:80px;text-align:left;"><?php echo e($item->Poid); ?></div></td>
                   <td><div class="cell" style="width:150px;text-align:left;" ><?php echo e($item->Commentaire); ?></div></td>
                   
                    
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
        </table>
          
                           </table>
                        </div>
                      </div>
                  </div>
             </div>

                          
            </form>
   </div>

<script>
    window.onload = function(){
        document.getElementById("popup-5").classList.toggle("active");
    }
   function togglePopup(){
    document.getElementById("popup-5").classList.toggle("active");
    }
 </script>
 <script>

$(document).ready(function(){
$('.accordion_box:first').addClass('active')
$('.accordion_box:first').children('.acc_trigger').children('i').addClass('fa-minus')
$('.accordion_box:first').children('.acc_trigger').addClass('selected').next('.acc_container').show()


  $('.acc_trigger').click(function(event){
         if($(this).hasClass('selected')){
           $(this).removeClass('selected');
           $(this).children('i').removeClass('fa-minus');
           $(this).next().slideUp();
           $(this).parent().removeClass('active');

         }else{
               $('.acc_trigger').removeClass('selected');
               $(this).addClass('selected');
               $('.acc_trigger').children('i').removeClass('fa-minus');
               $(this).children('i').addClass('fa-minus');
               $('.acc_trigger').next().slideUp();
               $(this).next().slideDown();
               $('.accordion_box').removeClass('active');
               $(this).parent().addClass('active');



         }

  });

});
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.exploitation_Sortie_Dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Demande_Destruction_Update.blade.php ENDPATH**/ ?>