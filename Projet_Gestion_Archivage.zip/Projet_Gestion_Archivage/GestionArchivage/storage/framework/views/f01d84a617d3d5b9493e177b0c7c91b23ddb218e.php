

<?php $__env->startSection('addstyleemplacementt'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleAdminGP.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/stylePopup.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentemplacement'); ?>

    <div class="headerCRUDStyle"> 
        <a href="/emplacement_Ranger_form_add">
            <i class="fa fa-plus" style="font-size:20px;color:#FFF"></i>
        </a>
    </div>
    <?php if(\Session::has('emplacement_Ranger_add')): ?>
    <div class="alert_green" style="text-align: center">
      <?php echo e(\Session::get('emplacement_Ranger_add')); ?>

    </div>
    <?php endif; ?>
    <?php if(\Session::has('emplacement_Ranger_delete')): ?>
        <div class="alert_erreur" style="text-align: center">
            <?php echo e(\Session::get('emplacement_Ranger_delete')); ?>

        </div>
    <?php endif; ?>
    <?php if(\Session::has('emplacement_Ranger_Impossible_delete')): ?>
        <div class="alert_erreur" style="text-align: center; height: 60px;padding-top:20px;">
            <?php echo e(\Session::get('emplacement_Ranger_Impossible_delete')); ?>

        </div>
    <?php endif; ?>
    <?php if(\Session::has('emplacement_Ranger_update')): ?>
        <div class="alert_green" style="text-align: center">
            <?php echo e(\Session::get('emplacement_Ranger_update')); ?>

        </div>
    <?php endif; ?>
       
    <div class="show_users">
        <table id="customers">
            <tr>
                <th></th>
                <th>Local</th>
                <th>Salle</th>
                <th>Code</th>
                <th>Nb Places</th>
                <th>Description</th>
                
            </tr>

            <?php $i = 0; ?>
            <?php $__currentLoopData = $emplacement_Ranger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                
                    <td>
                    <div style="width:60px;" class="cell">
                   
                        <a href="/click_edit_Ranger/<?php echo e($item->Code_Ranger); ?>">
                            <i class="fa fa-edit" style="font-size:15px;color:#0E1C36;" ></i>
                        </a>
                        
                        <a href="/click_delete_Ranger/<?php echo e($item->Code_Ranger); ?>">
                            <i class='fas fa-trash' style='font-size:15px;color:#0E1C36;margin-left:20px;'></i>
                        </a>
                        </div>
                    </td>
                    
                    
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Code_Local_E); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Code_Salle_E); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Code_Ranger); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Nombre_Place); ?></div></td>
                    <td><div style="width:290px;" class="cell"><?php echo e($item->Description); ?></div></td>
                   
                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $j = 0; ?>
            <?php $__currentLoopData = $emplacement_Ranger_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php $j++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
               <a href="" class="refrech">
                 <i class='fas fa-sync-alt' style='font-size:16px;color:#FFF'></i>
              </a> 
                 <div class="countStyle">   
                     <?php echo $i; ?> sur <?php echo $j; ?> enregistrements
                  </div>       
    </div>

    
       
    
    
    <script>
    
        function togglePopup_P1(){
        document.getElementById("popup-1").classList.toggle("active");
        }

        function togglePopup_P2(){
        document.getElementById("popup-2").classList.toggle("active");
        }

    
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.emplacementDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/emplacement_Ranger.blade.php ENDPATH**/ ?>