
<?php $__env->startSection('addstyleversement'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajoutunite.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentversement'); ?>
<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form action="/exploitation_UA_add" method="POST">
              <?php echo csrf_field(); ?>
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:22px;color:#0E1C36;'>UA-Ajout</h3>

               <table>
                               
                                  <tr>
                                      <td class="input-box"  >
                                         <label style="left:55px;">Entite:</label><br>
                                           <select name="entite_UA" style="left:60px; width:400px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" maxlength="20" required >
                                              <option style="font-size:15px;" disabled>--- Choisir Entitée ---</option>
                                              <?php $__currentLoopData = $all_entite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option style="font-size:17px;" value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                          </select><br><br>
                                            
                                      </td>
                                 
                                 
                                      <td class="input-box"  >
                                         <label style="left:500px;">Service:</label><br>
                                           <select name="service_UA" style="left:500px; width:400px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" maxlength="20" required >
                                              <option style="font-size:15px;" disabled>--- Choisir Service ---</option>
                                              <?php $__currentLoopData = $all_service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option style="font-size:17px;" value="<?php echo e($item->Code_Service); ?>"><?php echo e($item->Code_Service); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                          </select><br><br>
                                            
                                      </td>
                                 </tr> 
                                 <tr>
                                 <td class="input-box"  >
                                         <label style="left:55px;">Nature:</label><br>
                                           <select name="nature_UA" style="left:60px; width:400px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" maxlength="20" required >
                                               <option style="font-size:15px;" disabled>--- Choisir Nature de Document ---</option>
                                               <?php $__currentLoopData = $all_nature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <option style="font-size:17px;" value="<?php echo e($item->Code_Nature); ?>"><?php echo e($item->Nom); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                           </select><br><br>
                                            
                                      </td>
                                 
                                 
                                      <td class="input-box"  >
                                         <label style="left:500px;">Versement:</label><br>
                                           <select name="versement_UA" style="left:500px; width:400px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" maxlength="20" required >
                                               <option style="font-size:15px;" disabled>--- Choisir Versement ---</option>
                                               <?php $__currentLoopData = $all_versement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <option style="font-size:17px;" value="<?php echo e($item->Code_Versement); ?>"><?php echo e($item->Code_Versement); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                           </select><br><br>
                                            
                                      </td>
                                 </tr> 
                                  <tr>
                                  
                                      <td class="input-box">
                                          
                                              <label style="left:60px;">Date Entrée:</label><br>
                                              <input type="date" name="date_entree_UA" required/>
                                            
                                      </td> 
                                       <td class="input-box">
                                           
                                             <label style="left:500px">Année de Création:</label><br>
                                              <input type="text"  name="anne_creation_UA"  maxlength="4"/>
                                             
                                       </td> 
                                      
                                   </tr>
                                   <tr>
                                  
                                      <td class="input-box">
                                            <br>
                                              <label style="left:60px">N° UA Du:</label><br>
                                              <input type="text" name="numero_du_UA" maxlength="50" required/>
                                            
                                      </td> 
                                       <td class="input-box">
                                           <br>
                                             <label style="left:500px">-Au:</label><br>
                                              <input type="text" name="a_UA" required  />
                                              
                                       </td> 
                                      
                                   </tr>
                                   <tr>
                                       <td class="input-box">
                                           <br>
                                             <label style="left:60px">Statut:</label><br>
                                             <select name="statut_UA" style="left:60px; width:400px;position:absolute;border-radius:4px; 
                                             margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" maxlength="20" required>
                                               <option style="font-size:15px;" disabled>--- Votre Choix ---</option>
                                               <option>Normal</option>
                                               <option>A retourner</option>
                                               <option>Détruit</option>
                                               <option>En Consultation</option>
                                               <option>En-cours de création</option>
                                               <option>En-cours transfert</option>
                                               <option>Extrait</option>
                                               <option>Marqué pour destruction</option>
                                               <option>Marqué pour transfert</option>
                                             </select> 
                                             <br><br>
                                            
                                       </td> 
                                       <td class="input-box" colspan="2">
                                           
                                            <label style="left:500px;top:400px;"> Commentaires:</label><br>
                                            <textarea name="commentaire_UA" cols="20" rows="9" style="left:500px;top:425px; width:400px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:40px;font-size:15px;" ></textarea> 
                                                         
                                                      
                                        </td>
                                   </tr>    
                            </table>
                  </table>
                  <button type="submit" class="btn">Ajouter</button>
                   
          </div>
          </form>
        </div>

  <script>
        window.onload = function(){
            document.getElementById("popup-14").classList.toggle("active"); 
        }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.versementDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_UA_add.blade.php ENDPATH**/ ?>