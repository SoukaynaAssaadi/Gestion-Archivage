   

<?php $__env->startSection('content'); ?>

    <div class="show_users">
        <table id="customers">
        <tr>
            <th>Login</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>CIN</th>
            <th>Téléphone</th>
            <th>Adresse</th>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($item->Login); ?></th>
            <th><?php echo e($item->Nom); ?></th>
            <th><?php echo e($item->CIN); ?></th>
            <th><?php echo e($item->Prenom); ?></th>
            <th><?php echo e($item->Tel); ?></th>
            <th><?php echo e($item->Adresse); ?></th>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </table>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views//test.blade.php ENDPATH**/ ?>