<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Accueil</title>
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/menu.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleAdmin.css')); ?>">

   <?php echo $__env->yieldContent('addstyleemplacementt'); ?>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajoutUtilisateur.css')); ?>">

  <script src="<?php echo e(asset('assets/JQuery/menuJQuery.js')); ?>"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
   <div class="dashbord">
    <nav class="sidebar">
            <div class="text">
                Archive+
            </div>
         <div class="scrolling">
         <ul>
         <li>
               <a href="#" class="emplacement-btn">
                  <i class='fas fa-archive'></i>&nbsp;&nbsp;&nbsp;Emplacement
                   <span class="fas fa-caret-down emplacement"></span>
               </a>
              
               <ul class="emplacement-show">
                  <li><a href="/emplacement_Local">Local</a></li>
                  <li><a href="/emplacement_Salle">Salle</a></li>
                  <li><a href="/emplacement_Ranger">Ranger</a></li>
                  <li><a href="/emplacement_Travet">Travet</a></li>
                  <li><a href="/emplacement_Etage">Etage</a></li>
                  <li><a href="/emplacement_Affecter_Doc">Affectation</a></li>
               </ul>
            </li>
         </ul>
      </div>
      </nav>
   </div>
   <div class="search_users_inside_list">

        <?php echo $__env->yieldContent('contentemplacement'); ?>

    </div>

    <?php echo $__env->yieldContent('contentemplacementEE'); ?>
      <script>
      $('.administration-btn').click(function(){
         $('nav ul .administration-show').toggleClass("show");
         $('nav ul .first').toggleClass("rotate");
      });

      $('.emplacement-btn').click(function(){
         $('nav ul .emplacement-show').toggleClass("show1");
         $('nav ul .emplacement').toggleClass("rotate");
      });

      $('.exploitation-btn').click(function(){
         $('nav ul .exploitation-show').toggleClass("show2");
         $('nav ul .exploitation').toggleClass("rotate");
      });

      $('.TA-btn').click(function(){
         $('nav ul .TA-show').toggleClass("show3");
         $('nav ul .TA').toggleClass("rotate");
      });

      $('.integration-btn').click(function(){
         $('nav ul .integration-show').toggleClass("show4");
         $('nav ul .integration').toggleClass("rotate");
      });

      $('.recherche-btn').click(function(){
         $('nav ul .recherche-show').toggleClass("show5");
         $('nav ul .recherche').toggleClass("rotate");
      });

      $('.retour-btn').click(function(){
         $('nav ul .retour-show').toggleClass("show6");
         $('nav ul .retour').toggleClass("rotate");
      });

      $('.saisie-btn').click(function(){
         $('nav ul .saisie-show').toggleClass("show7");
         $('nav ul .resaisietour').toggleClass("rotate");
      });

      $('nav ul li').click(function(){
         $(this).addClass("active").siblings().removeClass("active");
      });

      </script>
</body>
</html>

<?php /**PATH C:\wamp\www\GestionArchivage\resources\views/layouts/emplacementDashbord.blade.php ENDPATH**/ ?>