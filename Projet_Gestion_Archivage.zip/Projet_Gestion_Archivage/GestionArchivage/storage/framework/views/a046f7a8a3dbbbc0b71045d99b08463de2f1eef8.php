
<?php $__env->startSection('styleExploitationEntiteUpdate'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajouterCorrespondants.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

   <div class="popup" id="popup-13"> 
        <div class="overlay"></div>
        <form action="/exploitation_Correspondant_add" method="POST">
            <?php echo csrf_field(); ?>
     <div class="content" >
         <div class="close-btn" onclick="togglePopup()">×</div>

           <h3 style='font-size:30px;color:#0E1C36;'>Correspondant-Ajout</h3>
           <div class="custom-info">


                          <fieldset>
                           <table>
                                <legend>Infos Contact</legend>
                                  <tr>
                                      <td class="input-box"  >
                                           <label>Nom:</label><br>
                                            <input type="text" name="nom_correspondant_add" maxlength="20" required/>
                                            
                                      </td> 
                                  
                                  
                                        <td class="input-box">
                                              <label>Prénom:</label><br>
                                              <input type="text" name="prenom_correspondant_add" maxlength="20" required/>
                                      </td> 
                                   </tr> 
                                   <tr>
                                        <td class="input-box">
                                             <label>Entité:</label>
                                             <br>
                                            <select name="entite_correspondant_add" style="color:#000;height:30px;font-size:15px;width:205px;background-color:#FFF;" required>
                                                <option style="font-size:15px;color:#000;" readonly>--- Choisir Entites ---</option>
                                                <?php $__currentLoopData = $affiche_Entite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option style="font-size:17px;" value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                            </select>
                                            
                                       </td> 
                                       <td class="input-box">
                                             <label>Code:</label><br>
                                              <input type="text" name="code_correspondant_add" maxlength="50" required/>
                                       </td> 
                                   </tr>
                                   <tr>
                                       <td class="input-box">
                                             <label>Tel:</label><br>
                                              <input type="phone" name="tel_correspondant_add" maxlength="10" required/>
                                       </td> 
                                       <td class="input-box">
                                             <label>Fax:</label><br>
                                              <input type="phone" name="fax_correspondant_add" maxlength="20" required/>
                                       </td> 
                                   </tr>
                                   <tr>
                                       <td class="input-box">
                                             <label>Email:</label><br>
                                              <input type="email" name="email_correspondant_add" maxlength="50" required/>
                                       </td> 
                                          <td class="input-box">
                                                      <label> Observations:</label><br>
                                                      <textarea name="observation_correspondant_add" cols="10" rows="2"style="color:black;" ></textarea> 
                                                         
                                                      
                                                    </td>
                                   </tr>
                                    
                            </table>
                            
                        </fieldset> 
                        <fieldset>
                             <legend>Infos Adresse</legend>
                                <table>
                                     <tr>
                                       <td class="input-box" >
                                            <label>Ville:</label><br>
                                             <input type="text" name="ville_correspondant_add" maxlenght="20" required/>
                                      </td>
                                      <td class="input-box">
                                             <label>Code Postal:</label><br>
                                             <input type="text" name="code_postal_correspondant_add" maxlenght="11" required/>
                                     </td> 
                                     </tr> 
                                      <tr>  
                                           <td class="input-box" colpan="2">
                                                  <label>Pays:</label><br>
                                                     <input type="text" name="pays_correspondant_add" maxlenght="20" required/>
                                           </td> 
                                           <td class="input-box">
                                                    <label>Adresse:</label><br>
                                                    <input type="text" name="adresse_correspondant_add" maxlenght="20" required/>
                                          </td> 
                                        </tr>
                                        <tr>
                                            <td class="input-box">
                                                
                                                <input type="radio" name="check_type_add" value="Actif"><span style="color: #000;"> Actif ?</span>
                                                
                                            </td>
                                            <td class="input-box">
                                                <input type="radio" name="check_type_add" value="Majeur"><span style="color: #000;"> Majeur ?<span>
                                            </td>
                                        </tr>
                                        
                                            </table>
                                       </fieldset>
                                       
                 </div>
                 <button style="width: 150px; height: 50px; color: #FFF; background-color: #0E1C36;margin-top: 170px; margin-left: 380px; border-radius: 20px;padding-top:7px;" type="submit">
        <span style="font-size: 15px;padding-bottom: 5px;">Ajouter</span></button>


        </div>
     </form>
</div>

    

     <script>
         window.onload = function(){
            document.getElementById("popup-13").classList.toggle("active");
         }
        function togglePopup(){
         document.getElementById("popup-13").classList.toggle("active");
         }
      </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.exploitationEntite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Correspondant_add.blade.php ENDPATH**/ ?>