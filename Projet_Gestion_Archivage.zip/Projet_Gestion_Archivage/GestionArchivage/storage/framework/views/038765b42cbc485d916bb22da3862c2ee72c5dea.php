


<?php $__env->startSection('addstyleAdminGP'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleAdminGP.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentAdminGP'); ?>

    <div class="headerCRUDStyle"> 
        <a href="/exploitation_Prestation_form_add">
            <i class="fa fa-plus" style="font-size:20px;color:#FFF"></i>
        </a>
        
    </div>
    
    <?php if(\Session::has('exploitation_Prestation_add')): ?>
          <div class="alert_green" style="text-align: center">
            <?php echo e(\Session::get('exploitation_Prestation_add')); ?>

          </div>
    <?php endif; ?>
    <?php if(\Session::has('exploitation_Prestation_delete')): ?>
          <div class="alert_erreur" style="text-align: center">
            <?php echo e(\Session::get('exploitation_Prestation_delete')); ?>

          </div>
    <?php endif; ?>
       
    <div class="show_users">
        <table id="customers">
            <tr>
                <th></th>
                <th style="text-align:left;">Code</th>
                <th style="text-align:left;">Description</th>
            </tr>

            <?php $i = 0; ?>
            <?php $__currentLoopData = $ePrestation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                
                    <td>
                    <div style="width:20px;" class="cell">
                
                       
                        <a href="/click_delete_Prestation/<?php echo e($item->Code_Prestation); ?>">
                            <i class='fas fa-trash' style='font-size:15px;color:#0E1C36;left:50px;'></i>
                        </a>
                        </div>
                    </td>
                    
                    
                    <td><div style="width:300px;text-align:left;" class="cell"><?php echo e($item->Code_Prestation); ?></div></td>
                    <td><div style="width:600px;text-align:left;" class="cell"><?php echo e($item->Description); ?></div></td>
                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $j = 0; ?>
            <?php $__currentLoopData = $ePrestation_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php $j++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
               <a href="" class="refrech">
                 <i class='fas fa-sync-alt' style='font-size:16px;color:#FFF'></i>
              </a> 
                 <div class="countStyle">   
                     <?php echo $i; ?> sur <?php echo $j; ?> enregistrements
                  </div>       
    </div>

       
    
    
    <script>
    
        function togglePopup_P1(){
        document.getElementById("popup-1").classList.toggle("active");
        }

        function togglePopup_P2(){
        document.getElementById("popup-2").classList.toggle("active");
        }

        

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Prestation.blade.php ENDPATH**/ ?>