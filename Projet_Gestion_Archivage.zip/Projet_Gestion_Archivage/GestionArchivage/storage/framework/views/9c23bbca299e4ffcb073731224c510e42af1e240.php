

<?php $__env->startSection('addstyleAdminGP'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/styleAdminGP.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/stylePopup.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentAdminGP'); ?>

    <div class="headerCRUDStyle"> 
        <a href="/exploitation_Entite_form_add">
            <i class="fa fa-plus" style="font-size:20px;color:#FFF"></i>
        </a>
         
    </div>
    <?php if(\Session::has('exploitation_Entite_add')): ?>
          <div style="width: 100%;
          padding-top: 10px;
          padding-bottom: 10px;
          background-color:#B0E0E6;
          color: #4169E1;text-align: center">
            <?php echo e(\Session::get('exploitation_Entite_add')); ?>

          </div>
    <?php endif; ?>   
    <?php if(\Session::has('exploitation_Entite_delete')): ?>
          <div style="width: 100%;
          padding-top: 10px;
          padding-bottom: 10px;
          background-color:#FFC0CB;
          color: #B22222;;text-align: center">
            <?php echo e(\Session::get('exploitation_Entite_delete')); ?>

          </div>
    <?php endif; ?>
    <?php if(\Session::has('Entite_Modifier')): ?>
          <div style="width: 100%;
          padding-top: 10px;
          padding-bottom: 10px;
          background-color:#B0E0E6;
          color: #4169E1;text-align: center">
            <?php echo e(\Session::get('Entite_Modifier')); ?>

          </div>
    <?php endif; ?>
    <?php if(\Session::has('Service_Modifier')): ?>
          <div style="width: 100%;
          padding-top: 10px;
          padding-bottom: 10px;
          background-color:#FFC0CB;
          color: #B22222;;text-align: center">
            <?php echo e(\Session::get('Service_Modifier')); ?>

          </div>
    <?php endif; ?>
    <?php if(\Session::has('Service_Ajouter')): ?>
          <div style="width: 100%;
          padding-top: 10px;
          padding-bottom: 10px;
          background-color:#B0E0E6;
          color: #4169E1;text-align: center">
            <?php echo e(\Session::get('Service_Ajouter')); ?>

          </div>
    <?php endif; ?>
    <div class="show_users">
        <table id="customers">
            <tr>
                <th></th>
                <th>Nom_Entite</th>
                <th>Code_Entite</th>
                <th>Tel</th>
                <th>Ville</th>
                <th>Code_Postal</th>
                <th>Observations</th>
            </tr>

            <?php $i = 0; ?>
            <?php $__currentLoopData = $eEntite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                    <div style="width:60px;" class="cell">
                    
                        <a href="/click_edit_Entite/<?php echo e($item->nom_entite); ?>">
                            <i class="fa fa-edit" style="font-size:15px;color:#0E1C36"></i>
                        </a>
                        &nbsp;&nbsp;&nbsp;
                    
                        <a href="/click_delete_Entite/<?php echo e($item->nom_entite); ?>">
                            <i class='fas fa-trash' style='font-size:15px;color:#0E1C36;'></i>
                        </a>
                    </div>
                    </td>
                    
                    
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Code_Entite); ?></div></td>
                    <td><div style="width:130px;" class="cell"><?php echo e($item->nom_entite); ?></div></td>
                    <td><div style="width:150px;" class="cell"><?php echo e($item->Tel); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Ville); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Code_Postal); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Observation); ?></div></td>
                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $j = 0; ?>
            <?php $__currentLoopData = $eEntite_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php $j++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
               <a href="/EntiteController" class="refrech">
                 <i class='fas fa-sync-alt' style='font-size:16px;color:#FFF'></i>
              </a> 
                 <div class="countStyle">   
                     <?php echo $i; ?> sur <?php echo $j; ?> enregistrements
                  </div>       
    </div>

    <!-- Popup ADD GP-->
    <div class="popup" id="popup-1">
        <div class="overlay"></div>
        <div class="content">
          <div class="close-btn" onclick="togglePopup_P1()">×</div>
          <br>
            <form action="/administration_Groupe_Privilege_ADD" method="POST" id="positionForm">
                <?php echo csrf_field(); ?>

                <table>
                    <tr>
                        <td  class="color">Code</td>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" maxlength="20" size="20px" class="styleInput" name="codeGP">
                        </td>
                    </tr>
                    <tr>
                        <td  class="color"><br>Description</td>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" maxlength="50" size="20px" class="styleInput" name="descriptionGP">
                        </td>
                    </tr>
                    
                    <tr>
                        <td><br>
                            <input type="submit" class="btnAdd" value="Ajouter">
                        </td>
                    </tr>    
                </table>
            </form>
        </div>
    </div>
       
    
    
    <script>
    
        function togglePopup_P1(){
        document.getElementById("popup-1").classList.toggle("active");
        }

        function togglePopup_P2(){
        document.getElementById("popup-2").classList.toggle("active");
        }

        

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Entite.blade.php ENDPATH**/ ?>