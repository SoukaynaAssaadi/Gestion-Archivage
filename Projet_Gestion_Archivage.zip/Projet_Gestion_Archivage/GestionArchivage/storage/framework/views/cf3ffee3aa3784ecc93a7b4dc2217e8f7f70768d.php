

<?php $__env->startSection('contentexploitation'); ?>

<div class="search_users_inside_list">
      
    <form method="POST" action="/exploitation_Versement_Update/<?php echo e($affiche_Versement_To_Edit[0]->Code_Versement); ?>" >
        <?php echo csrf_field(); ?>

         <fieldset style="width: 980px; ">
            <legend class="stylelegend" >Versement-Modification   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </legend>
            <div class="">
               <label style="color:black;left:20px;position:absolute;">Entité</label><br>
               <select name="entite_Versement_update" style="left:20px; width:580px;border-radius:4px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" >
                    <option style="font-size:15px;color:#000;" disabled>--- Choisir Entite ---</option>
                    <?php $__currentLoopData = $affich_entite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option style="font-size:17px;" value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </select><br><br>
                                            
            </div>
            <div class="left">
               <label >Code</label><br>
               <input type="text" maxlength="20" name="code_Versement_update" style="width:200px; padding-left:5px;" 
               value="<?php echo e($affiche_Versement_To_Edit[0]->Code_Versement); ?>">
            </div>
            <div class="left">
               <label>Date Entrée</label><br>
               <input type="Date"  name="date_entree_Versement_update"style="width:200px;"
                value="<?php echo e($affiche_Versement_To_Edit[0]->Date_Entrer); ?>">
            </div>
            <div class="left">
               <label>Description</label><br>
               <textarea name="description_Versement_update" cols="40" rows="11"style="left:60px; width:400px;border-radius:4px; 
                margin-bottom: 5px;color:black;background-color:white;font-size:15px;height:70px;">
                <?php echo e($affiche_Versement_To_Edit[0]->Description); ?></textarea> 
            </div>
            <button type="submit" class="btn_search" ><i class="fa fa-check" aria-hidden="true" 
                style="color:black;size:800px;top:140px;font-size:30px;position:absolute;"></i></button>
         </fieldset>
       
         <fieldset style="width: 980px;">
              <legend class="stylelegend" >Unité d'archivage   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               </legend>
               <div class="show_users">
        <table id="customers">
            <tr>
                
                <th>N°UA</th>
                <th>Local</th>
                <th>Ranger</th>
                <th>Travet</th>
                <th>Etage</th>
                <th>Statut</th>
                <th>Date Entrée</th>
                <th>Service</th>
                <th>Nature</th>
                <th>Année</th>
            </tr>

            <?php $i = 0; ?>
            <?php $__currentLoopData = $affich_UA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                
                    
                    <td><div style="width:40px;" class="cell"><?php echo e($item->Numero_UA); ?></div></td>
                    <td><div style="width:50px;" class="cell"><?php echo e($item->Code_Local_E); ?></div></td>
                    <td><div style="width:50px;" class="cell"><?php echo e($item->Code_Ranger_E); ?></div></td>
                    <td><div style="width:50px;" class="cell"><?php echo e($item->Code_Travet_E); ?></div></td>
                    <td><div style="width:50px;" class="cell"><?php echo e($item->Code_Etage_E); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Statut); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Date_Entrer); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Code_Service_E); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Code_Nature_E); ?></div></td>
                    <td><div style="width:80px;" class="cell"><?php echo e($item->Annee); ?></div></td>
                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
                
                <?php $j = 0; ?>
                <?php $__currentLoopData = $affich_UA_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php $j++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
     
        <div class="countStyle"> <?php echo $i; ?> sur <?php echo $j; ?> enregistrements</div>       
    </div>
              


      
         </fieldset>
      </form>

    

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.versementDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_Versement_Update.blade.php ENDPATH**/ ?>