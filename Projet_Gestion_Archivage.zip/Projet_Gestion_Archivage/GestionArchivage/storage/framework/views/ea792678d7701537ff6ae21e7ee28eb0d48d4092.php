

<?php $__env->startSection('addstyleversement'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/modifieunite.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentversement'); ?>
 
<div class="popup" id="popup-14"> 
        <div class="overlay"></div>
        <form  method="POST" action="/exploitation_UA_Update/<?php echo e($affiche_UA_To_Edit[0]->Numero_UA); ?>">
            <?php echo csrf_field(); ?>
        
     <div class="content" >
         <div class="close-btn" onclick="togglePopup()">×</div>

           <h3 style='font-size:25px;color:#0E1C36;'>UA-Modification</h3>
           <div class="custom-info">


                          <fieldset>
                          <legend>Infos UA</legend>
                           <table>
                                
                                  <tr>
                                      <td class="input-box"  >
                                         <label style="left:20px;position:absolute;">Entite:</label><br>
                                           <select style="left:45px; width:250px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" maxlength="20" 
                                            name="entite_UA_update" >
                                               <option style="font-size:15px;color:#000;" disabled>--- Choisir Entitée ---</option>
                                               <?php $__currentLoopData = $all_entite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option style="font-size:17px;" value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                           </select><br><br>
                                    
                                        </td>
                                        <td class="input-box"  >
                                         <label style="left:290px;position:absolute;">Service:</label><br>
                                           <select style="left: 310px; width:250px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" maxlength="20" 
                                            name="service_UA_update" >
                                              <option style="font-size:15px;color:#000;" disabled>--- Choisir Service ---</option>
                                              <?php $__currentLoopData = $all_service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option style="font-size:17px;" value="<?php echo e($item->Code_Service); ?>"><?php echo e($item->Code_Service); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                          </select>><br><br>
                                    
                                        </td>
                                    </tr>
                                    <tr>
                                  
                                      <td class="input-box"  >
                                         <label style="left:40px;position:absolute;">Versement:</label><br>
                                           <select style="left:45px; width:250px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" maxlength="20" 
                                            name="versement_UA_update">
                                              <option style="font-size:15px;color:#000;" disabled>--- Choisir Versement ---</option>
                                              <?php $__currentLoopData = $all_versement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option style="font-size:17px;" value="<?php echo e($item->Code_Versement); ?>"><?php echo e($item->Code_Versement); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                          </select><br><br>
                                      </td>
                            
                                            
                                          <td class="input-box">
                                          <td class="input-box"  >
                                         <label style="left:290px;position:absolute;">Nature Document:</label><br>
                                           <select style="left: 310px; width:250px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" maxlength="20" 
                                            name="nature_UA_update" >
                                               <option style="font-size:15px;color:#000;" disabled>--- Choisir Nature de document ---</option>
                                               <?php $__currentLoopData = $all_nature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option style="font-size:17px;" value="<?php echo e($item->Code_Nature); ?>"><?php echo e($item->Nom); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                           </select><br><br>
                                    
                                        </td>
                                      </td>
                                  </tr>
                                            
                                    <tr>        
                                       <td class="input-box">
                                             <label style="left:45px;">Date Entrée:</label><br>
                                              <input type="date" value="<?php echo e($affiche_UA_To_Edit[0]->Date_Entrer); ?>" 
                                              name="date_entree_UA_update"/>
                                       </td> 
                                   
                                   
                                       <td class="input-box">
                                             <label style="left:310px;">Année de création:</label><br>
                                              <input type="text" value="<?php echo e($affiche_UA_To_Edit[0]->Annee); ?>" maxlength="4"
                                              name="annee_creation_UA_update"/>
                                       </td> 
                                   </tr>
                                   <tr>
                                       <td class="input-box">
                                             <label style="left:15px;">N°UA:</label><br>
                                              <input type="text" name="N_UA_update" maxlength="50" value="<?php echo e($affiche_UA_To_Edit[0]->Numero_UA); ?>"/>
                                       </td> 
                                   
                                
                                       <td class="input-box">
                                             <label style="left:285px;">Statut:</label><br>
                                             
                                              <select name="statut_UA_update" style="left: 310px; width:250px;position:absolute;border-radius:4px; 
                                              margin-bottom: 5px;color:black;background-color:white;height:40px;font-size:15px;" maxlength="20">
                                                <option style="font-size:15px;" disabled>--- Votre Choix ---</option>
                                                <option>Normal</option>
                                                <option>A retourner</option>
                                                <option>Détruit</option>
                                                <option>En Consultation</option>
                                                <option>En-cours de création</option>
                                                <option>En-cours transfert</option>
                                                <option>Extrait</option>
                                                <option>Marqué pour destruction</option>
                                                <option>Marqué pour transfert</option>
                                              </select> 
                                              <br><br>
                                        </td> 
                                  </tr>
                                  <tr>
                                          <td class="input-box">
                                                      <label style="left:45px;"> Commentaire:</label><br>
                                                      <textarea name="commentaire_UA_update" cols="25" rows="16"style="left:45px; width:510px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:115px;font-size:15px;" ><?php echo e($affiche_UA_To_Edit[0]->Commentaire); ?></textarea> 
                                                         
                                                      
                                                    </td>
                                   </tr>
                                    
                            </table>
                            
                        </fieldset> 
                        <fieldset>
                             
                                <table>
                                <legend>Infos Adresse</legend>
                                    
                                  <tr>
                                      <td class="input-box"  >
                                         <label style="left:570px;position:absolute;">Local:</label><br>
                                           <select style="left:600px; width:250px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" 
                                            maxlength="20" name="local_UA_update" >
                                               <option style="font-size:15px;color:#000;" disabled>--- Choisir Local ---</option>
                                               <?php $__currentLoopData = $all_local; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option style="font-size:17px;" value="<?php echo e($item->Code_Local); ?>"><?php echo e($item->Code_Local); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                           </select><br><br>
                                     
                                        </td>
                                  </tr>
                                  <tr>
                                
                                        <td class="input-box"  >
                                         <label style="left:570px;position:absolute;">Salle:</label><br>
                                           <select style="left:600px; width:250px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;"
                                             maxlength="20" name="salle_UA_update" >
                                               <option style="font-size:15px;color:#000;" disabled>--- Choisir Salle ---</option>
                                               <?php $__currentLoopData = $all_salle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option style="font-size:17px;" value="<?php echo e($item->Code_Salle); ?>"><?php echo e($item->Code_Salle); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                           </select><br><br>
                                    
                                        </td>
                                    </tr>
                                    <tr>
                                  
                                      <td class="input-box"  >
                                         <label style="left:583px;position:absolute;">Ranger:</label><br>
                                           <select style="left:600px; width:250px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" 
                                            maxlength="20" name="rager_UA_update" >
                                               <option style="font-size:15px;color:#000;" disabled>--- Choisir Ranger ---</option>
                                               <?php $__currentLoopData = $all_ranger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option style="font-size:17px;" value="<?php echo e($item->Code_Ranger); ?>"><?php echo e($item->Code_Ranger); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                           </select>><br><br>
                                      </td>
                                  </tr>
                                  <tr>
                                      
                                            
                                          <td class=""  >
                                         <label style="left:600px;color:black;position:absolute;">Travet:</label><br>
                                           <select style="left:600px; width:250px;border-radius:4px;position:absolute; 
                                            margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" 
                                            maxlength="20" name="travet_UA_update" >
                                               <option style="font-size:15px;color:#000;" disabled>--- Choisir Travet ---</option>
                                               <?php $__currentLoopData = $all_travet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option style="font-size:17px;" value="<?php echo e($item->Code_Travet); ?>"><?php echo e($item->Code_Travet); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                           </select><br><br>
                                      </td>
                                  </tr>
                                  <tr>
                                      
                                            
                                      <td class=""  >
                                     <label style="left:600px;color:black;position:absolute;">Etage:</label><br>
                                       <select style="left:600px; width:250px;border-radius:4px;position:absolute; 
                                        margin-bottom: 5px;color:black;background-color:white;height:30px;font-size:15px;" 
                                        maxlength="20" name="etage_UA_update" >
                                           <option style="font-size:15px;color:#000;" disabled>--- Choisir Etage ---</option>
                                           <?php $__currentLoopData = $all_etage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <option style="font-size:17px;" value="<?php echo e($item->Code_Etage); ?>"><?php echo e($item->Code_Etage); ?></option>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                       </select><br><br>
                                  </td>
                              </tr>
                                   <tr>
                                       <td class="input-box">
                                             <label style="left:600px">Date Destruction Prévu:</label><br>
                                              <input type="date" name="date_destruction_UA_update" maxlength="10"
                                               value="<?php echo e($affiche_UA_To_Edit[0]->Date_Destruction); ?>"/>
                                       </td> 
                                   </tr>
                                            </table>
                                       </fieldset>
                                       
                 </div>
                 <button style="width: 150px; height: 50px; color: #FFF; background-color: #0E1C36;margin-top: 295px; margin-left: 20px; border-radius: 20px;" type="submit; font-size: 1px;">
        <span style="font-size: 15px;padding-bottom: 5px;">Modifier</span></button>


        </div>
     </form>
</div>

    

     <script>
         window.onload = function(){
            document.getElementById("popup-14").classList.toggle("active");
         }
        function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
         }
      </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.versementDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/exploitation_UA_Update.blade.php ENDPATH**/ ?>