

<?php $__env->startSection('addstyleAdminGP'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/stylePopupAdmin_U_update.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentAdminGP'); ?>

   <div class="popup" id="popup-5"> 
        <div class="overlay"></div>
       <div class="content" >
           <div class="close-btn" onclick="togglePopup_P5()">×</div>

           <div class="accordion_area">
                  <div class="accordion_box ">
                      <h3 class="acc_trigger" style='font-size:20px;color:black;' >Section Modification 
                        <i class="fa fa-chevron-circle-down" style="font-size:17px"></i></h3>

                        <div class="acc_container">
                        <div class="custom-info">


<fieldset>
    <legend>Infos Connexion</legend>
    <form method="POST" action="/administrationU_A_E">
        <?php echo csrf_field(); ?>
 <table>
      
     
          
      
        <tr>
            <td class="input-box"  >
                 <label>Login:</label><br>
                  <input type="text" name="loginU_update" disabled/>
                  
            </td> 
              <td class="input-box">
                    <label>Mot de passe:</label><br>
                    <input type="password" name="passwordU_update" disabled/>
            </td> 
         </tr> 
        <tr>  
             <td class="input-box" colpan="2">
                 <label>Confirmation MDP:</label><br>
                 <input type="password" name="c_passwordU_update" disabled/>
            </td> 
              <td class="input-box">
                   <label>Date Création:</label><br>
                    <input type="Date" name="date_creationU_update" disabled/>
             </td> 
         </tr>
          <tr>
                <td class="input-box">
                    <label>Statut:</label><br>
                     <input type="text" name="statutU_update" disabled/>
               </td> 

                  <td class="input-box">
                           <label>Date Début:</label><br>
                          <input type="Date" name="date_debutU_update" disabled/>
                 </td> 
         </tr>
           <tr>
                  <td class="input-box">
                           <label>Date fin:</label><br>
                           <input type="Date" name="date_finU_update" disabled/>
                   </td>
                 <td class="input-box">
                           <label>Dernier changement MDP:</label><br>
                            <input type="Date" name="d_c_U_update" disabled/>
                </td> 
         </tr>
  </table>
  
</fieldset> 
<fieldset>
   <legend>Infos Personnelles</legend>
      <table>
           <tr>
             <td class="input-box" >
                  <label>Nom:</label><br>
                   <input type="text" name="nomU_update" disabled/>
            </td>
            <td class="input-box">
                   <label>Prénom:</label><br>
                   <input type="text" name="prenomU_update" disabled/>
           </td> 
           </tr> 
            <tr>  
                 <td class="input-box" >
                        <label>Tel:</label><br>
                           <input type="text" name="telU_update" disabled/>
                 </td> 
                 <td class="input-box">
                          <label>Email:</label><br>
                          <input type="email" name="emailU_update" disabled/>
                </td> 
              </tr>
              <tr>
                   <td class="input-box">
                         <label>CIN:</label><br>
                         <input type="text" name="cinU_update" disabled/>
                 </td> 

                   <td class="input-box">
                      <label>Adresse:</label><br>
                      <input type="text" name="adresseU_update" disabled/>
                   </td> 
                   </tr>
                    <tr>
                         <td class="input-box">
                            <label> Ville:</label><br>
                                   <input type="text" name="villeU_update" disabled/>
                          </td>
                         <td class="input-box">
                                  <label>Pays:</label><br>
                                  <input type="text" name="paysU_update" disabled/>
                        </td> 
                        </tr>
                         <tr>
                           <td class="input-box">
                                 <label>Commentaires</label><br>
                                <input type="text" name="commentairesU_update" disabled/>
                         </td> 
                       </tr>
                  </table>
             </fieldset>
             
         </div>
         <button type="submit" disabled style="border:none;margin-left:420px;margin-top:160px;"><i class="fa fa-check" style='font-size:25px;color:#0E1C36;'></i></button>

                        </div>
                  </div>
        </div>
                          
        <div class="accordion_area">
                  <div class="accordion_box ">
                      <h3 class="acc_trigger" style='font-size:20px;color:black;' >Liste Entité<i class="fa fa-chevron-circle-down" style="font-size:17px"></i></h3>

                        <div class="acc_container">   

                        <table id="customers">
                            
                            <tr>
                                <th>
                                    <button type="submit" style="border:none;top:130px;left:60px;padding:0px;background-color: #749ce6"><i class="fa fa-check" style='font-size:25px;color:#0E1C36;'></i></button>
                                </th>
                                <th>Entité</th>
                            </tr>                             
                            <tr>
                                <td>
                                    <div style="width:60px;" class="cell">
                                        
                                    </div>
                                </td>
                                <td>
                                    <div style="width:800px;" class="cell">
                                        <select name="selectEntite" style="width: 100%; color: #000;font-size: 16px;">
                                            <option selected disabled>--- Choisir une Entite ---</option>
                                            <?php $__currentLoopData = $entite_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>    
                                    </div>
                                </td>
                            </tr>
                       
               
           </table>
                    </form>

                      
                    </div>

                    </div>
               </div>
       </div>                 
                          

   </div>
   <div>


  

<script>
    window.onload = function(){
        document.getElementById("popup-5").classList.toggle("active");
    }
   function togglePopup_P5(){
    document.getElementById("popup-5").classList.toggle("active");
    }
 </script>
 <script>

$(document).ready(function(){
$('.accordion_box:first').addClass('active')
$('.accordion_box:first').children('.acc_trigger').children('i').addClass('fa-minus')
$('.accordion_box:first').children('.acc_trigger').addClass('selected').next('.acc_container').show()


  $('.acc_trigger').click(function(event){
         if($(this).hasClass('selected')){
           $(this).removeClass('selected');
           $(this).children('i').removeClass('fa-minus');
           $(this).next().slideUp();
           $(this).parent().removeClass('active');

         }else{
               $('.acc_trigger').removeClass('selected');
               $(this).addClass('selected');
               $('.acc_trigger').children('i').removeClass('fa-minus');
               $(this).children('i').addClass('fa-minus');
               $('.acc_trigger').next().slideUp();
               $(this).next().slideDown();
               $('.accordion_box').removeClass('active');
               $(this).parent().addClass('active');



         }

  });

});
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views//administration_U_affect_entite.blade.php ENDPATH**/ ?>