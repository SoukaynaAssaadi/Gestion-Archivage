
<?php $__env->startSection('contentSortie'); ?>

<form method="POST" action="/exploitation_Sortie_PD">
         <?php echo csrf_field(); ?>

      
         <fieldset style="width: 980px; ">
            <legend class="stylelegend">Section Recherche   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              
            </legend>
              <div class="left">
               <label style="color:black;top:45px;position:absolute;">Entité:</label><br>
               <select style=" width:200px;border-radius:4px;top:70px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
               name="etite_PD_search" maxlength="50" required>
                    <option disabled>--- Choisir Entité ---</option>
                    <?php $__currentLoopData = $show_entite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->Nom_Entite); ?>"><?php echo e($item->Nom_Entite); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
              </div>
              <div class="left">
               <label style="color:black;left:220px;position:absolute;top:45px;">Versement:</label><br>
               <select style="left:220px; width:200px;border-radius:4px;position:absolute;top:70px;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
               name="versement_PD_search" maxlength="20"required>
                    <option disabled>--- Choisir un versement ---</option>
                    <?php $__currentLoopData = $show_versement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->Code_Versement); ?>"><?php echo e($item->Code_Versement); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                                            
            </div>
            <div class="left">
               <label style="color:black;left:430px;top:45px;position:absolute;">Service Doc:</label><br>
               <select style="left:425px; width:200px;border-radius:4px;top:70px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
               name="service_PD_search" maxlength="20" required>
                    <option disabled>--- Choisir Service ---</option>
                    <?php $__currentLoopData = $show_service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->Code_Service); ?>"><?php echo e($item->Code_Service); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                                            
            </div>
            <div class="left">
               <label style="color:black;left:635px;top:45px;position:absolute;">Nature Doc:</label><br>
               <select style="left:635px; width:200px;border-radius:4px;top:70px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
               name="nature_PD_search" maxlength="20"required >
                   <option disabled>--- Choisir Nature de Document ---</option>
                   <?php $__currentLoopData = $show_nature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option value="<?php echo e($item->Code_Nature); ?>"><?php echo e($item->Code_Nature); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select><br><br><br><br>
                                            
            </div>
            <div class="left">
               <label style="position:absolute;top:45px;color:black;left:850px;">Année:</label><br>
               <input type="text" maxlength="4" name="annee_PD_search"
               style=" border-radius: 5px;color: #000;top:70px;left:850px;position:absolute;width:120px;" required>
            </div>
            <div class="left">
               <label style="color:black;top:100px;position:absolute;left:15px;">Statut:</label><br>
               <select style=" width:200px;border-radius:4px;top:125px;position:absolute;left:15px;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
               name="statut_PD_search"  required>
                    <option disabled>--Votre Choix--</option>
                    <option style="color:black;" >Normal</option>
                    <option style="color:black;" >A Retourner</option>
                    <option style="color:black;" >Détruit</option>
                    <option style="color:black;" >En Consultation</option>
                    <option style="color:black;" >En-cours de création</option>
                    <option style="color:black;">En-cours transfert</option>
                    <option style="color:black;">Extrait</option>
                    <option style="color:black;">Marqué pour destruction</option>
                    <option style="color:black;">Marqué pour transfert</option>
                    <option style="color:black;">Initialisé</option>
                    <option style="color:black;">Terminé</option> 
                    <option style="color:black;">Validé</option>                   
                 </select>
              </div>
              <div class="left">
               <label style="position:absolute;top:100px;color:black;left:220px;">N°du:</label><br>
               <input type="text" maxlength="50" name="n_du_PD_search"
               style=" border-radius: 5px;color: #000;top:125px;left:220px;position:absolute;width:140px;" required>
              </div>
              <div class="left">
               <label style="position:absolute;top:100px;color:black;left:365px;">au:</label><br>
               <input type="text" maxlength="50" name="au_PD_search"
               style=" border-radius: 5px;color: #000;top:124px;left:365px;position:absolute;width:140px;"required>
              </div>
              <div class="left">
               <label style="color:black;left:515px;top:100px;position:absolute;">Local:</label><br>
               <select style="left:515px; width:200px;border-radius:4px;top:124px;position:absolute;
               margin-bottom: 5px;color:black;background-color:white;font-size:15px;" 
               name="local_PD_search" maxlength="20"required >
                <option disabled>--- Choisir Local ---</option>
                <?php $__currentLoopData = $show_local; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->Code_Local); ?>"><?php echo e($item->Code_Local); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select><br><br><br><br>
                                            
            </div>
           
            <button type="submit" ><i class="fa fa-search" style="font-size:25px;color:black;left:910px;position:absolute;top:125px;"></i></button>
        </fieldset>          
        <?php if(\Session::has('exploitation_Sortie_PD_creer')): ?>
            <div class="alert_green" style="text-align: center">
              <?php echo e(\Session::get('exploitation_Sortie_PD_creer')); ?>   
            </div>
          <?php endif; ?> 
</form>

<?php echo $__env->yieldContent('proposition'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.exploitation_Sortie_Dashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/layouts/exploitation_PD_form.blade.php ENDPATH**/ ?>