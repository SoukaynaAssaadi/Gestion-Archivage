
<?php $__env->startSection('addstyleemplacementt'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajoutSalle.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentemplacement'); ?>
<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form action="/emplacement_Salle_add" method="POST">
            <?php echo csrf_field(); ?>
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Salle-Ajout</h3>        
                   <table>
                     
                                  <tr>
                                  
                                      <td class="input-box">
                                              <label style="left:45px">Nom:</label><br>
                                              <input type="text" name="nom_Salle" maxlength="20" required/>
                                      </td> 
                                  
                                  
                                       <td class="input-box">
                                             <label style="left:365px">Code:</label><br>
                                              <input type="text" name="code_Salle" maxlength="20" required  />
                                       </td> 
                                      
                                   </tr>
                                   <tr>
                                       <td class="input-box" style="top:160px;position:absolute;">
                                             <label style="left:20px;position:absolute;"> Places Disponibles:</label><br>
                                              <input type="number" name="place_Disponible_Salle" 
                                              min="1" max="9000000"/>
                                       </td> 
                                       <td class="input-box"  >
                                         <label style="left:365px;top:160px">Local:</label><br>
                                           <select style="left:360px; width:300px;top:230px;position:absolute;border-radius:4px; 
                                            margin-bottom: 5px;color:black;background-color:white;height:35px;font-size:15px;"
                                             maxlength="20" name="local_Salle_add" >
                                               <option style="font-size:15px;color:#000;" disabled>--- Votre Choix ---</option>
                                               <?php $__currentLoopData = $show_local; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option style="font-size:15px;" value="<?php echo e($item->Code_Local); ?>"><?php echo e($item->Code_Local); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select><br><br>
                                        </td>
                                      
                                   </tr>
                            
                                   </table>              
                
                                   <button type="submit" class="btn">Ajouter </button>
    
          </div>
          </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-14").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.emplacementDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/emplacement_Salle_add.blade.php ENDPATH**/ ?>