
<?php $__env->startSection('addstyleemplacementt'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/ajoutLocal.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contentemplacement'); ?>
<div class="popup" id="popup-14"> 
          <div class="overlay"></div>
          <form  method="POST" action="/emplacement_Local_Update/<?php echo e($affiche_Local_To_Edit[0]->Code_Local); ?>">
            <?php echo csrf_field(); ?>
            
          <div class="content" >
              <div class="close-btn" onclick="togglePopup()">×</div>

               <h3 style='font-size:25px;color:#0E1C36;'>Local-Modification</h3>
                   
                   <table>
                                  <tr>
                                  
                                      <td class="input-box">
                                              <label style="left:60px">Nom:</label>
                                              <input type="text" name="nom_Local_update" maxlength="20" 
                                              value="<?php echo e($affiche_Local_To_Edit[0]->Nom); ?>"/>
                                              
                                      </td> 
                                  </tr>
                                  <tr>
                                       <td class="input-box">
                                             <label style="left:60px">Code:</label>
                                              <input type="text" name="code_Local_update" maxlength="20" 
                                              placeholder="Entrer un nouveau Code!" 
                                              value="<?php echo e($affiche_Local_To_Edit[0]->Code_Local); ?>"  />
                                       </td> 
                                      
                                   </tr>
                                   <tr>
                                       <td class="input-box">
                                             <label style="left:60px"> Places Disponibles:</label>
                                              <input type="number" name="place_disponible_Local_update" 
                                              min="1" max="9000000" 
                                              value="<?php echo e($affiche_Local_To_Edit[0]->Place_Disponible); ?>"/>
                                       </td> 
                                      
                                   </tr>
                            
                                   </table>              
                
                                   <button type="submit" class="btn">Modifier </button>

          </div>
          </form>
        </div>

  <script>
      window.onload = function(){
        document.getElementById("popup-14").classList.toggle("active");
      }
         function togglePopup(){
         document.getElementById("popup-14").classList.toggle("active");
          }
   </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.emplacementDashbord', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views/emplacement_Local_Update.blade.php ENDPATH**/ ?>