
<?php $__env->startSection('tableau'); ?>

<div class="show_users">
    <table id="customers">
                <tr>
                    
                    <th></th>
                    <th>N°</th>
                    <th>UA</th>
                    <th>Statut</th>
                    <th>Libellé</th>
                    <th>Entité</th>
                    <th>Service</th>
                    <th>Nature</th>
                    <th>Date Livraison</th>
                    
                </tr>
                
                
                <?php $i = 0; ?>
            <?php $__currentLoopData = $DO_search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <div style="width:40px;" class="cell">
                        <a href="/ti_Recherche_DO_print_Doc/<?php echo e($item->Numero_Demande); ?>" >
                            
                            <i class="fa fa-print" 
                            style="font-size:19px;color:black; margin-left:8px;">
                            </i>
                            
                        </a>
                        </div>
                    </td>
                    <td><div style="width:60px;" class="cell"><?php echo e($item->Numero_Demande); ?></div></td>
                    <td><div style="width:50px;" class="cell"><?php echo e($item->Numero_UA_E); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Statut); ?></div></td>
                    <td><div style="width:90px;" class="cell"><?php echo e($item->Libelle); ?></div></td>
                    <td><div style="width:100px;" class="cell"><?php echo e($item->Nom_Entite_E); ?></div></td>
                    <td><div style="width:90px;" class="cell"><?php echo e($item->Code_Service_E); ?></div></td>
                    <td><div style="width:80px;" class="cell"><?php echo e($item->Code_Nature_E); ?></div></td>
                    <td><div style="width:70px;" class="cell"><?php echo e($item->Date_Livraison); ?></div></td>
                </tr>
                <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $j = 0; ?>
            <?php $__currentLoopData = $DO_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php $j++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <a href="" class="refrech">
            <i class='fas fa-sync-alt' style='font-size:16px;color:#FFF'></i>
        </a> 
        <div class="countStyle">   
             <?php echo $i; ?> sur <?php echo $j; ?> enregistrements
        </div>       
                     
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.travaux_Interieure_Recherche_DO_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\GestionArchivage\resources\views//travaux_interieure_Recherche_DO_result_search.blade.php ENDPATH**/ ?>