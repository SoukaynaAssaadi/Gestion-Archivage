<?php

use Illuminate\Support\Facades\Route;
use App\Utilisateur;
use Illuminate\Http\Request;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/registre', 'RegisterController@formulaire');
Route::post('/registre', 'RegisterController@traitement');

Route::get('/login', 'LoginController@formulaire');
Route::post('/login', 'LoginController@traitement');

Route::get('/changerMDP', 'Forget_PasswordController@formulaire');
Route::post('/changerMDP', 'Forget_PasswordController@traitement');

//  Administration 

// Groupe Privilege

Route::get('/administration', 'AdministrationController@formulaire');
Route::post('/administration', 'AdministrationController@traitement');

Route::get('/administration', 'AdministrationController@formulaire');
Route::post('/administration', 'AdministrationController@traitement');

// for Refrech
Route::get('/administration_Groupe_Privilege', 'administration_Groupe_Privilege_Controller@traitement');

Route::post('/administration_Groupe_Privilege_ADD', 'administration_Groupe_Privilege_Controller@insertion');

Route::get('/click_editGP/{id_Privilege}', 'administration_Groupe_Privilege_Controller@editGP_function');
Route::post('/formUpdateGP/{id_Privilege}', 'administration_Groupe_Privilege_Controller@updateGP_function');

Route::get('/click_deleteGP/{id_Privilege}', 'administration_Groupe_Privilege_Controller@deleteGP_function');


Route::get('/listPrivilegeGP_AND_sectionUtilisateurGP', 'administration_Groupe_Privilege_Controller@listPrivilegeGP_sectionUtilisateur_function');
Route::get('/listPrivilegeGP', 'administration_Groupe_Privilege_Controller@listPrivilegeGP_function');
//Route::post('/ajouter_Privilege_InDataBase', 'administration_Groupe_Privilege_Controller@addPrivilege_function');

Route::get('/click_deleteListPrivilegeGP/{id_Liste_Privilege}', 'administration_Groupe_Privilege_Controller@deleteListPrivilegeGP_function');
Route::get('/click_deleteSectionUtilisateurGP/{id_Utilisateur}', 'administration_Groupe_Privilege_Controller@deleteSectionUtilisateurGP_function');

Route::get('/softDeleteListePrivilege/{id_list_privilege}', 'administration_Groupe_Privilege_Controller@deleteListPrivilegeGP_function');

Route::get('/lpGP_and_suGP_not_null', 'administration_Groupe_Privilege_Controller@lpGP_and_suGP_not_null_function');

Route::post('/click_Button_Affecter', 'administration_Groupe_Privilege_Controller@click_Button_Affecter_function');

// Utilisateurs

Route::get('/administrationU_add', 'AdministrationUserController@formulaire');
Route::post('/administrationU_ADD_data_base', 'AdministrationUserController@insertion');

Route::get('/click_deleteU/{id_utilisateur}', 'AdministrationUserController@deleteU_function');
Route::get('/administration_show', 'AdministrationController@traitement');

Route::get('/click_editU/{id_utilisateur}', 'AdministrationUserController@editU_function');
Route::post('/administrationU_update', 'AdministrationUserController@updateU_function');

// Exploitation 

// Entite
Route::get('/exploitation_Entite', 'Exploitation_Entite_Controller@showTable');
Route::get('/exploitation_Entite_form_add', 'Exploitation_Entite_Controller@exploitation_Entite_form_add_function');

Route::post('/exploitation_Entite_add', 'Exploitation_Entite_Controller@exploitation_Entite_add_function');

Route::get('/click_delete_Entite/{Nom_Entite}', 'Exploitation_Entite_Controller@delete_Entite_function');

Route::get('/click_edit_Entite/{Nom_Entite}', 'Exploitation_Entite_Controller@edit_Entite_function');
Route::post('/administration_Entite_update/{Nom_Entite}', 'Exploitation_Entite_Controller@update_Entite_function');

Route::get('/click_deleteService/{Code_Service}', 'Exploitation_Entite_Controller@click_deleteService_function');

Route::get('/exploitation_Service_form_add', 'Exploitation_Entite_Controller@exploitation_Service_form_add_function');
Route::post('/exploitation_Service_add', 'Exploitation_Entite_Controller@exploitation_Service_add_function');

// Correspondant
Route::get('/exploitation_Correspondant', 'Exploitation_Correspondant_Controller@showTable');
Route::get('/exploitation_Correspondant_form_add', 'Exploitation_Correspondant_Controller@exploitation_Correspondant_form_add_function');

Route::post('/exploitation_Correspondant_add', 'Exploitation_Correspondant_Controller@exploitation_Correspondant_add_function');

Route::get('/click_delete_Correspondant/{Code_Correspondant}', 'Exploitation_Correspondant_Controller@delete_Correspondant_function');

Route::get('/click_edit_Correspondant/{Code_Correspondant}', 'Exploitation_Correspondant_Controller@edit_Correspondant_function');
Route::post('/exploitation_Correspondant_update/{Code_Correspondant}', 'Exploitation_Correspondant_Controller@update_Correspondant_function');

// Nature
Route::get('/exploitation_Nature', 'Exploitation_Nature_Controller@showTable');
Route::get('/exploitation_Nature_form_add', 'Exploitation_Nature_Controller@exploitation_Nature_form_add_function');

Route::post('/exploitation_Nature_add', 'Exploitation_Nature_Controller@exploitation_Nature_add_function');

Route::get('/click_delete_Nature/{Code_Nature}', 'Exploitation_Nature_Controller@delete_Nature_function');

Route::get('/click_edit_Nature/{Code_Nature}', 'Exploitation_Nature_Controller@edit_Nature_function');
Route::post('/exploitation_Nature_update/{Code_Nature}', 'Exploitation_Nature_Controller@update_Nature_function');

Route::get('/click_Nature_Indexation/{Code_Nature}', 'Exploitation_Nature_Controller@nature_Show_Indaxation_function');

Route::get('/exploitation_Nature_Indexation_form_add', 'Exploitation_Nature_Controller@exploitation_Nature_Indexation_form_add_function');

Route::post('/exploitation_Nature_Indexation_add', 'Exploitation_Nature_Controller@exploitation_Nature_Indexation_add_function');

Route::get('/nature_Show_Indax_After', 'Exploitation_Nature_Controller@nature_Show_Indaxation_function_After');

Route::get('/click_delete_Nature_Index/{Code_Index}', 'Exploitation_Nature_Controller@delete_Nature_Index_function');

// Prestations
Route::get('/exploitation_Prestation', 'Exploitation_Prestation_Controller@showTable');
Route::get('/exploitation_Prestation_form_add', 'Exploitation_Prestation_Controller@exploitation_Prestation_form_add_function');

Route::post('/exploitation_Prestation_add', 'Exploitation_Prestation_Controller@exploitation_Prestation_add_function');

Route::get('/click_delete_Prestation/{Code_Prestation}', 'Exploitation_Prestation_Controller@delete_Prestation_function');


// Exploitation

// Versements
Route::get('/exploitation_Versement', 'Exploitation_Versement_Controller@showTable');
Route::get('/exploitation_Versement_form_add', 'Exploitation_Versement_Controller@exploitation_Versement_form_add_function');

Route::post('/exploitation_Versement_add', 'Exploitation_Versement_Controller@exploitation_Versement_add_function');

Route::get('/click_delete_Versement/{Code_Versement}', 'Exploitation_Versement_Controller@delete_Versement_function');

Route::get('/click_edit_Versement/{Code_Versement}', 'Exploitation_Versement_Controller@edit_Versement_function');
Route::post('/exploitation_Versement_Update/{Code_Versement}', 'Exploitation_Versement_Controller@update_Versement_function');

// Unité d'archivage

Route::get('/exploitation_UA', 'Exploitation_UA_Controller@showTable');
Route::get('/exploitation_UA_form_add', 'Exploitation_UA_Controller@exploitation_UA_form_add_function');

Route::post('/exploitation_UA_add', 'Exploitation_UA_Controller@exploitation_UA_add_function');

Route::get('/click_delete_UA/{Numero_UA}', 'Exploitation_UA_Controller@delete_UA_function');

Route::get('/click_edit_UA/{Numero_UA}', 'Exploitation_UA_Controller@edit_UA_function');
Route::post('/exploitation_UA_Update/{Numero_UA}', 'Exploitation_UA_Controller@update_UA_function');

// Emplacement

// Local
Route::get('/emplacement_Local', 'Emplacement_Local_Controller@showTable');
Route::get('/emplacement_Local_form_add', 'Emplacement_Local_Controller@emplacement_Local_form_add_function');

Route::post('/emplacement_Local_add', 'Emplacement_Local_Controller@emplacement_Local_add_function');

Route::get('/click_delete_Local/{Code_Local}', 'Emplacement_Local_Controller@delete_Local_function');

Route::get('/click_edit_Local/{Code_Local}', 'Emplacement_Local_Controller@edit_Local_function');
Route::post('/emplacement_Local_Update/{Code_Local}', 'Emplacement_Local_Controller@update_Local_function');

// Salle
Route::get('/emplacement_Salle', 'Emplacement_Salle_Controller@showTable');
Route::get('/emplacement_Salle_form_add', 'Emplacement_Salle_Controller@emplacement_Salle_form_add_function');

Route::post('/emplacement_Salle_add', 'Emplacement_Salle_Controller@emplacement_Salle_add_function');

Route::get('/click_delete_Salle/{Code_Salle}', 'Emplacement_Salle_Controller@delete_Salle_function');

Route::get('/click_edit_Salle/{Code_Salle}', 'Emplacement_Salle_Controller@edit_Salle_function');
Route::post('/emplacement_Salle_Update/{Code_Salle}', 'Emplacement_Salle_Controller@update_Salle_function');

// Ranger
Route::get('/emplacement_Ranger', 'Emplacement_Ranger_Controller@showTable');
Route::get('/emplacement_Ranger_form_add', 'Emplacement_Ranger_Controller@emplacement_Ranger_form_add_function');

Route::post('/emplacement_Ranger_add', 'Emplacement_Ranger_Controller@emplacement_Ranger_add_function');

Route::get('/click_delete_Ranger/{Code_Ranger}', 'Emplacement_Ranger_Controller@delete_Ranger_function');

Route::get('/click_edit_Ranger/{Code_Ranger}', 'Emplacement_Ranger_Controller@edit_Ranger_function');
Route::post('/emplacement_Ranger_Update/{Code_Ranger}', 'Emplacement_Ranger_Controller@update_Ranger_function');

// Travet
Route::get('/emplacement_Travet', 'Emplacement_Travet_Controller@showTable');
Route::get('/emplacement_Travet_form_add', 'Emplacement_Travet_Controller@emplacement_Travet_form_add_function');

Route::post('/emplacement_Travet_add', 'Emplacement_Travet_Controller@emplacement_Travet_add_function');

Route::get('/click_delete_Travet/{Code_Travet}', 'Emplacement_Travet_Controller@delete_Travet_function');

Route::get('/click_edit_Travet/{Code_Travet}', 'Emplacement_Travet_Controller@edit_Travet_function');
Route::post('/emplacement_Travet_Update/{Code_Travet}', 'Emplacement_Travet_Controller@update_Travet_function');

// Etage
Route::get('/emplacement_Etage', 'Emplacement_Etage_Controller@showTable');
Route::get('/emplacement_Etage_form_add', 'Emplacement_Etage_Controller@emplacement_Etage_form_add_function');

Route::post('/emplacement_Etage_add', 'Emplacement_Etage_Controller@emplacement_Etage_add_function');

Route::get('/click_delete_Etage/{Code_Etage}', 'Emplacement_Etage_Controller@delete_Etage_function');

Route::get('/click_edit_Etage/{Code_Etage}', 'Emplacement_Etage_Controller@edit_Etage_function');
Route::post('/emplacement_Etage_Update/{Code_Etage}', 'Emplacement_Etage_Controller@update_Etage_function');

// Travaux Intérieure

// Saisie
Route::get('/ti_Saisie', 'TI_Saisie_Controller@showDashbord');
Route::get('/ti_Saisie_Inventaire', 'TI_Saisie_Controller@showInventaire');

Route::post('/ti_Saisie_Inventaire', 'TI_Saisie_Controller@traitement_recherche');

Route::get('/ti_Saisie_Inventaire_show_table', 'TI_Saisie_Controller@showTable');

Route::get('/ti_Saisie_Inventaire_form_add', 'TI_Saisie_Controller@ti_Saisie_Inventaire_form_add_function');

Route::post('/ti_Saisie_Inventaire_add', 'TI_Saisie_Controller@ti_Saisie_Inventaire_add_function');

Route::get('/click_delete_Saisie_Inventaire/{id_Inventaire}', 'TI_Saisie_Controller@delete_ti_Saisie_Inventaire_function');

Route::get('/click_edit_Saisie_Inventaire/{id_Inventaire}', 'TI_Saisie_Controller@edit_ti_Saisie_Inventaire_function');
Route::post('/ti_Saisie_Inventaire_Update/{id_Inventaire}', 'TI_Saisie_Controller@update_ti_Saisie_Inventaire_function');

// Recherche
// Demande de Recherche
Route::get('/ti_Recherche', 'TI_Recherche_Controller@showDashbord');
Route::get('/ti_Recherche_DR', 'TI_Recherche_Controller@show_DR');

Route::post('/ti_Recherche_DR', 'TI_Recherche_Controller@traitement_recherche');

Route::get('/ti_Recherche_DR_form_add', 'TI_Recherche_Controller@ti_Recherche_DR_form_add_function');

Route::post('/ti_Recherche_DR_add', 'TI_Recherche_Controller@ti_Recherche_DR_add_function');

Route::get('/click_delete_ti_Recherche_DR/{Numero_Demande}', 'TI_Recherche_Controller@delete_ti_Recherche_DR_function');

Route::get('/click_edit_ti_Recherche_DR/{Numero_Demande}', 'TI_Recherche_Controller@edit_ti_Recherche_DR_function');
Route::post('/ti_Recherche_DR_Update/{Numero_Demande}', 'TI_Recherche_Controller@update_ti_Recherche_DR_function');

// Demande Originaux
Route::get('/ti_Recherche_DO', 'TI_Recherche_DO_Controller@show_DO');

Route::post('/ti_Recherche_DO', 'TI_Recherche_DO_Controller@traitement_recherche');

Route::get('/ti_Recherche_DO_print_Doc/{Numero_Demande}', 'TI_Recherche_DO_Controller@print_Doc_Originaux_function');

// Retour
// Bordereau
Route::get('/ti_Retour', 'TI_Retour_Controller@showDashbord');
Route::get('/ti_Retour_Bordereau', 'TI_Retour_Controller@show_Bordereau_form');

Route::post('/ti_Retour_Bordereau', 'TI_Retour_Controller@traitement_recherche');

Route::get('/ti_Retour_form_add', 'TI_Retour_Controller@ti_Retour_form_add_function');

Route::post('/ti_Retour_add', 'TI_Retour_Controller@ti_Retour_add_function');

Route::get('/click_delete_ti_Retour_Bordereau/{Numero_Bordereau}', 'TI_Retour_Controller@delete_ti_Retour_Bordereau_function');

Route::get('/click_edit_ti_Retour_Bordereau/{Numero_Bordereau}', 'TI_Retour_Controller@edit_ti_Retour_Bordereau_function');
Route::post('/ti_Retour_Bordereau_Update/{Numero_Bordereau}', 'TI_Retour_Controller@update_ti_Retour_Bordereau_function');

// Document Non Retournes
Route::get('/ti_Retour_DocNonRetourne', 'TI_Retour_DocNonRetoune_Controller@show_form');

Route::post('/ti_Retour_DocNonRetourne', 'TI_Retour_DocNonRetoune_Controller@traitement_recherche');

Route::get('/click_edit_ti_Retour_DocNonRetourne_popup{Numero_Demande}', 'TI_Retour_DocNonRetoune_Controller@ti_Retour_DocNonRetourne_popup_function');

Route::post('ti_Retour_DocNonRetourne_popup_UpdateStatut/{Numero_Demande}', 'TI_Retour_DocNonRetoune_Controller@ti_Retour_DocNonRetourne_popup_UpdateStatut_function');

// Exploitation
// Proposition de Destruction
Route::get('/exploitation_Sortie', 'Exploitation_PD_Controller@showDashbord');
Route::get('/exploitation_Sortie_PD', 'Exploitation_PD_Controller@show_form');

Route::post('/exploitation_Sortie_PD', 'Exploitation_PD_Controller@traitement_recherche');

Route::get('/click_cree_DDestruction{Numero_UA}', 'Exploitation_PD_Controller@click_cree_DDestruction_function');

Route::post('cree_DDestruction', 'Exploitation_PD_Controller@cree_DDestruction_function');

// Sortie définitive
Route::get('/exploitation_Sortie_Definitive', 'Exploitation_PD_Controller@show_form_sortie_definitive');
Route::post('/exploitation_Sortie_Definitive', 'Exploitation_PD_Controller@traitement_recherche_sortie_definitive');

Route::get('/click_delete_exploitation_Sortie_Definitive/{Numero_Sortie_Definitive}', 'Exploitation_PD_Controller@delete_Demande_Destruction_function');

Route::get('/click_edit_exploitation_Sortie_Definitive/{Numero_Sortie_Definitive}', 'Exploitation_PD_Controller@edit_Demande_Destruction_function');
Route::post('/exploitation_Sortie_Definitive_Update/{Numero_Sortie_Definitive}', 'Exploitation_PD_Controller@update_Demande_Destruction_function');

Route::get('/exploitation_DD_Voyage_form_add', 'Exploitation_PD_Controller@exploitation_DD_Voyage_form_add_function');

Route::post('/exploitation_DD_Voyage_add', 'Exploitation_PD_Controller@exploitation_DD_Voyage_add_function');

Route::get('/click_delete_exploitation_DD_Voyage/{Numero_Voyage}', 'Exploitation_PD_Controller@delete_exploitation_DD_Voyage_function');

// Emplacement
// Affecter
Route::get('/emplacement_Affecter_Doc', 'emplacement_Affecter_Controller@showTable');

Route::get('/emplacement_Affecter_form', 'emplacement_Affecter_Controller@emplacement_Affecter_form_function');
Route::post('/emplacement_Affecter_form_add', 'emplacement_Affecter_Controller@emplacement_Affecter_form_add_function');

Route::get('/click_Affiche_Doc/{Numero_Doc}', 'emplacement_Affecter_Controller@affiche_Document');

Route::get('/click_delete_Doc/{Numero_Doc}', 'emplacement_Affecter_Controller@delete_Doc_function');










// Accueil
Route::get('/accueil', 'DashbordController@afficherMenu');




















































































