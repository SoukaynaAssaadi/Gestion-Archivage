<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

use Illuminate\Http\UploadedFile;

class emplacement_Affecter_Controller extends Controller
{
    public function showTable(Request $req){
        //$select_all_docs = DB::select('select * from docs;');
        $select_all_docs_count = DB::table('docs')->get();

        $adresse_UA = DB::select('select docs.Numero_Doc, docs.photo, docs.Numero_UA,
        unitearchivages.Code_Local_E, unitearchivages.Code_Salle_E, 
        unitearchivages.Code_Ranger_E, unitearchivages.Code_Travet_E, unitearchivages.Code_Etage_E
        from unitearchivages, docs
        where unitearchivages.Numero_UA = docs.Numero_UA;');
 
         return view('/emplacement_Affecter_Doc_show_table', [
         'select_all_docs_count' => $select_all_docs_count, 'adresse_UA' => $adresse_UA]);
     }

    public function emplacement_Affecter_form_function(Request $req){
       $select_all_UA = DB::select('select Numero_UA from unitearchivages;');

        return view('/emplacement_Affecter_form', ['select_all_UA' => $select_all_UA]);
    }

    public function emplacement_Affecter_form_add_function(Request $req){
        $numero_UA = $req->input('numero_UA');
        //$photo =$req->input('photo');   //file
        
            $path = $req->file('photo')->store('image');
            //$path = $req->input('photo')->store('image');
            DB::insert('insert into docs () values (null, ?, ?)', [ $numero_UA, $path]);
        

    

         return redirect('emplacement_Affecter_Doc')->with('Doc_add', 'Un Document est Enregistrer');
     }

     public function affiche_Document($Numero_Doc){
       $affichage = DB::select('select photo from docs where Numero_Doc=?;', [$Numero_Doc]);
    
     $path = substr("{$affichage[0]->photo}", -3, 3);
       

    
         return view('/affichage_Document', ['affichage' => $affichage, 'path' => $path]);
     }
     
     public function delete_Doc_function($Numero_Doc){
        
        DB::delete('delete from docs where Numero_Doc = ?',[ $Numero_Doc]);

        return redirect('emplacement_Affecter_Doc')->with('Doc_delete', 
        'Un Document est Supprimer');            
    }
}
