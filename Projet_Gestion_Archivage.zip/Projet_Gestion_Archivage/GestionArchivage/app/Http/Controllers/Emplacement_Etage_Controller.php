<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class Emplacement_Etage_Controller extends Controller
{
    public function showTable(){
        $emplacement_Etage =  DB::select('select * from etage;');
        $emplacement_Etage_count = DB::table('etage')->get();
        return view('emplacement_Etage',['emplacement_Etage' => $emplacement_Etage, 
        'emplacement_Etage_count' => $emplacement_Etage_count]); 
    }

    public function emplacement_Etage_form_add_function(){
        $affiche_L = DB::select('select * from local;');
        $affiche_S = DB::select('select * from salle;');
        $affiche_R = DB::select('select * from ranger;');
        $affiche_T = DB::select('select * from travet;');
        return view('emplacement_Etage_add', ['affiche_L' => $affiche_L, 
        'affiche_S' => $affiche_S, 'affiche_R' => $affiche_R,
        'affiche_T' => $affiche_T]);
    }

    public function emplacement_Etage_add_function(Request $req){
        $code_Etage = $req->input('code_Etage');
        $nb_place_Etage = $req->input('nb_place_Etage');
        $local_Etage = $req->input('local_Etage');
        $salle_Etage = $req->input('salle_Etage');
        $ranger_Etage = $req->input('ranger_Etage');
        $travet_Etage = $req->input('travet_Etage');
        $description_Etage = $req->input('description_Etage');
        
        DB::insert('insert into etage() values (?, ?, ? , ?, ?, ?, ?)', [ $code_Etage,
         $nb_place_Etage, $description_Etage, $local_Etage, $salle_Etage, $ranger_Etage,$travet_Etage ]);

        return redirect('emplacement_Etage')->with('emplacement_Etage_add', 'Un Etage est Ajouter');
    }
    
    public function delete_Etage_function($Code_Etage){
    
        $foreignUA = DB::select('select * from unitearchivages where Code_Etage_E=?;', [$Code_Etage]);

        if($foreignUA != null){
            return redirect('/emplacement_Etage')->with('emplacement_Etage_Impossible_delete', 
            "La suppression n'a pas eu lieu (données associées) !");
        }else{
            DB::delete('delete from etage where Code_Etage = ?',[ $Code_Etage]);
            return redirect('/emplacement_Etage')->with("emplacement_Etage_delete",
             "Un Etage est Supprimer");
        }              
    }

    public function edit_Etage_function($Code_Etage){
        $affiche_Etage_To_Edit = DB::select('select * from etage where Code_Etage = ?;', 
        [$Code_Etage]);
        $afficher_l = DB::select('select * from local;');
        $afficher_s = DB::select('select * from salle;');
        $afficher_r = DB::select('select * from ranger;');
        $afficher_t = DB::select('select * from travet;');
        return view('emplacement_Etage_Update', ['affiche_Etage_To_Edit' => $affiche_Etage_To_Edit,
        'afficher_l' => $afficher_l, 'afficher_s' => $afficher_s, 
        'afficher_r' => $afficher_r, 'afficher_t' => $afficher_t]);  
    }

    public function update_Etage_function(Request $req, $Code_Etage){
        $code_Etage_update = $req->input('code_Etage_update');
        $nb_place_Etage_update = $req->input('nb_place_Etage_update');
        $local_Etage_update = $req->input('local_Etage_update');
        $salle_Etage_update = $req->input('salle_Etage_update');
        $ranger_Etage_update = $req->input('ranger_Etage_update');
        $travet_Etage_update = $req->input('travet_Etage_update');
        $description_Etage_update = $req->input('description_Etage_update');

        DB::update('update etage set Code_Etage=?, Nombre_Place=?, Description=?, Code_Local_E=?,
        Code_Salle_E=?, Code_Ranger_E=?, Code_Travet_E=? where Code_Etage=? ;', 
        [$code_Etage_update, $nb_place_Etage_update, $description_Etage_update, $local_Etage_update,
        $salle_Etage_update, $ranger_Etage_update, $travet_Etage_update, $Code_Etage]); 

        return redirect('/emplacement_Etage')->with("emplacement_Etage_update",
          "Un Etage est Modifier");          
    }
}
