<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class AdministrationUserController extends Controller
{
    public function formulaire(){
        return view('administrationUadd');
    }

    public function insertion(Request $req){
        $loginUadd = $req->input('loginUadd');
        $passwordUadd = $req->input('passwordUadd');
        $c_passwordUadd = $req->input('c_passwordUadd');
        $date_creation_Uadd = $req->input('date_creation_Uadd');
        $statut_Uadd = $req->input('statut_Uadd');
        $date_debut_Uadd = $req->input('date_debut_Uadd');
        $date_fin_Uadd = $req->input('date_fin_Uadd');
        $d_c_Uadd = $req->input('d_c_Uadd');

        $nom_Uadd = $req->input('nom_Uadd');
        $prenom_Uadd = $req->input('prenom_Uadd');
        $tel_Uadd = $req->input('tel_Uadd');
        $email_Uadd = $req->input('email_Uadd');
        $cin_Uadd = $req->input('cin_Uadd');
        $adresse_Uadd = $req->input('adresse_Uadd');
        $ville_Uadd = $req->input('ville_Uadd');
        $pays_Uadd = $req->input('pays_Uadd');
        $commentaires_Uadd = $req->input('commentaires_Uadd');

        DB::insert('insert into gestion_utilisateur () values (null, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, null)', [ $cin_Uadd, $loginUadd, $nom_Uadd,
        $prenom_Uadd, $tel_Uadd, $adresse_Uadd, $email_Uadd, $passwordUadd, $date_creation_Uadd, 
        $date_debut_Uadd, $date_fin_Uadd, $statut_Uadd, $d_c_Uadd, $ville_Uadd, $pays_Uadd, $commentaires_Uadd]);

        DB::insert('insert into utilisateurs () values(null, ?, ?, ?, ?, ?, ?, ?, ?, null, null, null)', [
            $cin_Uadd, $loginUadd, $nom_Uadd, $prenom_Uadd, $tel_Uadd, $adresse_Uadd, $email_Uadd, $passwordUadd,

        ]);
        return redirect('/administration');
    }

    public function deleteU_function($id_utilisateur){
        /*$a = DB::select('select Login from privilege where Login IN (select Login from utilisateurs where id=?)',
        [$id_utilisateur]);
        $b = DB::select('select Login from gestion_utilisateur where Login IN (select Login from utilisateurs where id=?)',
        [$id_utilisateur]); */
        DB::delete('delete from gestion_utilisateur where CIN = (select CIN from utilisateurs where id = ?);',[ $id_utilisateur]);
        DB::delete('delete from utilisateurs where id = ?',[ $id_utilisateur]); 
        return redirect('/administration_show')->with("Ud", "Un Utilisateur est Supprimer");
            
    }

    public function editU_function($id_utilisateur){
        $afficheU_To_Edit = DB::select('select * from gestion_utilisateur where CIN = 
        (select CIN from utilisateurs where id = ? );', [$id_utilisateur]);
        $entite_select = DB::select('select * from entites;');
        return view('/administration_U_Update', ['afficheU_To_Edit' => $afficheU_To_Edit, 'entite_select' => $entite_select]); 
    }
    
    public function updateU_function(Request $req){
        $loginU_update = $req->input('loginU_update');
        $passwordU_update = $req->input('passwordU_update');
        $c_passwordU_update = $req->input('c_passwordU_update');
        $date_creationU_update = $req->input('date_creationU_update');
        $statutU_update = $req->input('statutU_update');
        $date_debutU_update = $req->input('date_debutU_update');
        $date_finU_update = $req->input('date_finU_update');
        $d_c_U_update = $req->input('d_c_U_update');

        $nomU_update = $req->input('nomU_update');
        $prenomU_update = $req->input('prenomU_update');
        $telU_update = $req->input('telU_update');
        $emailU_update = $req->input('emailU_update');
        $cinU_update = $req->input('cinU_update');
        $adresseU_update = $req->input('adresseU_update');
        $villeU_update = $req->input('villeU_update');
        $paysU_update = $req->input('paysU_update');
        $commentairesU_update = $req->input('commentairesU_update');

        $elementSelecter = $req->input('selectEntite');

        DB::update('update gestion_utilisateur set CIN=?, Login=?, Nom=?, Prenom=?, Tel=?, Adresse=?, Email=?,
        MDP=?, Date_Creation=?, Date_Debut=?, Date_Fin=?, Statut=?, Derniere_changement_MDP=?, Ville=?, Pays=?,
        Commentaire=?, Nom_Entite_E=? where CIN= ? ;', [ $cinU_update, $loginU_update, $nomU_update,
        $prenomU_update, $telU_update, $adresseU_update, $emailU_update, $passwordU_update, $date_creationU_update, 
        $date_debutU_update, $date_finU_update, $statutU_update, $d_c_U_update, $villeU_update, $paysU_update, 
        $commentairesU_update, $elementSelecter, $cinU_update]);
         
        DB::update('update utilisateurs set CIN=?, Login=?, Nom=?, Prenom=?, Tel=?, Adresse=?, Email=?, MDP=? 
        where CIN= ?;',
        [$cinU_update, $loginU_update, $nomU_update,
        $prenomU_update, $telU_update, $adresseU_update, $emailU_update, $passwordU_update, $cinU_update]);

        return redirect('/administration');  
         
    }

    public function administration_U_affect_entite_select(){
        return redirect('administration_U_affect_entite_Affecter');
    }

    /*public function administration_U_affect_entite_Affecter_function(){
        $entite_select = DB::select('select * from entites;');

        return view('/administration_U_affect_entite', ['entite_select' => $entite_select]);

    }

    public function administrationU_A_E_function(Request $req){
        $elementSelecter = $req->input('selectEntite');
        //$a = app('App\Http\Controllers\AdministrationUserController')->updateU_function($req);
       $a = DB::select('select * from utilisateurs where updated_at IS NOT NULL;');
       
        //DB::update('update gestion_utilisateur set Nom_Entite_E= ? where CIN=? ;', [$elementSelecter, $a]);
        //print_r($a);// $a['CIN'];
        //echo $a{'CIN'};
       /* foreach($a as $key => $value){
            echo $key '=>' $value;
        } */
    
    
    
}
