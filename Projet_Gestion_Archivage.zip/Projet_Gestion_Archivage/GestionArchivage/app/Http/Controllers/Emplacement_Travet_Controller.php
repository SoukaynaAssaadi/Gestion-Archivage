<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class Emplacement_Travet_Controller extends Controller
{
    public function showTable(){
        $emplacement_Travet =  DB::select('select * from travet;');
        $emplacement_Travet_count = DB::table('travet')->get();
        return view('emplacement_Travet',['emplacement_Travet' => $emplacement_Travet, 
        'emplacement_Travet_count' => $emplacement_Travet_count]); 
    }

    public function emplacement_Travet_form_add_function(){
        $affiche_locals = DB::select('select * from local;');
        $affiche_salles = DB::select('select * from salle;');
        $affiche_rangees = DB::select('select * from ranger;');
        return view('emplacement_Travet_add', ['affiche_locals' => $affiche_locals, 
        'affiche_salles' => $affiche_salles, 'affiche_rangees' => $affiche_rangees]);
    }

    public function emplacement_Travet_add_function(Request $req){
        $code_Travet = $req->input('code_Travet');
        $nb_place_Travet = $req->input('nb_place_Travet');
        $local_Travet = $req->input('local_Travet');
        $salle_Travet = $req->input('salle_Travet');
        $ranger_Travet = $req->input('ranger_Travet');
        $description_Travet = $req->input('description_Travet');
        
        DB::insert('insert into travet() values (?, ?, ? , ?, ?, ?)', [ $code_Travet,
         $nb_place_Travet, $description_Travet, $local_Travet, $salle_Travet, $ranger_Travet]);

        return redirect('emplacement_Travet')->with('emplacement_Travet_add', 'Un Travée est Ajouter');
    }
    
    public function delete_Travet_function($Code_Travet){
        
        $foreign_etages = DB::select('select * from etage where Code_Travet_E=?;', [$Code_Travet]);
        $foreign_UA = DB::select('select * from unitearchivages where Code_Travet_E=?;', [$Code_Travet]);

        if($foreign_etages != null || $foreign_UA != null){
            return redirect('/emplacement_Travet')->with('emplacement_Travet_Impossible_delete', 
            "La suppression n'a pas eu lieu (données associées) !");
        }else{
            DB::delete('delete from travet where Code_Travet = ?',[ $Code_Travet]);
            return redirect('/emplacement_Travet')->with("emplacement_Travet_delete",
             "Un Travée est Supprimer");
        }              
    }

    public function edit_Travet_function($Code_Travet){
        $affiche_Travet_To_Edit = DB::select('select * from travet where Code_Travet = ?;', 
        [$Code_Travet]);
        $afficher_Local = DB::select('select * from local;');
        $afficher_Salle = DB::select('select * from salle;');
        $afficher_Ranger = DB::select('select * from ranger;');
        return view('emplacement_Travet_Update', ['affiche_Travet_To_Edit' => $affiche_Travet_To_Edit,
        'afficher_Local' => $afficher_Local, 'afficher_Salle' => $afficher_Salle, 
        'afficher_Ranger' => $afficher_Ranger]);  
    }

    public function update_Travet_function(Request $req, $Code_Travet){
        $code_Travet_update = $req->input('code_Travet_update');
        $nb_place_Travet_update = $req->input('nb_place_Travet_update');
        $local_Travet_update = $req->input('local_Travet_update');
        $salle_Travet_update = $req->input('salle_Travet_update');
        $ranger_Travet_update = $req->input('ranger_Travet_update');
        $description_Travet_update = $req->input('description_Travet_update');
        

        DB::update('update travet set Code_Travet=?, Nombre_Place =?, Description=?, Code_Local_E=?,
        Code_Salle_E=?, Code_Ranger_E=? where Code_Travet=? ;', 
        [$code_Travet_update, $nb_place_Travet_update, $description_Travet_update, $local_Travet_update,
        $salle_Travet_update,$ranger_Travet_update, $Code_Travet]); 

        return redirect('/emplacement_Travet')->with("emplacement_Travet_update",
          "Un Travée est Modifier");          
    }
}
