<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class TI_Retour_DocNonRetoune_Controller extends Controller
{
    public function show_form(){
        $entites_s = DB::select('select * from entites;');
        $services_s = DB::select('select * from service;');
        $natures_s = DB::select('select * from nature_document;');
        $statut_s = DB::select('select DISTINCT Statut from recherche;');
        $bordereaus_s = DB::select('select Numero_Bordereau from bordereau;');

        $libelle = DB::select('select DISTINCT Libelle from recherche;');
        $numeros_demande = DB::select('select DISTINCT Numero_Demande from recherche;');
        $numeros_recherche = DB::select('select DISTINCT Numero_Recherche from recherche;');
        
        return view('layouts/travaux_Interieure_Retour_DocNonRetourne_form',
         ['entites_s' => $entites_s, 'services_s' => $services_s,
        'natures_s' => $natures_s, 'statut_s' => $statut_s,
        'bordereaus_s' => $bordereaus_s, 'libelle' => $libelle,
        'numeros_demande' => $numeros_demande, 'numeros_recherche' => $numeros_recherche
        ]);
    }

    public function traitement_recherche(Request $req){
        $entite_Recherche_DO_search = $req->input('entite_Recherche_DO_search');
        $service_Recherche_DO_search = $req->input('service_Recherche_DO_search');
        $nature_Recherche_DO_search = $req->input('nature_Recherche_DO_search');

        $statut_Recherche_DO_search = $req->input('statut_Recherche_DO_search');
        $bordereau_Recherche_DO_search = $req->input('bordereau_Recherche_DO_search');
        $libele_Recherche_DO_search = $req->input('libele_Recherche_DO_search');

        $ua_du_Recherche_DO_search = $req->input('ua_du_Recherche_DO_search');
        $au_Recherche_DO_search = $req->input('au_Recherche_DO_search');
        $numero_demande_Recherche_DO_search = $req->input('numero_demande_Recherche_DO_search');
        

        $DocNonRetourne_search =  DB::select('select * from recherche 
        where Numero_Demande=?
        AND Statut=?
        AND Nom_Entite_E=?
        AND Code_Service_E=?
        AND Code_Nature_E=?
        AND Numero_UA_E BETWEEN ? and ?
        AND Libelle=?
        AND Numero_Bordereau_E=?; ',
         [$numero_demande_Recherche_DO_search, $statut_Recherche_DO_search,
         $entite_Recherche_DO_search, $service_Recherche_DO_search,
         $nature_Recherche_DO_search, $ua_du_Recherche_DO_search, $au_Recherche_DO_search,
         $libele_Recherche_DO_search, $bordereau_Recherche_DO_search]); 


         $entites_s = DB::select('select * from entites;');
         $services_s = DB::select('select * from service;');
         $natures_s = DB::select('select * from nature_document;');
         $statut_s = DB::select('select DISTINCT Statut from recherche;');
         $bordereaus_s = DB::select('select Numero_Bordereau from bordereau;');
 
         $libelle = DB::select('select DISTINCT Libelle from recherche;');
         $numeros_demande = DB::select('select DISTINCT Numero_Demande from recherche;');
         $numeros_recherche = DB::select('select DISTINCT Numero_Recherche from recherche;');

        $DocNonRetourne_count = DB::table('recherche')->get();
        return view('/travaux_interieure_Retour_DocNonRetourne_result_search', 
        ['DocNonRetourne_search' => $DocNonRetourne_search, 'DocNonRetourne_count' => $DocNonRetourne_count,
        'entites_s' => $entites_s, 'services_s' => $services_s,
        'natures_s' => $natures_s, 'statut_s' => $statut_s,
        'bordereaus_s' => $bordereaus_s, 'libelle' => $libelle,
        'numeros_demande' => $numeros_demande, 'numeros_recherche' => $numeros_recherche]);
               
    }

    public function ti_Retour_DocNonRetourne_popup_function($Numero_Demande){
        $affich_DocNonRetourn_To_Edit = DB::select('select * from recherche where Numero_Demande=?;', 
    [$Numero_Demande]);
        return view('ti_Retour_DocNonRetourne_popup',
         ['affich_DocNonRetourn_To_Edit' => $affich_DocNonRetourn_To_Edit]);
    }

    public function ti_Retour_DocNonRetourne_popup_UpdateStatut_function(Request $req, $Numero_Demande){
        $statut_Document = $req->input('statut_Document');
        DB::update('update recherche set Statut=? where Numero_Demande=?;', [$statut_Document, $Numero_Demande]);
        return redirect('ti_Retour_DocNonRetourne')->with('ti_Retour_DocNonRetourne_updateStatut', 
        "Le Statut d'un Document est Modifier");
    }
    
}
