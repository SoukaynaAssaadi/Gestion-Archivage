<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class Emplacement_Local_Controller extends Controller
{
    public function showTable(){
        $emplacement_Local =  DB::select('select * from local;');
        $emplacement_Local_count = DB::table('local')->get();
        return view('emplacement_Local',['emplacement_Local' => $emplacement_Local, 
        'emplacement_Local_count' => $emplacement_Local_count]); 
    }

    public function emplacement_Local_form_add_function(Request $req){
        return view('emplacement_Local_add');
    }

    public function emplacement_Local_add_function(Request $req){
        $nom_Local = $req->input('nom_Local');
        $code_Local = $req->input('code_Local');
        $place_disponible_Local = $req->input('place_disponible_Local');
        
        DB::insert('insert into local () values (?, ?, ? )',
         [$code_Local, $nom_Local, $place_disponible_Local]);

        return redirect('emplacement_Local')->with('emplacement_Local_add', 'Un Local est Ajouter');
    }

    public function delete_Local_function($Code_Local){
        
        $foreign_salle = DB::select('select * from salle where Code_Local_E=?;' ,[$Code_Local]);
        $foreign_ranger = DB:: select('select * from ranger where Code_Local_E=?;', [$Code_Local]);
        $foreign_travet = DB:: select('select * from travet where Code_Local_E=?;', [$Code_Local]);
        $foreign_etage = DB:: select('select * from etage where Code_Local_E=?;', [$Code_Local]);
        $foreign_UA = DB:: select('select * from unitearchivages where Code_Local_E=?;', [$Code_Local]);

        if($foreign_salle != null || $foreign_ranger != null || $foreign_travet != null ||
         $foreign_etage != null || $foreign_UA != null){
            return redirect('emplacement_Local')->with('emplacement_Local_Impossible_delete', 
            "La suppression n'a pas eu lieu (données associées) !");
        }else{
            DB::delete('delete from local where Code_Local = ?',[ $Code_Local]);
            return redirect('/emplacement_Local')->with("emplacement_Local_delete", "Un Local est Supprimer");
        }              
    }

    public function edit_Local_function($Code_Local){
        $affiche_Local_To_Edit = DB::select('select * from local where Code_Local = ?;', 
        [$Code_Local]);
    
        return view('emplacement_Local_Update', ['affiche_Local_To_Edit' => $affiche_Local_To_Edit]);  
    }

    public function update_Local_function(Request $req, $Code_Local){
        $nom_Local_update = $req->input('nom_Local_update');
        $code_Local_update = $req->input('code_Local_update');
        $place_disponible_Local_update = $req->input('place_disponible_Local_update');

        DB::update('update local set Code_Local=?, Nom =?, Place_Disponible=? where Code_Local=? ;', 
        [$code_Local_update, $nom_Local_update, $place_disponible_Local_update, $Code_Local]); 

        return redirect('/emplacement_Local')->with("emplacement_Local_update",
          "Un Local est Modifier");          
    } 


}
