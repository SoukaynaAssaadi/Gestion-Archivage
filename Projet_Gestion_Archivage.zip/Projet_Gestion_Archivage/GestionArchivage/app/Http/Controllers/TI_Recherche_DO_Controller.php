<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class TI_Recherche_DO_Controller extends Controller
{
    public function show_DO(){
        $entites_s = DB::select('select * from entites;');
        $services_s = DB::select('select * from service;');
        $natures_s = DB::select('select * from nature_document;');
        $statut_s = DB::select('select DISTINCT Statut from recherche;');
        $bordereaus_s = DB::select('select Numero_Bordereau from bordereau;');

        $libelle = DB::select('select DISTINCT Libelle from recherche;');
        $numeros_demande = DB::select('select DISTINCT Numero_Demande from recherche;');
        $numeros_recherche = DB::select('select DISTINCT Numero_Recherche from recherche;');
        
        return view('layouts/travaux_Interieure_Recherche_DO_form',
         ['entites_s' => $entites_s, 'services_s' => $services_s,
        'natures_s' => $natures_s, 'statut_s' => $statut_s,
        'bordereaus_s' => $bordereaus_s, 'libelle' => $libelle,
        'numeros_demande' => $numeros_demande, 'numeros_recherche' => $numeros_recherche
        ]);
    }

    public function traitement_recherche(Request $req){
        $entite_Recherche_DO_search = $req->input('entite_Recherche_DO_search');
        $service_Recherche_DO_search = $req->input('service_Recherche_DO_search');
        $nature_Recherche_DO_search = $req->input('nature_Recherche_DO_search');

        $statut_Recherche_DO_search = $req->input('statut_Recherche_DO_search');
        $bordereau_Recherche_DO_search = $req->input('bordereau_Recherche_DO_search');
        $libele_Recherche_DO_search = $req->input('libele_Recherche_DO_search');

        $ua_du_Recherche_DO_search = $req->input('ua_du_Recherche_DO_search');
        $au_Recherche_DO_search = $req->input('au_Recherche_DO_search');
        $numero_demande_Recherche_DO_search = $req->input('numero_demande_Recherche_DO_search');
        

        $DO_search =  DB::select('select * from recherche 
        where Numero_Demande=?
        AND Statut=?
        AND Nom_Entite_E=?
        AND Code_Service_E=?
        AND Code_Nature_E=?
        AND Numero_UA_E BETWEEN ? and ?
        AND Libelle=?
        AND Numero_Bordereau_E=?; ',
         [$numero_demande_Recherche_DO_search, $statut_Recherche_DO_search,
         $entite_Recherche_DO_search, $service_Recherche_DO_search,
         $nature_Recherche_DO_search, $ua_du_Recherche_DO_search, $au_Recherche_DO_search,
         $libele_Recherche_DO_search, $bordereau_Recherche_DO_search]); 


         $entites_s = DB::select('select * from entites;');
         $services_s = DB::select('select * from service;');
         $natures_s = DB::select('select * from nature_document;');
         $statut_s = DB::select('select DISTINCT Statut from recherche;');
         $bordereaus_s = DB::select('select Numero_Bordereau from bordereau;');
 
         $libelle = DB::select('select DISTINCT Libelle from recherche;');
         $numeros_demande = DB::select('select DISTINCT Numero_Demande from recherche;');
         $numeros_recherche = DB::select('select DISTINCT Numero_Recherche from recherche;');

        $DO_count = DB::table('recherche')->get();
        return view('/travaux_interieure_Recherche_DO_result_search', 
        ['DO_search' => $DO_search, 'DO_count' => $DO_count,
        'entites_s' => $entites_s, 'services_s' => $services_s,
        'natures_s' => $natures_s, 'statut_s' => $statut_s,
        'bordereaus_s' => $bordereaus_s, 'libelle' => $libelle,
        'numeros_demande' => $numeros_demande, 'numeros_recherche' => $numeros_recherche]);
               
    }


    public function print_Doc_Originaux_function($Numero_Demande){
        $affiche_Demande_To_Print = DB::select('select * from recherche where Numero_Demande=?', [$Numero_Demande]);
        //$uniteArchiv = DB::select('select Numero_UA_E from recherche where Numero_Demande=?;', [$Numero_Demande]);
        $adresse_UA = DB::select('select unitearchivages.Code_Local_E, unitearchivages.Code_Salle_E,
        unitearchivages.Code_Ranger_E, unitearchivages.Code_Travet_E, unitearchivages.Code_Etage_E
        from unitearchivages,recherche 
         where unitearchivages.Numero_UA = recherche.Numero_UA_E
         AND recherche.Numero_UA_E=?;', [$affiche_Demande_To_Print[0]->Numero_UA_E]);

        return view('/print_Fiche_Recherche_Originaux', ['affiche_Demande_To_Print' => $affiche_Demande_To_Print,
        'adresse_UA' => $adresse_UA]);
    }
    
}
