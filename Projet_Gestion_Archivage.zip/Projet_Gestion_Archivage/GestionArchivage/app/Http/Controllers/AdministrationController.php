<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class AdministrationController extends Controller
{
    public function formulaire(){
        return view('layouts/master');
    }
    
    public function traitement(Request $req){
        $search_user_login = $req->input('search_user_login');
        $search_user_nom = $req->input('search_user_nom');
        $search_user_prenom = $req->input('search_user_prenom');

        $user_search =  DB::select('select * from utilisateurs where Login = ? OR Nom = ? OR Prenom = ? ',
         [$search_user_login, $search_user_nom, $search_user_prenom]); 

        $user_count = DB::table('utilisateurs')->get();
        return view('/administration', ['user_search' => $user_search, 'user_count' => $user_count]);
               
    }

    
    
}

