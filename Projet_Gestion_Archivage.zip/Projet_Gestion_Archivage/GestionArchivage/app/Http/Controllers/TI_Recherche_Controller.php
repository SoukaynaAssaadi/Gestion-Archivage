<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class TI_Recherche_Controller extends Controller
{
    public function showDashbord(){
        return view('layouts/travaux_interieure_Recherche_Dashbord');
    }

    public function show_DR(){
            $entites_select = DB::select('select * from entites;');
            $services_select = DB::select('select * from service;');
            $natures_select = DB::select('select * from nature_document;');
            $statut_select = DB::select('select DISTINCT Statut from recherche;');
            $types_select = DB::select('select DISTINCT Type from recherche;');
            $correspondant_select = DB::select('select Code_Correspondant from correspondant;');
            $urgence_select = DB::select('select DISTINCT Urgence from recherche;');
            $prestation_select = DB::select('select Code_Prestation from prestation;');
            $ua_select = DB::select('select Numero_UA from unitearchivages;');
            $dR_select = DB::select('select Numero_Demande from recherche;');
            $ua = DB::select('select Numero_UA from unitearchivages;');
            $bordereau = DB::select('select Numero_Bordereau from bordereau;');
            
            return view('layouts/travaux_Interieure_Recherche_showTable',
             ['entites_select' => $entites_select, 'services_select' => $services_select,
            'natures_select' => $natures_select, 'statut_select' => $statut_select,
            'types_select' => $types_select, 'correspondant_select' => $correspondant_select,
            'urgence_select' => $urgence_select, 'prestation_select' => $prestation_select,
            'ua_select' => $ua_select, 'dR_select' => $dR_select, 'ua' => $ua, 'bordereau' => $bordereau]);
    }

    public function traitement_recherche(Request $req){
        $entite_DR_search = $req->input('entite_DR_search');
        $service_DR_search = $req->input('service_DR_search');
        $nature_DR_search = $req->input('nature_DR_search');

        $statut_DR_search = $req->input('statut_DR_search');
        $type_DR_search = $req->input('type_DR_search');
        $correspondant_DR_search = $req->input('correspondant_DR_search');

        $urgence_DR_search = $req->input('urgence_DR_search');
        $prestation_DR_search = $req->input('prestation_DR_search');
        $ua_DR_search = $req->input('ua_DR_search');
        $demende_DR_search = $req->input('demende_DR_search');

        $DR_search =  DB::select('select * from recherche 
        where Numero_Demande=?
        AND Statut=?
        AND Type=?
        AND Urgence=?
        AND Nom_Entite_E=?
        AND Code_Service_E=?
        AND Code_Correspondant_E=?
        AND Code_Prestation_E=?
        AND Code_Nature_E=?
        AND Numero_UA_E=?; ',
         [$demende_DR_search, $statut_DR_search, $type_DR_search, $urgence_DR_search,
         $entite_DR_search, $service_DR_search, $correspondant_DR_search, $prestation_DR_search,
         $nature_DR_search, $ua_DR_search]); 


        $entites_select = DB::select('select * from entites;');
        $services_select = DB::select('select * from service;');
        $natures_select = DB::select('select * from nature_document;');
        $statut_select = DB::select('select DISTINCT Statut from recherche;');
        $types_select = DB::select('select DISTINCT Type from recherche;');
        $correspondant_select = DB::select('select Code_Correspondant from correspondant;');
        $urgence_select = DB::select('select DISTINCT Urgence from recherche;');
        $prestation_select = DB::select('select Code_Prestation from prestation;');
        $ua_select = DB::select('select Numero_UA from unitearchivages;');
        $dR_select = DB::select('select Numero_Demande from recherche;');
        $ua = DB::select('select Numero_UA from unitearchivages;');
        

        $DR_count = DB::table('recherche')->get();
        return view('/travaux_interieure_Recherche_result_search', 
        ['DR_search' => $DR_search, 'DR_count' => $DR_count,
        'entites_select' => $entites_select, 'services_select' => $services_select,
        'natures_select' => $natures_select, 'statut_select' => $statut_select,
        'types_select' => $types_select, 'correspondant_select' => $correspondant_select,
        'urgence_select' => $urgence_select, 'prestation_select' => $prestation_select,
        'ua_select' => $ua_select, 'dR_select' => $dR_select, 'ua' => $ua]);
               
    }


    public function ti_Recherche_DR_form_add_function(){
        $entites = DB::select('select * from entites;');
        $services = DB::select('select * from service;');
        $natures = DB::select('select * from nature_document;');
        $correspondant = DB::select('select Code_Correspondant from correspondant;');
        $prestation = DB::select('select Code_Prestation from prestation;');
        $ua = DB::select('select Numero_UA from unitearchivages;');
        $bordereau = DB::select('select Numero_Bordereau from bordereau;');
        
        return view('ti_Recherche_DR_add', ['entites' => $entites, 'services' => $services,
        'natures' => $natures, 'correspondant' => $correspondant, 'prestation' => $prestation,
        'ua' => $ua, 'bordereau' => $bordereau]);
    }

    public function ti_Recherche_DR_add_function(Request $req){

        $entite_DR = $req->input('entite_DR');
        $service_DR = $req->input('service_DR');
        $nature_DR = $req->input('nature_DR');
        $annee_DR = $req->input('annee_DR');

        $correspondant_DR = $req->input('correspondant_DR');
        $statut_DR = $req->input('statut_DR');
        $type_DR = $req->input('type_DR');
        $urgence_DR = $req->input('urgence_DR');

        $prestation_DR = $req->input('prestation_DR');
        $email_DR = $req->input('email_DR');
        $numero_demande_DR = $req->input('numero_demande_DR');
        $demandeur_DR = $req->input('demandeur_DR');

        $mode_livraison_DR = $req->input('mode_livraison_DR');
        $adresse_correspondant_DR = $req->input('adresse_correspondant_DR');
        $date_reception_DR = $req->input('date_reception_DR');
        $date_livraison_prevu_DR = $req->input('date_livraison_prevu_DR');

        $libelle_DR = $req->input('libelle_DR');
        $notes_DR = $req->input('notes_DR');
        $numero_uarchiv_DR = $req->input('numero_uarchiv_DR');
        $numero_bordereau_DR = $req->input('numero_bordereau_DR');
        
        DB::insert('insert into recherche() values(?, null, ?, ?, ?, ?,?,?,?,?,?,?,?,?,null,null,null,
        ?,?,?,?,?,?,?);',
        [$numero_demande_DR, $statut_DR, $email_DR, $mode_livraison_DR, $date_reception_DR,
        $date_livraison_prevu_DR, $libelle_DR, $annee_DR, $type_DR, $urgence_DR, $demandeur_DR,
        $adresse_correspondant_DR, $notes_DR, $entite_DR, $service_DR, $correspondant_DR, 
        $prestation_DR, $nature_DR, $numero_uarchiv_DR, $numero_bordereau_DR]);

        return redirect('ti_Recherche_DR')->with('ti_Recherche_DR_add', "Une nouvelle Demande de Recherche est Créer");    
    }

    public function delete_ti_Recherche_DR_function($Numero_Demande){
        DB::delete('delete from recherche where Numero_Demande = ?',[ $Numero_Demande]);
            return redirect('/ti_Recherche_DR')->with("ti_Recherche_DR_delete",
            "Une Demande de Recherche est Supprimer!");            
    }

    public function edit_ti_Recherche_DR_function($Numero_Demande){
        $affiche_Recherche_DR_To_Edit = DB::select('select * from recherche  where Numero_Demande = ?;', 
        [$Numero_Demande]);
        $entites_show = DB::select('select * from entites;');
        $services_show = DB::select('select * from service;');
        $natures_show = DB::select('select * from nature_document;');
        $correspondant_show = DB::select('select Code_Correspondant from correspondant;');
        $prestation_show = DB::select('select Code_Prestation from prestation;');
        $ua_show = DB::select('select Numero_UA from unitearchivages;');
        $bordereau = DB::select('select Numero_Bordereau from bordereau;');
        
        return view('ti_Recherche_DR_Update', 
        ['affiche_Recherche_DR_To_Edit' => $affiche_Recherche_DR_To_Edit,
        'entites_show' => $entites_show, 'services_show' => $services_show, 'natures_show' => $natures_show,
        'correspondant_show' => $correspondant_show, 'prestation_show' => $prestation_show,
         'ua_show' => $ua_show, 'bordereau' => $bordereau]);  
    }

    public function update_ti_Recherche_DR_function(Request $req, $Numero_Demande){
        $entite_DR_update = $req->input('entite_DR_update');
        $service_DR_update = $req->input('service_DR_update');
        $nature_DR_update = $req->input('nature_DR_update');
        $annee_DR_update = $req->input('annee_DR_update');

        $correspondant_DR_update = $req->input('correspondant_DR_update');
        $statut_DR_update = $req->input('statut_DR_update');
        $type_DR_update = $req->input('type_DR_update');
        $urgence_DR_update = $req->input('urgence_DR_update');

        $prestation_DR_update = $req->input('prestation_DR_update');
        $email_DR_update = $req->input('email_DR_update');
        $numero_demande_DR_update = $req->input('numero_demande_DR_update');
        $demandeur_DR_update = $req->input('demandeur_DR_update');

        $mode_livraison_DR_update = $req->input('mode_livraison_DR_update');
        $adresse_correspondant_DR_update = $req->input('adresse_correspondant_DR_update');
        $date_reception_DR_update = $req->input('date_reception_DR_update');
        $date_livraison_prevu_DR_update = $req->input('date_livraison_prevu_DR_update');

        $libelle_DR_update = $req->input('libelle_DR_update');
        $notes_DR_update = $req->input('notes_DR_update');
        $numero_uarchiv_DR_update = $req->input('numero_uarchiv_DR_update');
        $numero_bordereau_DR_update = $req->input('numero_bordereau_DR_update');
        
        DB::update('update recherche set Numero_Demande =?, Statut =?, Email=?, Mode_Livraison=?,
        Date_Reception=?, Date_Livraison=?, Libelle=?, Annee=?, Type=?, Urgence=?, Demandeur=?,
        Adresse_Correspondant=?, Notes=?, Nom_Entite_E=?, Code_Service_E=?, Code_Correspondant_E=?, 
        Code_Prestation_E=?, Code_Nature_E=?, Numero_UA_E=?, Numero_Bordereau_E=?
        where Numero_Demande=? ;', 
        [$numero_demande_DR_update, $statut_DR_update, $email_DR_update, $mode_livraison_DR_update,
         $date_reception_DR_update, $date_livraison_prevu_DR_update, $libelle_DR_update, 
        $annee_DR_update, $type_DR_update, $urgence_DR_update, $demandeur_DR_update, $adresse_correspondant_DR_update,
        $notes_DR_update, $entite_DR_update, $service_DR_update, $correspondant_DR_update, $prestation_DR_update,
        $nature_DR_update, $numero_uarchiv_DR_update, $numero_bordereau_DR_update, $Numero_Demande
        ]); 

        return redirect('/ti_Recherche_DR')->with("ti_Recherche_DR_update",
            "Une Demande de Recherche est Modifier");         
    } 
}
