<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

use App\Listeprivilege;

use App\Utilisateur;

class administration_Groupe_Privilege_Controller extends Controller
{
    
    public function insertion(Request $req){
        $codeGP = $req->input('codeGP');
        $descriptionGP = $req->input('descriptionGP');

        DB::insert('insert into groupe_privilege () values (null, ?, ?)', [ $codeGP, $descriptionGP]);

        return redirect('/administration_Groupe_Privilege');
    }

    
    public function traitement(){
        $gp =  DB::select('select * from groupe_privilege;');
        $gp_count = DB::table('groupe_privilege')->get();
        return view('/administrationGP', ['gp' => $gp, 'gp_count' => $gp_count]);         
    }

    public function editGP_function($id_Privilege){
        $afficheGP_To_Edit = DB::select('select * from groupe_privilege where id_Privilege= ? ;', [$id_Privilege]);
        return view('/administrationGPUpdate', ['afficheGP_To_Edit' => $afficheGP_To_Edit]); 
    }

    public function updateGP_function(Request $req, $id_Privilege){
        $codeGPupdate = $req->input('codeGPupdate');
        $descriptionGPupdate = $req->input('descriptionGPupdate');

        DB::update('update groupe_privilege set Code_Privilege = ?, Description = ? where id_Privilege = ?',
         [$codeGPupdate, $descriptionGPupdate, $id_Privilege]);
         return redirect('/administration_Groupe_Privilege')->with("GPu", "un groupe privilège est Modifier"); ;            
    }

    public function deleteGP_function($id_Privilege){
        
        DB::delete('delete from groupe_privilege where id_Privilege = ?',[ $id_Privilege]);

         return redirect('/administration_Groupe_Privilege')->with("GPd", "un groupe privilège est Supprimer");            
    }

    // liste privilege

    public function listPrivilegeGP_sectionUtilisateur_function(){
        DB::update('update listeprivileges set deleted_at = null');
        DB::update('update utilisateurs set deleted_at = null');
        $listePrivilege =  DB::select('select * from listeprivileges;');
        $utilisateurLNP =  DB::select('select * from utilisateurs;');
        return view('/adminPopupGPupdate', ['listePrivilege' => $listePrivilege, 'utilisateurLNP' => $utilisateurLNP]);             
    }

    public function deleteListPrivilegeGP_function($id_Liste_Privilege){
        Listeprivilege::find($id_Liste_Privilege)->delete();

        $listePrivilege =  DB::select('select * from listeprivileges where deleted_at IS NULL;');
        return redirect('/lpGP_and_suGP_not_null');
    }

    public function lpGP_and_suGP_not_null_function(){

        $listePrivilege =  DB::select('select * from listeprivileges where deleted_at IS NULL;');
        $utilisateurLNP =  DB::select('select * from utilisateurs where deleted_at IS NULL;');
        return view('/adminPopupGPupdate', ['listePrivilege' => $listePrivilege, 'utilisateurLNP' => $utilisateurLNP]);             
    }

    public function click_Button_Affecter_function(){
        DB::insert('insert into privilege(Menu, Page, Ajouter, Modifier, Supprimer, Rechercher, Export, Import, Login,
         Nom, Prenom) select Menu, Page, null, null, null, null, null, null, Login, Nom, Prenom from listeprivileges, utilisateurs
         where listeprivileges.deleted_at IS NULL AND utilisateurs.deleted_at IS NULL;');

        DB::update('update listeprivileges set deleted_at = null');
        DB::update('update utilisateurs set deleted_at = null');
        
        return redirect('listPrivilegeGP_AND_sectionUtilisateurGP');
    }


    // section utilisateur

    public function deleteSectionUtilisateurGP_function($id_Utilisateur){
        Utilisateur::find($id_Utilisateur)->delete();

        $utilisateurLNP =  DB::select('select * from listeprivileges where deleted_at IS NULL;');
        return redirect('/lpGP_and_suGP_not_null');            
    }

    public function ajouter_Privilege_InDataBase(){
         
                    
    }
    
    
    


    
}
