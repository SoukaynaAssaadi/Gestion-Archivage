<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TestCntroller extends Controller
{
    public function formulaire(){
        return view('testTable');
    }

    public function recupererData(Request $req){
        $p = $req->input('p');
        $x = $req->input('x');
        $a = $req->input('a');
        $b = $req->input('b');

        

        $name="soukayna";
        echo $x . $p; 




        $i = $req->input("secteur");
        echo $i;    // affiche 
    }
}

