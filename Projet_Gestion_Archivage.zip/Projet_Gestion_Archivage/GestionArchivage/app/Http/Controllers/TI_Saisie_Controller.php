<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class TI_Saisie_Controller extends Controller
{
    public function showDashbord(){
        return view('layouts/travaux_interieure1_Dashbord');
    }
    
    public function showInventaire(){
        $entites = DB::select('select * from entites;');
        $services = DB::select('select * from service;');
        $natures = DB::select('select * from nature_document;');
        $annes = DB::select('select DISTINCT Annee from unitearchivages;');
        return view('layouts/travaux_interieure_Dashbord', ['entites' => $entites, 'services' => $services,
        'natures' => $natures, 'annes' => $annes]);
    }
    
    public function traitement_recherche(Request $req){

        $search_inventaire_nUA = $req->input('search_inventaire_nUA');
        $search_inventaire_Au = $req->input('search_inventaire_Au');
        $search_inventaire_entite = $req->input('search_inventaire_entite');
        $search_inventaire_service = $req->input('search_inventaire_service');
        $search_inventaire_nature = $req->input('search_inventaire_nature');
        $search_inventaire_annee = $req->input('search_inventaire_annee');

        $inventaire_search =  DB::select('select  DISTINCT inventaire.Libelle, inventaire.Date_Modification,
        inventaire.Nombre_Page, inventaire.Numero_UA_E, unitearchivages.Statut 
        from unitearchivages,inventaire  where inventaire.Numero_UA_E=unitearchivages.Numero_UA 
        AND unitearchivages.Numero_UA BETWEEN ? AND ?
        AND Nom_Entite_E=? AND Code_Service_E=? AND Code_Nature_E=? AND Annee=? ',
         [$search_inventaire_nUA, $search_inventaire_Au, $search_inventaire_entite, $search_inventaire_service,
         $search_inventaire_nature, $search_inventaire_annee]); 

         $entites = DB::select('select * from entites;');
         $services = DB::select('select * from service;');
         $natures = DB::select('select * from nature_document;');
         $annes = DB::select('select DISTINCT Annee from unitearchivages;');

        $inventaire_count = DB::table('inventaire')->get();
        return view('/travaux_interieure_Saisie_result_search', ['inventaire_search' => $inventaire_search, 
        'inventaire_count' => $inventaire_count, 'entites' => $entites, 'services' => $services,
        'natures' => $natures, 'annes' => $annes]);       
    }

    public function showTable(){
        $ti_Saisie_Inventaire =  DB::select('select * from inventaire;');
        $inventaire_count = DB::table('inventaire')->get();
        return view('ti_Saisie_Inventaire',['ti_Saisie_Inventaire' => $ti_Saisie_Inventaire, 
        'inventaire_count' => $inventaire_count]); 
    }


    public function ti_Saisie_Inventaire_form_add_function(){
        $numero_ua = DB::select('select * from unitearchivages;');
        return view('ti_Saisie_Inventaire_add', ['numero_ua' => $numero_ua]);
    }

    public function ti_Saisie_Inventaire_add_function(Request $req){

        $libelle_Saisie_Inventaire = $req->input('libelle_Saisie_Inventaire');
        $date_mise_jour_Saisie_Inventaire = $req->input('date_mise_jour_Saisie_Inventaire');
        $nb_page_Saisie_Inventaire = $req->input('nb_page_Saisie_Inventaire');
        $numero_ua_Saisie_Inventaire = $req->input('numero_ua_Saisie_Inventaire');
        
        DB::insert('insert into inventaire() values(null, ?, ?, ?, ?);',
        [$libelle_Saisie_Inventaire, $date_mise_jour_Saisie_Inventaire, $nb_page_Saisie_Inventaire,
        $numero_ua_Saisie_Inventaire]);

        return redirect('ti_Saisie_Inventaire_show_table')->with('ti_Saisie_Inventaire_add', "Un Inventaire est Ajouter au Unité d'archivage");    
    }

    public function delete_ti_Saisie_Inventaire_function($id_Inventaire){
        DB::delete('delete from inventaire where id_Inventaire = ?',[ $id_Inventaire]);
            return redirect('/ti_Saisie_Inventaire_show_table')->with("ti_Saisie_Inventaire_delete",
            "Un Inventaire est Supprimer dans une Unité");            
    }

    public function edit_ti_Saisie_Inventaire_function($id_Inventaire){
        $affiche_Saisie_inventaire_To_Edit = DB::select('select * from inventaire  where id_Inventaire = ?;', 
        [$id_Inventaire]);
        $afficher_ua = DB::select('select * from unitearchivages;');
        
        return view('ti_Saisie_Inventaire_Update', 
        ['affiche_Saisie_inventaire_To_Edit' => $affiche_Saisie_inventaire_To_Edit,
        'afficher_ua' => $afficher_ua]);  
    }

    public function update_ti_Saisie_Inventaire_function(Request $req, $id_Inventaire){
        $numero_ua_Saisie_Inventaire_update = $req->input('numero_ua_Saisie_Inventaire_update');
        $libelle_Saisie_Inventaire_update = $req->input('libelle_Saisie_Inventaire_update');
        $date_mise_jour_Saisie_Inventaire_update = $req->input('date_mise_jour_Saisie_Inventaire_update');
        $nb_page_Saisie_Inventaire_update = $req->input('nb_page_Saisie_Inventaire_update');
  
        DB::update('update inventaire set Libelle =?, Date_Modification =?, Nombre_Page=?, Numero_UA_E=?
        where id_Inventaire=? ;', 
        [$libelle_Saisie_Inventaire_update, $date_mise_jour_Saisie_Inventaire_update,
         $nb_page_Saisie_Inventaire_update, $numero_ua_Saisie_Inventaire_update,
        $id_Inventaire]); 

        return redirect('/ti_Saisie_Inventaire_show_table')->with("ti_Saisie_Inventaire_update",
            "Un Inventaire est Modifier dans une Unité");          
    } 
    
   
}
