<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

//use App\Utilisateur;

class LoginController extends Controller
{
    public function formulaire(){
        return view('login');
    }

    public function traitement(Request $req){
        // validation rules
        $req->validate([
            'login_Login' => 'required | min:10',
            'password_Login' => 'required | min:5'
        ]);
            // page accueille
        
        $administration = "Administration";
        $exploitation = "Exploitation";
        $emplacement = "Emplacement";
        $ta = "Travaux Intérieurs";

        $login_Login = $req->input('login_Login');
        $password_Login = $req->input('password_Login');

        $utilisateurs_Login = DB::select('select * from utilisateurs where Login = ? ', [$login_Login]);
        $utilisateurs_Password = DB::select('select * from utilisateurs where MDP = ? AND Login = ? ', [$password_Login, $login_Login]);
        // Droit acces Total
        //$utilisateur_Droit = DB::select('select Prenom from privilege where Login = "myLogin" AND Menu = ALL (select DISTINCT Menu from listeprivileges);' 
       // , [$login_Login]);

        // AND Menu = ?
        //AND Menu = ?
        //AND Menu = ?
        //AND Menu = ?
        //$utilisateur_Droit = DB::select('select * from privilege where Login = ? and Menu 
        //                               =(select Menu from privilege where Menu=? ;',[$login_Login, $emplacement, $exploitation]);
        //if($login_Login == "Administrateur" && $password_Login == "admin"){
        $page_Versement = "Versements";
        $page_UA = "Unité d'archivage";
        $menu_emplacement = "Emplacement";
        $menu_TI = "Travaux Intérieurs";
        $page_Saisie = "Saisie";
        $page_Recherche = "Recherche";
        $page_Retour = "Retour";
        $menu_Exploitation = "Exploitation";
        $page_Sortie_definitif = "Sorties definitive";


        $admin = DB::select('select * from administrateur where Login = ? and MDP = ?', [$login_Login, $password_Login]);
        $groupe_Versement = DB::select('select * from privilege where Login=? and Page IN (?, ?);',[$login_Login,
        $page_Versement, $page_UA]);
        
        $groupe_Emplacement = DB::select('select * from privilege where Login=? and Menu=?;', [$login_Login,
         $menu_emplacement]);

        $groupe_Saisie = DB::select('select * from privilege where Login=? and Menu=? and Page=?;',
          [$login_Login, $menu_TI, $page_Saisie]);
         
        $groupe_Recherche = DB::select('select * from privilege where Login=? and Menu=? and Page=?;',
          [$login_Login, $menu_TI, $page_Recherche]);
          
        $groupe_Retour = DB::select('select * from privilege where Login=? and Menu=? and Page=?;',
        [$login_Login, $menu_TI, $page_Retour]);  

        $groupe_Sortie_definitif = DB::select('select * from privilege where Login=? and Menu=? and Page=?;',
        [$login_Login, $menu_Exploitation, $page_Sortie_definitif]);

        if($admin != null){    
            return view('layouts/adminDashbord');
        }else if($utilisateurs_Login == null){
            return redirect('/login')->with('refuser', "Vous n'avez pas encore de compte ? Inscrivez vous");
        }else if($utilisateurs_Password == null){
            return redirect('/login')->with('MDP_incorrect', "Le mot de passe est Incorrect !");
        }else if($groupe_Versement != null){
            return view('layouts/versementDashbord'); 
        }else if($groupe_Emplacement != null){
            return view('layouts/emplacementDashbord'); 
        }else if($groupe_Saisie != null){
            return view('layouts/travaux_Interieure1_Dashbord'); 
        }else if($groupe_Recherche != null){
            return view('layouts/travaux_Interieure_Recherche_Dashbord'); 
        }else if($groupe_Retour != null){
            return view('layouts/travaux_Interieure_Retour_Dashbord'); 
        }else if($groupe_Sortie_definitif != null){
            return view('layouts/exploitation_Sortie_Dashbord'); 
        }else if($login_Login == "Acces total"){      // pour le groupe d'Acces Total Login = "Acces total"
            return redirect('/accueil');
        }
    
       
    }
}
