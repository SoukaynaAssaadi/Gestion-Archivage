<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class Emplacement_Salle_Controller extends Controller
{
    public function showTable(){
        $emplacement_Salle =  DB::select('select * from salle;');
        $emplacement_Salle_count = DB::table('salle')->get();
        return view('emplacement_Salle',['emplacement_Salle' => $emplacement_Salle, 
        'emplacement_Salle_count' => $emplacement_Salle_count]); 
    }

    public function emplacement_Salle_form_add_function(){
        $show_local = DB::select('select * from local;');
        return view('emplacement_Salle_add', ['show_local' => $show_local]);
    }

    public function emplacement_Salle_add_function(Request $req){
        $nom_Salle = $req->input('nom_Salle');
        $code_Salle = $req->input('code_Salle');
        $place_Disponible_Salle = $req->input('place_Disponible_Salle');
        $local_Salle_add = $req->input('local_Salle_add');
        
        
        DB::insert('insert into salle() values (?, ?, ? , ? )', [ $code_Salle,
         $nom_Salle, $place_Disponible_Salle, $local_Salle_add]);

        return redirect('emplacement_Salle')->with('emplacement_Salle_add', 'Une Salle est Ajouter');
    }
    
    public function delete_Salle_function($code_Salle){
        
        $foreign_Ranger = DB::select('select * from ranger where Code_Salle_E=?;', [$code_Salle]);
        $foreign_Travet = DB::select('select * from travet where Code_Salle_E=?;', [$code_Salle]);
        $foreign_Etage = DB::select('select * from etage where Code_Salle_E=?;', [$code_Salle]);
        $foreign_ua = DB::select('select * from unitearchivages where Code_Salle_E=?;', [$code_Salle]);

        if($foreign_Ranger != null || $foreign_Travet != null ||
         $foreign_Etage != null || $foreign_ua != null){
            return redirect('emplacement_Salle')->with('emplacement_Salle_Impossible_delete', 
            "La suppression n'a pas eu lieu (données associées) !");
        }else{
            DB::delete('delete from salle where code_Salle = ?',[ $code_Salle]);
            return redirect('/emplacement_Salle')->with("emplacement_Salle_delete",
             "Une Salle est Supprimer");
        }              
    }

    public function edit_Salle_function($code_Salle){
        $affiche_Salle_To_Edit = DB::select('select * from salle where code_Salle = ?;', 
        [$code_Salle]);
        $afficher_locals = DB::select('select * from local;');
        return view('emplacement_Salle_Update', ['affiche_Salle_To_Edit' => $affiche_Salle_To_Edit,
        'afficher_locals' => $afficher_locals]);  
    }

    public function update_Salle_function(Request $req, $code_Salle){
        $nom_Salle_update = $req->input('nom_Salle_update');
        $code_Salle_update = $req->input('code_Salle_update');
        $place_Disponible_Salle_update = $req->input('place_Disponible_Salle_update');
        $local_Salle_update = $req->input('local_Salle_update');

        DB::update('update salle set Code_Salle=?, Nom =?, Place_Disponible=?, Code_Local_E=?
         where Code_Salle=? ;', 
        [$code_Salle_update, $nom_Salle_update, $place_Disponible_Salle_update, $local_Salle_update,
        $code_Salle]); 

        return redirect('/emplacement_Salle')->with("emplacement_Salle_update",
          "Une Salle est Modifier");          
    }
}
