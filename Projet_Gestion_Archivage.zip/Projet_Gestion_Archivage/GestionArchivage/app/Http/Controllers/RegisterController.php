<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
//use App\Utilisateur;

class RegisterController extends Controller
{
    public function formulaire(){
        return view('register');
    }

    public function traitement(Request $req){
            // validation rules
            $req->validate([
                'cin' => 'required | size:8 | alpha_num | unique:utilisateurs,CIN',
                'login_Registre' => 'required | min:10 | unique:utilisateurs,Login',
                'nom' => 'required | alpha ',
                'prenom' => 'required | alpha',
                'tel' => 'required | numeric',
                'adresse' => 'required | min:3',
                'email' => 'required | email | unique:utilisateurs,Email',
                'password_Registre' => 'required | min:10',
                'confirmer_password_Registre' => 'required | min:10 | same:password_Registre'
            ]);
    
            /*$utilisateur1 = new Utilisateur;
            $utilisateur1->CIN = $req->cin;
            $utilisateur1->Login = $req->login_Registre;
            $utilisateur1->Nom = $req->nom;
            $utilisateur1->Prenom = $req->prenom;
            $utilisateur1->Tel = $req->tel;
            $utilisateur1->Adresse = $req->adresse;
            $utilisateur1->Email = $req->email;
            $utilisateur1->MDP = $req->password_Registre;  

    
            echo $utilisateur1->save();  */
                      // page accueille
            $cin = $req->input('cin');
            $login_Registre = $req->input('login_Registre');
            $nom = $req->input('nom');
            $prenom = $req->input('prenom');
            $tel = $req->input('tel');
            $adresse = $req->input('adresse');
            $email = $req->input('email');
            $password_Registre = $req->input('password_Registre');

            DB::insert('insert into utilisateurs () values (null, ?, ?, ?, ?, ?, ?, ?, ?, null, null, null)'
            , [$cin, $login_Registre, $nom, $prenom, $tel, $adresse, $email, $password_Registre]);

            DB::insert('insert into gestion_utilisateur () values (null, ?, ?, ?, ?, ?, ?, ?, ?, null, null, null, null,null,null,null,null,null)'
            , [$cin, $login_Registre, $nom, $prenom, $tel, $adresse, $email, $password_Registre]);
            return redirect('/login');

    }
}
