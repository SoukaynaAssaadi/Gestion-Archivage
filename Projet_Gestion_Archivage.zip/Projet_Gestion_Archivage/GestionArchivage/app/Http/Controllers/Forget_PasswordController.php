<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
//use App\Utilisateur;

class Forget_PasswordController extends Controller
{
    public function formulaire(){
        return view('Forget_Password');
    }

    public function traitement(Request $req){
        // validation rules
        $req->validate([
            'nouveau_login_Login' => 'required| min:10',
            'nouveau_password_Login' => 'required| min:10',
            'confirmer_nouveau_password_Login' => 'required| min:10 | same:nouveau_password_Login'
        ]);
        
        $nouveau_login_Login = $req->input('nouveau_login_Login');
        $nouveau_password_Login = $req->input('nouveau_password_Login');
        $confirmer_nouveau_password_Login = $req->input('confirmer_nouveau_password_Login');

        $resultat = DB::update('update utilisateurs set MDP = ? where Login = ?', [$confirmer_nouveau_password_Login, 
                    $nouveau_login_Login]);
        if($resultat != null){
            return redirect('/login')->with('MDP_Changer', "Le mot de passe est Bien Changer.");
        }else{
            return redirect('/changerMDP')->with('refuser', "Vous n'avez pas encore de compte ? Inscrivez vous");
        }
            
            
    }
}
