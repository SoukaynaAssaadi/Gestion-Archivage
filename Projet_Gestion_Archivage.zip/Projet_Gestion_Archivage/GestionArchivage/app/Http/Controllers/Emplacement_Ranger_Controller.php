<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class Emplacement_Ranger_Controller extends Controller
{
    public function showTable(){
        $emplacement_Ranger =  DB::select('select * from ranger;');
        $emplacement_Ranger_count = DB::table('ranger')->get();
        return view('emplacement_Ranger',['emplacement_Ranger' => $emplacement_Ranger, 
        'emplacement_Ranger_count' => $emplacement_Ranger_count]); 
    }

    public function emplacement_Ranger_form_add_function(){
        $afficher_local = DB::select('select * from local;');
        $afficher_salle = DB::select('select * from salle;');
        return view('emplacement_Ranger_add', ['afficher_local' => $afficher_local, 
        'afficher_salle' => $afficher_salle]);
    }

    public function emplacement_Ranger_add_function(Request $req){
        $code_Range = $req->input('code_Range');
        $nb_place_Range = $req->input('nb_place_Range');
        $local_Range = $req->input('local_Range');
        $salle_Range = $req->input('salle_Range');
        $description_Range = $req->input('description_Range');
        
        DB::insert('insert into ranger() values (?, ?, ? , ?, ?)', [ $code_Range,
         $nb_place_Range, $description_Range, $local_Range, $salle_Range]);

        return redirect('emplacement_Ranger')->with('emplacement_Ranger_add', 'Un Ranger est Ajouter');
    }
    
    public function delete_Ranger_function($Code_Ranger){
        
        $foreignTravet = DB::select('select * from travet where Code_Ranger_E=?;', [$Code_Ranger]);
        $foreignEtage = DB::select('select * from etage where Code_Ranger_E=?;', [$Code_Ranger]);
        $foreignUA = DB::select('select * from unitearchivages where Code_Ranger_E=?;', [$Code_Ranger]);

        if($foreignTravet != null || $foreignEtage != null ||
         $foreignUA != null){
            return redirect('/emplacement_Ranger')->with('emplacement_Ranger_Impossible_delete', 
            "La suppression n'a pas eu lieu (données associées) !");
        }else{
            DB::delete('delete from ranger where Code_Ranger = ?',[ $Code_Ranger]);
            return redirect('/emplacement_Ranger')->with("emplacement_Ranger_delete",
             "Un Rangée est Supprimer");
        }              
    }

    public function edit_Ranger_function($Code_Ranger){
        $affiche_Ranger_To_Edit = DB::select('select * from ranger where Code_Ranger = ?;', 
        [$Code_Ranger]);
        $show_locals = DB::select('select * from local;');
        $show_salles = DB::select('select * from salle;');
        return view('emplacement_Ranger_Update', ['affiche_Ranger_To_Edit' => $affiche_Ranger_To_Edit,
        'show_locals' => $show_locals, 'show_salles' => $show_salles]);  
    }

    public function update_Ranger_function(Request $req, $Code_Ranger){
        $code_Range_update = $req->input('code_Range_update');
        $nb_place_Range_update = $req->input('nb_place_Range_update');
        $local_Range_update = $req->input('local_Range_update');
        $salle_Range_update = $req->input('salle_Range_update');
        $description_Range_update = $req->input('description_Range_update');

        DB::update('update ranger set Code_Ranger=?, Nombre_Place =?, Description=?, Code_Local_E=?,
        Code_Salle_E=? where Code_Ranger=? ;', 
        [$code_Range_update, $nb_place_Range_update, $description_Range_update, $local_Range_update,
        $salle_Range_update,$Code_Ranger]); 

        return redirect('/emplacement_Ranger')->with("emplacement_Ranger_update",
          "Un Ranger est Modifier");          
    }
}
