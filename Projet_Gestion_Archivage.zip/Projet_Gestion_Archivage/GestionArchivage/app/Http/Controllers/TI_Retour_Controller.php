<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;

class TI_Retour_Controller extends Controller
{
    public function showDashbord(){
        return view('layouts/travaux_interieure_Retour_Dashbord');
    }

    public function show_Bordereau_form(){
            $show_Entites = DB::select('select * from entites;');
            $show_Correspondant = DB::select('select Code_Correspondant from correspondant;');
              
            return view('layouts/travaux_Interieure_Retour_showTable',
             ['show_Entites' => $show_Entites, 'show_Correspondant' => $show_Correspondant]);
    }

    public function traitement_recherche(Request $req){
        $entite_Retour_search = $req->input('entite_Retour_search');
        $correspondant_Retour_search = $req->input('correspondant_Retour_search');
        $numero_bordereau_Retour_search = $req->input('numero_bordereau_Retour_search');

        $statut_Retour_search = $req->input('statut_Retour_search');
        $date_du_Retour_search = $req->input('date_du_Retour_search');
        $date_au_Retour_search = $req->input('date_au_Retour_search');

        $Bordereau_search =  DB::select('select correspondant.Nom, correspondant.Prenom,
        bordereau.Numero_Bordereau, bordereau.Nom_Entite_E, bordereau.Statut,
        bordereau.Date_Creation , bordereau.Date_Reception, bordereau.Adresse
        from bordereau, correspondant 
        where bordereau.Code_Correspondant_E = correspondant.Code_Correspondant
        AND bordereau.Nom_Entite_E=?
        AND Code_Correspondant_E=? 
        AND Numero_Bordereau=?
        AND Statut=?
        AND Date_Creation=?
        AND Date_Reception=?; ',
         [$entite_Retour_search, $correspondant_Retour_search, $numero_bordereau_Retour_search,
         $statut_Retour_search, $date_du_Retour_search, $date_au_Retour_search]); 

        $show_Entites = DB::select('select * from entites;');
        $show_Correspondant = DB::select('select Code_Correspondant from correspondant;');
        

        $Bordereau_count = DB::table('bordereau')->get();
        return view('/travaux_interieure_Retour_result_search', 
        ['Bordereau_search' => $Bordereau_search, 'Bordereau_count' => $Bordereau_count,
        'show_Entites' => $show_Entites, 'show_Correspondant' => $show_Correspondant]);
               
    }

    public function ti_Retour_form_add_function(){
        $entites_affich = DB::select('select * from entites;');
        $correspondant_affich = DB::select('select * from correspondant;');
        
        return view('ti_Retour_add', ['entites_affich' => $entites_affich,
         'correspondant_affich' => $correspondant_affich]);
    }

    public function ti_Retour_add_function(Request $req){

        $entite_Bordereau = $req->input('entite_Bordereau');
        $correspondant_Bordereau = $req->input('correspondant_Bordereau');
        $date_creation_Bordereau = $req->input('date_creation_Bordereau');
        $date_reception_Bordereau = $req->input('date_reception_Bordereau');

        $statut_Bordereau = $req->input('statut_Bordereau');
        $adresse_Bordereu = $req->input('adresse_Bordereu');
        $bureau_Bordereau = $req->input('bureau_Bordereau');
        $etage_Bordereau = $req->input('etage_Bordereau');

        $ville_Bordereau = $req->input('ville_Bordereau');
        $tel_Bordereau = $req->input('tel_Bordereau');
        $fax_Bordereau = $req->input('fax_Bordereau');
        $commentaire_Bordereau = $req->input('commentaire_Bordereau');
        
        DB::insert('insert into bordereau() values(null, ?, ?, ?, ?,?,?,?,?,?,?,?,?);',
        [$date_creation_Bordereau, $date_reception_Bordereau, $adresse_Bordereu, $tel_Bordereau, $statut_Bordereau,
        $bureau_Bordereau, $ville_Bordereau, $fax_Bordereau, $commentaire_Bordereau, $entite_Bordereau, $etage_Bordereau,
        $correspondant_Bordereau]);

        return redirect('ti_Retour_Bordereau')->with('ti_Retour_Bordereau_add', "Un Bordereau est Créer");    
    }

    public function delete_ti_Retour_Bordereau_function($Numero_Bordereau){
        DB::delete('delete from bordereau where Numero_Bordereau = ?',[ $Numero_Bordereau]);
            return redirect('/ti_Retour_Bordereau')->with("ti_Retour_Bordereau_delete",
            "Un Bordereau est Supprimer!");            
    }

    public function edit_ti_Retour_Bordereau_function($Numero_Bordereau){
        $affiche_Retour_Bordereau_To_Edit = DB::select('select * from bordereau  where Numero_Bordereau = ?;', 
        [$Numero_Bordereau]);
        $entites_affich = DB::select('select * from entites;');
        $correspondant_affich = DB::select('select * from correspondant;');
        
        return view('ti_Retour_Bordereau_Update', 
        ['affiche_Retour_Bordereau_To_Edit' => $affiche_Retour_Bordereau_To_Edit,
        'entites_affich' => $entites_affich, 'correspondant_affich' => $correspondant_affich]);  
    }

    public function update_ti_Retour_Bordereau_function(Request $req, $Numero_Bordereau){
        $entite_Bordereau_update = $req->input('entite_Bordereau_update');
        $correspondant_Bordereau_update = $req->input('correspondant_Bordereau_update');
        $date_creation_Bordereau_update = $req->input('date_creation_Bordereau_update');
        $date_reception_Bordereau_update = $req->input('date_reception_Bordereau_update');

        $statut_Bordereau_update = $req->input('statut_Bordereau_update');
        $adresse_Bordereu_update = $req->input('adresse_Bordereu_update');
        $bureau_Bordereau_update = $req->input('bureau_Bordereau_update');
        $etage_Bordereau_update = $req->input('etage_Bordereau_update');

        $ville_Bordereau_update = $req->input('ville_Bordereau_update');
        $tel_Bordereau_update = $req->input('tel_Bordereau_update');
        $fax_Bordereau_update = $req->input('fax_Bordereau_update');
        $commentaire_Bordereau_update = $req->input('commentaire_Bordereau_update');
        
        DB::update('update bordereau set Date_Creation=?, Date_Reception=?, Adresse=?,
        Tel =?, Statut=?, Bureau=?, Ville=?, Fax=?, Commentaire =?, Nom_Entite_E=?, Etage=?,
        Code_Correspondant_E=?
        where Numero_Bordereau=? ;', 
        [$date_creation_Bordereau_update, $date_reception_Bordereau_update, $adresse_Bordereu_update, $tel_Bordereau_update,
         $statut_Bordereau_update, $bureau_Bordereau_update, $ville_Bordereau_update, 
        $fax_Bordereau_update, $commentaire_Bordereau_update, $entite_Bordereau_update, $etage_Bordereau_update, 
        $correspondant_Bordereau_update, $Numero_Bordereau
        ]); 

        return redirect('/ti_Retour_Bordereau')->with("ti_Retour_Bordereau_update",
            "Un Bordereau est Modifier");        
    } 
}
