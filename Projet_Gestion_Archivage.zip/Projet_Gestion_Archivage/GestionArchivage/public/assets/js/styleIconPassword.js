 const eye = document.querySelector(".feather-eye");
const eyeoff = document.querySelector(".feather-eye-off");
const fields = document.querySelectorAll("input[type=password]");
fields.forEach(field => {
     field.parentElement.querySelector('.feather-eye').addEventListener("click", () => {
    if (field.type === 'password'){
      field.type="text";
      this.className='.feather-eye-off';
    }else{
      field.type='password';
    }
     });
    
 })

